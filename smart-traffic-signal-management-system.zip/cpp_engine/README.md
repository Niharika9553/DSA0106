# Smart Traffic Signal Management System — C++11 + OpenCV + YOLO ONNX Engine

This directory contains the complete object-oriented C++11 detection and traffic control engine.

## 1. Architecture & Modules

- `Road`: Encapsulates directional lane ROI, vehicle class counters (`car`, `bus`, `truck`, `motorcycle`), and emergency state.
- `VehicleDetector`: Loads `yolov8n.onnx` via `cv::dnn::readNetFromONNX`, runs NMS, classifies vehicles into North/South/East/West detection regions, and draws bounding boxes with confidence percentages.
- `VehicleTracker`: Nearest-centroid tracker with virtual counting lines across consecutive frames so each unique vehicle is counted once.
- `TrafficDensity`: Computes vehicle counts, directional density percentages, highest-density road, and `LOW` / `MEDIUM` / `HIGH` status.
- `TrafficSignal`: Implements `RED` / `GREEN` / `YELLOW` states and proportional `Green Time = Vehicle Count * 2 seconds` (no 60s cap; zero-vehicle roads skipped).
- `EmergencyManager`: Manages Ambulance and Fire Engine alerts and triggers safe next-phase priority.
- `PedestrianCrossing`: Enforces the 15-second all-red pedestrian `WALK` phase.
- `TrafficSignalController`: Executes `GREEN -> YELLOW -> ALL_RED_CLEARANCE -> NEXT GREEN` transitions with intersection occupancy safety checks.
- `TrafficLogger`: Writes completed traffic cycles to `traffic_history.csv`.
- `main.cpp`: Runs the controlled-interval (100ms) OpenCV capture loop, 1s signal state machine thread, and HTTP JSON API on `http://localhost:8080`.

## 2. Dependencies

- **C++11 Compiler**: `g++` (GCC 7+) or `clang++`
- **CMake**: 3.16+
- **OpenCV**: 4.7+ (required for YOLOv8 ONNX `cv::dnn` layers)

### Ubuntu / Debian
```bash
sudo apt update
sudo apt install -y build-essential cmake libopencv-dev
```

### macOS (Homebrew)
```bash
brew install cmake opencv
```

## 3. YOLO ONNX Model Setup

Place a YOLOv8 ONNX model at `cpp_engine/models/yolov8n.onnx`:

```bash
mkdir -p cpp_engine/models
yolo export model=yolov8n.pt format=onnx imgsz=640 simplify=True
mv yolov8n.onnx cpp_engine/models/yolov8n.onnx
```

## 4. Compilation Commands

```bash
cd cpp_engine
mkdir -p build && cd build
cmake ..
make -j4
```

## 5. Execution Instructions

```bash
# Live Webcam (Index 0)
./smart_traffic_engine ../models/yolov8n.onnx

# Or Video File
./smart_traffic_engine ../models/yolov8n.onnx path/to/traffic_video.mp4
```

The HTTP/JSON API runs at `http://localhost:8080`:
- `GET  /api/status`
- `GET  /api/frame.jpg`
- `POST /api/camera/start`
- `POST /api/camera/stop`
- `POST /api/simulation/start`
- `POST /api/simulation/pause`
- `POST /api/simulation/resume`
- `POST /api/simulation/stop`
- `POST /api/pedestrian/start`
- `POST /api/reset`
- `POST /api/emergency/<Direction>/<AMBULANCE|FIRE_ENGINE|NONE>`
