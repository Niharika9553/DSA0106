#include "VehicleTracker.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

VehicleTracker::VehicleTracker(int maxMissingFrames, double maxCentroidDistance)
    : nextTrackId_(1),
      maxMissingFrames_(maxMissingFrames),
      maxCentroidDistance_(maxCentroidDistance) {}

bool VehicleTracker::crossedVirtualCountingLine(const TrackedVehicle& track, const cv::Size& frameSize) const {
    if (frameSize.width <= 0 || frameSize.height <= 0) return true;

    double nyPrev = static_cast<double>(track.prevCentroid.y) / frameSize.height;
    double nyCurr = static_cast<double>(track.centroid.y) / frameSize.height;
    double nxPrev = static_cast<double>(track.prevCentroid.x) / frameSize.width;
    double nxCurr = static_cast<double>(track.centroid.x) / frameSize.width;

    switch (track.direction) {
        case Direction::NORTH:
            // Virtual counting line at y = 0.30 (approaching downward)
            return (nyPrev < 0.30 && nyCurr >= 0.30) || (nyCurr >= 0.25 && nyCurr <= 0.35 && track.prevCentroid == track.centroid);
        case Direction::SOUTH:
            // Virtual counting line at y = 0.70 (approaching upward)
            return (nyPrev > 0.70 && nyCurr <= 0.70) || (nyCurr >= 0.65 && nyCurr <= 0.75 && track.prevCentroid == track.centroid);
        case Direction::WEST:
            // Virtual counting line at x = 0.30 (approaching rightward)
            return (nxPrev < 0.30 && nxCurr >= 0.30) || (nxCurr >= 0.25 && nxCurr <= 0.35 && track.prevCentroid == track.centroid);
        case Direction::EAST:
            // Virtual counting line at x = 0.70 (approaching leftward)
            return (nxPrev > 0.70 && nxCurr <= 0.70) || (nxCurr >= 0.65 && nxCurr <= 0.75 && track.prevCentroid == track.centroid);
    }
    return false;
}

std::vector<TrackedVehicle> VehicleTracker::update(const std::vector<Detection>& detections,
                                                   const cv::Size& frameSize) {
    std::vector<TrackedVehicle> newlyCounted;
    std::vector<bool> detectionMatched(detections.size(), false);

    // Match existing tracks via nearest centroid
    for (auto& track : activeTracks_) {
        double bestDist = std::numeric_limits<double>::max();
        int bestIdx = -1;

        for (size_t i = 0; i < detections.size(); ++i) {
            if (detectionMatched[i]) continue;
            cv::Point detCenter(detections[i].box.x + detections[i].box.width / 2,
                                detections[i].box.y + detections[i].box.height / 2);
            double dist = std::hypot(detCenter.x - track.centroid.x,
                                     detCenter.y - track.centroid.y);
            if (dist < bestDist && dist <= maxCentroidDistance_) {
                bestDist = dist;
                bestIdx = static_cast<int>(i);
            }
        }

        if (bestIdx >= 0) {
            detectionMatched[bestIdx] = true;
            track.prevCentroid = track.centroid;
            track.box = detections[bestIdx].box;
            track.centroid = cv::Point(track.box.x + track.box.width / 2,
                                       track.box.y + track.box.height / 2);
            track.className = detections[bestIdx].className;
            track.confidence = detections[bestIdx].confidence;
            track.direction = detections[bestIdx].direction;
            track.framesMissing = 0;

            if (!track.counted &&
                countedTrackIds_.find(track.trackId) == countedTrackIds_.end() &&
                crossedVirtualCountingLine(track, frameSize)) {
                track.counted = true;
                countedTrackIds_.insert(track.trackId);
                newlyCounted.push_back(track);
            }
        } else {
            track.framesMissing++;
        }
    }

    // Remove expired tracks
    activeTracks_.erase(
        std::remove_if(activeTracks_.begin(), activeTracks_.end(),
                       [this](const TrackedVehicle& t) {
                           return t.framesMissing > maxMissingFrames_;
                       }),
        activeTracks_.end());

    // Register newly detected objects
    for (size_t i = 0; i < detections.size(); ++i) {
        if (detectionMatched[i]) continue;

        TrackedVehicle tv;
        tv.trackId = nextTrackId_++;
        tv.box = detections[i].box;
        tv.centroid = cv::Point(tv.box.x + tv.box.width / 2,
                                tv.box.y + tv.box.height / 2);
        tv.prevCentroid = tv.centroid;
        tv.className = detections[i].className;
        tv.confidence = detections[i].confidence;
        tv.direction = detections[i].direction;
        tv.framesMissing = 0;
        tv.counted = false;

        if (crossedVirtualCountingLine(tv, frameSize)) {
            tv.counted = true;
            countedTrackIds_.insert(tv.trackId);
            newlyCounted.push_back(tv);
        }

        activeTracks_.push_back(tv);
    }

    return newlyCounted;
}

const std::vector<TrackedVehicle>& VehicleTracker::getActiveTracks() const {
    return activeTracks_;
}

void VehicleTracker::reset() {
    nextTrackId_ = 1;
    activeTracks_.clear();
    countedTrackIds_.clear();
}
