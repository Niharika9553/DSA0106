#include "Road.hpp"

Road::Road(Direction direction, const std::string& name, const cv::Rect& roi)
    : direction_(direction),
      name_(name),
      detectionROI_(roi),
      vehicleCount_(0),
      carCount_(0),
      busCount_(0),
      truckCount_(0),
      motorcycleCount_(0),
      emergency_(EmergencyType::NONE) {}

Direction Road::getDirection() const { return direction_; }
std::string Road::getName() const { return name_; }
cv::Rect Road::getDetectionROI() const { return detectionROI_; }
void Road::setDetectionROI(const cv::Rect& roi) { detectionROI_ = roi; }

void Road::incrementVehicle(const std::string& vehicleClass) {
    vehicleCount_++;
    if (vehicleClass == "car") {
        carCount_++;
    } else if (vehicleClass == "bus") {
        busCount_++;
    } else if (vehicleClass == "truck") {
        truckCount_++;
    } else if (vehicleClass == "motorcycle") {
        motorcycleCount_++;
    }
}

void Road::resetCounts() {
    vehicleCount_ = 0;
    carCount_ = 0;
    busCount_ = 0;
    truckCount_ = 0;
    motorcycleCount_ = 0;
}

int Road::getVehicleCount() const { return vehicleCount_; }
int Road::getCarCount() const { return carCount_; }
int Road::getBusCount() const { return busCount_; }
int Road::getTruckCount() const { return truckCount_; }
int Road::getMotorcycleCount() const { return motorcycleCount_; }

void Road::setEmergency(EmergencyType type) { emergency_ = type; }
EmergencyType Road::getEmergency() const { return emergency_; }
bool Road::hasEmergency() const { return emergency_ != EmergencyType::NONE; }

std::string Road::directionToString(Direction dir) {
    switch (dir) {
        case Direction::NORTH: return "North";
        case Direction::SOUTH: return "South";
        case Direction::EAST:  return "East";
        case Direction::WEST:  return "West";
    }
    return "North";
}

std::string Road::emergencyToString(EmergencyType type) {
    switch (type) {
        case EmergencyType::AMBULANCE:   return "AMBULANCE";
        case EmergencyType::FIRE_ENGINE: return "FIRE_ENGINE";
        case EmergencyType::NONE:        return "NONE";
    }
    return "NONE";
}
