#include "PedestrianCrossing.hpp"

PedestrianCrossing::PedestrianCrossing(int durationSeconds)
    : active_(false),
      durationSeconds_(durationSeconds),
      remainingSeconds_(0) {}

void PedestrianCrossing::activate() {
    active_ = true;
    remainingSeconds_ = durationSeconds_;
}

void PedestrianCrossing::deactivate() {
    active_ = false;
    remainingSeconds_ = 0;
}

void PedestrianCrossing::tick() {
    if (!active_) return;
    if (remainingSeconds_ > 0) {
        remainingSeconds_--;
    }
    if (remainingSeconds_ <= 0) {
        active_ = false;
    }
}

bool PedestrianCrossing::isActive() const { return active_; }
int PedestrianCrossing::getRemainingSeconds() const { return remainingSeconds_; }
int PedestrianCrossing::getDurationSeconds() const { return durationSeconds_; }
