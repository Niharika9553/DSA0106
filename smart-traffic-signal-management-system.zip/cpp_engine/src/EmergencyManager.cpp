#include "EmergencyManager.hpp"
#include <algorithm>

void EmergencyManager::registerEmergency(Direction direction, EmergencyType type) {
    if (type == EmergencyType::NONE) {
        clearEmergency(direction);
        return;
    }
    for (auto& alert : alerts_) {
        if (alert.direction == direction) {
            alert.type = type;
            alert.servedInCurrentCycle = false;
            return;
        }
    }
    alerts_.push_back({direction, type, false});
}

void EmergencyManager::clearEmergency(Direction direction) {
    alerts_.erase(
        std::remove_if(alerts_.begin(), alerts_.end(),
                       [direction](const EmergencyAlert& a) {
                           return a.direction == direction;
                       }),
        alerts_.end());
}

void EmergencyManager::clearAll() {
    alerts_.clear();
}

bool EmergencyManager::isPriorityMode() const {
    return !alerts_.empty();
}

bool EmergencyManager::hasPendingEmergency() const {
    for (const auto& a : alerts_) {
        if (!a.servedInCurrentCycle) return true;
    }
    return false;
}

Direction EmergencyManager::getNextPriorityDirection() const {
    for (const auto& a : alerts_) {
        if (!a.servedInCurrentCycle) return a.direction;
    }
    return Direction::NORTH;
}

void EmergencyManager::markServed(Direction direction) {
    for (auto& a : alerts_) {
        if (a.direction == direction) {
            a.servedInCurrentCycle = true;
        }
    }
}

void EmergencyManager::resetCycleFlags() {
    for (auto& a : alerts_) {
        a.servedInCurrentCycle = false;
    }
}

const std::vector<EmergencyAlert>& EmergencyManager::getAlerts() const {
    return alerts_;
}
