#include "TrafficLogger.hpp"
#include <ctime>
#include <fstream>
#include <sstream>

TrafficLogger::TrafficLogger(const std::string& csvFilePath)
    : csvFilePath_(csvFilePath) {
    std::ifstream check(csvFilePath_);
    if (!check.good()) {
        std::ofstream out(csvFilePath_);
        if (out.is_open()) {
            out << "Cycle,Timestamp,North,South,East,West,SignalOrder,GreenDurations,Emergencies,Congestion\n";
        }
    }
}

std::string TrafficLogger::currentTimestamp() {
    std::time_t now = std::time(nullptr);
    char buf[64];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&now));
    return std::string(buf);
}

void TrafficLogger::logCycle(int cycleNumber,
                             const int counts[4],
                             const int greenDurations[4],
                             const std::vector<Direction>& signalOrder,
                             const std::string& emergencySummary,
                             CongestionLevel congestionLevel) {
    CycleLogEntry entry;
    entry.cycleNumber = cycleNumber;
    entry.timestamp = currentTimestamp();
    for (int i = 0; i < 4; ++i) {
        entry.counts[i] = counts[i];
        entry.greenDurations[i] = greenDurations[i];
    }
    entry.signalOrder = signalOrder;
    entry.emergencySummary = emergencySummary;
    entry.congestionLevel = congestionLevel;
    entries_.push_back(entry);

    std::ofstream out(csvFilePath_, std::ios::app);
    if (out.is_open()) {
        std::ostringstream orderStr;
        for (size_t i = 0; i < signalOrder.size(); ++i) {
            if (i > 0) orderStr << " -> ";
            orderStr << Road::directionToString(signalOrder[i]);
        }

        out << cycleNumber << ","
            << "\"" << entry.timestamp << "\","
            << counts[0] << "," << counts[1] << "," << counts[2] << "," << counts[3] << ","
            << "\"" << orderStr.str() << "\","
            << "\"N:" << greenDurations[0] << "s S:" << greenDurations[1]
            << "s E:" << greenDurations[2] << "s W:" << greenDurations[3] << "s\","
            << "\"" << emergencySummary << "\","
            << TrafficDensity::levelToString(congestionLevel) << "\n";
    }
}

const std::vector<CycleLogEntry>& TrafficLogger::getEntries() const {
    return entries_;
}

void TrafficLogger::clear() {
    entries_.clear();
}
