#include "TrafficDensity.hpp"
#include <cmath>

std::vector<DirectionDensity> TrafficDensity::compute(const std::vector<Road>& roads) {
    int total = getTotalVehicles(roads);
    std::vector<DirectionDensity> out;
    out.reserve(roads.size());

    for (const auto& road : roads) {
        DirectionDensity dd;
        dd.direction = road.getDirection();
        dd.vehicleCount = road.getVehicleCount();
        dd.percentage = (total > 0)
                            ? (static_cast<double>(dd.vehicleCount) / total) * 100.0
                            : 0.0;
        dd.status = classifyRoadCount(dd.vehicleCount);
        out.push_back(dd);
    }
    return out;
}

int TrafficDensity::getTotalVehicles(const std::vector<Road>& roads) {
    int total = 0;
    for (const auto& r : roads) {
        total += r.getVehicleCount();
    }
    return total;
}

Direction TrafficDensity::getHighestDensityDirection(const std::vector<Road>& roads) {
    Direction best = Direction::NORTH;
    int maxCount = -1;
    for (const auto& r : roads) {
        if (r.getVehicleCount() > maxCount) {
            maxCount = r.getVehicleCount();
            best = r.getDirection();
        }
    }
    return best;
}

CongestionLevel TrafficDensity::classifyRoadCount(int count) {
    if (count >= 40) return CongestionLevel::HIGH;
    if (count >= 15) return CongestionLevel::MEDIUM;
    return CongestionLevel::LOW;
}

CongestionLevel TrafficDensity::classifyIntersectionWeighted(int currentTotal, int previousTotal) {
    double score = (previousTotal >= 0)
                       ? (0.6 * currentTotal + 0.4 * previousTotal)
                       : static_cast<double>(currentTotal);
    int rounded = static_cast<int>(std::round(score));
    if (rounded > 280) return CongestionLevel::HIGH;
    if (rounded >= 120) return CongestionLevel::MEDIUM;
    return CongestionLevel::LOW;
}

std::string TrafficDensity::levelToString(CongestionLevel level) {
    switch (level) {
        case CongestionLevel::LOW:    return "LOW";
        case CongestionLevel::MEDIUM: return "MEDIUM";
        case CongestionLevel::HIGH:   return "HIGH";
    }
    return "LOW";
}
