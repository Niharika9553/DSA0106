#include "TrafficSignalController.hpp"
#include <algorithm>
#include <sstream>

TrafficSignalController::TrafficSignalController()
    : pedestrian_(15),
      logger_("traffic_history.csv"),
      phase_(ControllerPhase::IDLE),
      activeDirection_(Direction::NORTH),
      clearanceRemainingSeconds_(0),
      cycleNumber_(0),
      previousCycleVehicles_(-1),
      intersectionOccupied_(false),
      paused_(false),
      stopped_(false),
      pendingPedestrian_(false),
      emergencyClearancePending_(false),
      lastEmergencyDirection_(Direction::NORTH),
      queueIndex_(0) {
    roads_.emplace_back(Direction::NORTH, "North", cv::Rect(220, 0, 200, 180));
    roads_.emplace_back(Direction::SOUTH, "South", cv::Rect(220, 300, 200, 180));
    roads_.emplace_back(Direction::EAST, "East", cv::Rect(420, 180, 220, 120));
    roads_.emplace_back(Direction::WEST, "West", cv::Rect(0, 180, 220, 120));

    for (int i = 0; i < 4; ++i) {
        signals_.emplace_back(static_cast<Direction>(i));
        allocatedDurations_[i] = 0;
    }
}

void TrafficSignalController::setAllSignalsRed() {
    for (auto& sig : signals_) {
        sig.setRed();
    }
}

void TrafficSignalController::buildCycleQueue() {
    cycleQueue_.clear();
    queueIndex_ = 0;
    servedOrder_.clear();
    for (int i = 0; i < 4; ++i) allocatedDurations_[i] = 0;

    std::vector<Road> sorted = roads_;

    // Emergency directions first, then descending by latest vehicle count (fair deterministic tie-breaker)
    std::sort(sorted.begin(), sorted.end(), [](const Road& a, const Road& b) {
        if (a.hasEmergency() != b.hasEmergency()) {
            return a.hasEmergency();
        }
        if (a.getVehicleCount() != b.getVehicleCount()) {
            return a.getVehicleCount() > b.getVehicleCount();
        }
        return static_cast<int>(a.getDirection()) < static_cast<int>(b.getDirection());
    });

    for (const auto& road : sorted) {
        if (road.getVehicleCount() == 0 && !road.hasEmergency()) {
            continue; // Skip zero-vehicle directions
        }
        cycleQueue_.push_back(road.getDirection());
        int idx = static_cast<int>(road.getDirection());
        allocatedDurations_[idx] =
            TrafficSignal::calculateGreenDuration(road.getVehicleCount(), road.hasEmergency());
    }
}

void TrafficSignalController::analyzeLatestDensityAndBuildSchedule(Direction lastServed) {
    cycleQueue_.clear();
    queueIndex_ = 0;
    servedOrder_.clear();
    for (int i = 0; i < 4; ++i) allocatedDurations_[i] = 0;

    std::vector<Road> sorted = roads_;
    std::sort(sorted.begin(), sorted.end(), [lastServed](const Road& a, const Road& b) {
        if (a.hasEmergency() != b.hasEmergency()) {
            return a.hasEmergency();
        }
        if (a.getVehicleCount() != b.getVehicleCount()) {
            return a.getVehicleCount() > b.getVehicleCount();
        }
        if (a.getDirection() == lastServed && b.getDirection() != lastServed) return false;
        if (b.getDirection() == lastServed && a.getDirection() != lastServed) return true;
        return static_cast<int>(a.getDirection()) < static_cast<int>(b.getDirection());
    });

    for (const auto& road : sorted) {
        if (road.getVehicleCount() == 0 && !road.hasEmergency()) {
            continue;
        }
        cycleQueue_.push_back(road.getDirection());
        int idx = static_cast<int>(road.getDirection());
        allocatedDurations_[idx] =
            TrafficSignal::calculateGreenDuration(road.getVehicleCount(), road.hasEmergency());
    }
}

void TrafficSignalController::startDirectionGreen(Direction dir) {
    setAllSignalsRed();
    activeDirection_ = dir;
    int idx = static_cast<int>(dir);
    int duration = TrafficSignal::calculateGreenDuration(
        roads_[idx].getVehicleCount(), roads_[idx].hasEmergency());
    allocatedDurations_[idx] = duration;
    signals_[idx].setGreen(duration);
    phase_ = ControllerPhase::GREEN;
    if (std::find(servedOrder_.begin(), servedOrder_.end(), dir) == servedOrder_.end()) {
        servedOrder_.push_back(dir);
    }
}

void TrafficSignalController::recordDetectedVehicle(Direction dir, const std::string& vehicleClass) {
    if (paused_ || stopped_) return;
    int idx = static_cast<int>(dir);
    roads_[idx].incrementVehicle(vehicleClass);

    if (phase_ == ControllerPhase::IDLE) {
        buildCycleQueue();
        if (!cycleQueue_.empty()) {
            startDirectionGreen(cycleQueue_[0]);
        }
    }
}

void TrafficSignalController::setRoadCountManual(Direction dir, int count) {
    int idx = static_cast<int>(dir);
    roads_[idx].resetCounts();
    for (int i = 0; i < count; ++i) {
        roads_[idx].incrementVehicle("car");
    }
    buildCycleQueue();
    if (phase_ == ControllerPhase::IDLE && !stopped_ && !paused_ && !cycleQueue_.empty()) {
        startDirectionGreen(cycleQueue_[0]);
    }
}

void TrafficSignalController::setRoadEmergency(Direction dir, EmergencyType type) {
    int idx = static_cast<int>(dir);
    roads_[idx].setEmergency(type);
    emergencyManager_.registerEmergency(dir, type);

    if (stopped_) return;

    if (phase_ == ControllerPhase::IDLE && type != EmergencyType::NONE) {
        buildCycleQueue();
        if (!cycleQueue_.empty()) {
            startDirectionGreen(cycleQueue_[0]);
        }
    } else if (phase_ == ControllerPhase::GREEN &&
               activeDirection_ != dir &&
               type != EmergencyType::NONE) {
        // Begin safe transition: current GREEN -> YELLOW -> Required ALL-RED CLEARANCE -> Emergency GREEN
        int activeIdx = static_cast<int>(activeDirection_);
        signals_[activeIdx].setYellow(2);
        phase_ = ControllerPhase::YELLOW;
    }
}

void TrafficSignalController::notifyEmergencyVehicleExited(Direction dir) {
    int idx = static_cast<int>(dir);
    if (!roads_[idx].hasEmergency()) {
        return;
    }

    // 1. Immediately release emergency priority upon exit confirmation
    roads_[idx].setEmergency(EmergencyType::NONE);
    emergencyManager_.clearEmergency(dir);
    lastEmergencyDirection_ = dir;

    // 2. Immediately analyze latest 4-direction traffic density
    analyzeLatestDensityAndBuildSchedule(dir);

    // 3. Enforce required safety sequence without unnecessary extra delay:
    //    Emergency GREEN -> YELLOW (2s) -> Required ALL-RED Safety Clearance (1s) -> Highest-Density GREEN
    if (phase_ == ControllerPhase::GREEN && activeDirection_ == dir) {
        emergencyClearancePending_ = true;
        signals_[idx].setYellow(2);
        phase_ = ControllerPhase::YELLOW;
    }
}

void TrafficSignalController::setIntersectionOccupied(bool occupied) {
    intersectionOccupied_ = occupied;
}

void TrafficSignalController::startSimulation() {
    stopped_ = false;
    paused_ = false;
    if (phase_ == ControllerPhase::IDLE) {
        buildCycleQueue();
        if (!cycleQueue_.empty()) {
            startDirectionGreen(cycleQueue_[0]);
        }
    }
}

void TrafficSignalController::pauseSimulation() {
    paused_ = true;
}

void TrafficSignalController::resumeSimulation() {
    if (!stopped_) {
        paused_ = false;
    }
}

void TrafficSignalController::stopSimulation() {
    stopped_ = true;
    paused_ = false;
    setAllSignalsRed();
    pedestrian_.deactivate();
    phase_ = ControllerPhase::IDLE;
}

void TrafficSignalController::requestPedestrianCrossing() {
    if (stopped_) return;
    if (phase_ == ControllerPhase::IDLE) {
        setAllSignalsRed();
        pedestrian_.activate();
        phase_ = ControllerPhase::PEDESTRIAN_WALK;
    } else if (phase_ == ControllerPhase::GREEN) {
        pendingPedestrian_ = true;
        int idx = static_cast<int>(activeDirection_);
        signals_[idx].setYellow(3);
        phase_ = ControllerPhase::YELLOW;
    } else {
        pendingPedestrian_ = true;
    }
}

void TrafficSignalController::reset() {
    for (auto& r : roads_) {
        r.resetCounts();
        r.setEmergency(EmergencyType::NONE);
    }
    emergencyManager_.clearAll();
    pedestrian_.deactivate();
    setAllSignalsRed();
    cycleQueue_.clear();
    servedOrder_.clear();
    queueIndex_ = 0;
    phase_ = ControllerPhase::IDLE;
    clearanceRemainingSeconds_ = 0;
    intersectionOccupied_ = false;
    paused_ = false;
    stopped_ = false;
    pendingPedestrian_ = false;
    emergencyClearancePending_ = false;
}

void TrafficSignalController::completeCycleAndRestart() {
    cycleNumber_++;
    int counts[4];
    for (int i = 0; i < 4; ++i) counts[i] = roads_[i].getVehicleCount();

    int total = TrafficDensity::getTotalVehicles(roads_);
    CongestionLevel level = TrafficDensity::classifyIntersectionWeighted(total, previousCycleVehicles_);
    previousCycleVehicles_ = total;

    logger_.logCycle(cycleNumber_, counts, allocatedDurations_, servedOrder_, "Completed", level);
    emergencyManager_.resetCycleFlags();

    buildCycleQueue();
    if (!cycleQueue_.empty()) {
        startDirectionGreen(cycleQueue_[0]);
    } else {
        phase_ = ControllerPhase::IDLE;
        setAllSignalsRed();
    }
}

void TrafficSignalController::tickSecond() {
    if (paused_ || stopped_) return;

    if (phase_ == ControllerPhase::IDLE) {
        if (pendingPedestrian_) {
            pendingPedestrian_ = false;
            setAllSignalsRed();
            pedestrian_.activate();
            phase_ = ControllerPhase::PEDESTRIAN_WALK;
            return;
        }
        buildCycleQueue();
        if (!cycleQueue_.empty()) {
            startDirectionGreen(cycleQueue_[0]);
        }
        return;
    }

    if (phase_ == ControllerPhase::GREEN) {
        int idx = static_cast<int>(activeDirection_);
        signals_[idx].decrementSecond();
        if (signals_[idx].getRemainingSeconds() <= 0) {
            if (roads_[idx].hasEmergency()) {
                notifyEmergencyVehicleExited(activeDirection_);
            } else {
                signals_[idx].setYellow(2);
                phase_ = ControllerPhase::YELLOW;
            }
        }
        return;
    }

    if (phase_ == ControllerPhase::YELLOW) {
        int idx = static_cast<int>(activeDirection_);
        signals_[idx].decrementSecond();
        if (signals_[idx].getRemainingSeconds() <= 0) {
            setAllSignalsRed();
            if (roads_[idx].hasEmergency()) {
                roads_[idx].setEmergency(EmergencyType::NONE);
                emergencyManager_.clearEmergency(activeDirection_);
                lastEmergencyDirection_ = activeDirection_;
                emergencyClearancePending_ = true;
            }
            // Required minimum 1s ALL-RED safety clearance (extended dynamically only if occupied)
            clearanceRemainingSeconds_ = 1;
            phase_ = ControllerPhase::ALL_RED_CLEARANCE;
        }
        return;
    }

    if (phase_ == ControllerPhase::ALL_RED_CLEARANCE) {
        if (clearanceRemainingSeconds_ > 0) {
            clearanceRemainingSeconds_--;
        }
        if (clearanceRemainingSeconds_ > 0 || intersectionOccupied_) {
            return;
        }

        if (pendingPedestrian_) {
            pendingPedestrian_ = false;
            setAllSignalsRed();
            pedestrian_.activate();
            phase_ = ControllerPhase::PEDESTRIAN_WALK;
            return;
        }

        if (emergencyManager_.hasPendingEmergency()) {
            Direction nextEmg = emergencyManager_.getNextPriorityDirection();
            startDirectionGreen(nextEmg);
            return;
        }

        if (emergencyClearancePending_) {
            emergencyClearancePending_ = false;
            analyzeLatestDensityAndBuildSchedule(lastEmergencyDirection_);
            if (!cycleQueue_.empty()) {
                startDirectionGreen(cycleQueue_[0]);
            } else {
                phase_ = ControllerPhase::IDLE;
                setAllSignalsRed();
            }
            return;
        }

        for (const auto& candidate : cycleQueue_) {
            bool alreadyServed = std::find(servedOrder_.begin(), servedOrder_.end(), candidate) != servedOrder_.end();
            int cIdx = static_cast<int>(candidate);
            if (!alreadyServed && (roads_[cIdx].getVehicleCount() > 0 || roads_[cIdx].hasEmergency())) {
                startDirectionGreen(candidate);
                return;
            }
        }

        // All active directions served -> enter 15-second Pedestrian WALK phase
        setAllSignalsRed();
        pedestrian_.activate();
        phase_ = ControllerPhase::PEDESTRIAN_WALK;
        return;
    }

    if (phase_ == ControllerPhase::PEDESTRIAN_WALK) {
        pedestrian_.tick();
        if (!pedestrian_.isActive()) {
            completeCycleAndRestart();
        }
    }
}

ControllerPhase TrafficSignalController::getPhase() const { return phase_; }
Direction TrafficSignalController::getActiveDirection() const { return activeDirection_; }
bool TrafficSignalController::isPaused() const { return paused_; }
bool TrafficSignalController::isStopped() const { return stopped_; }
int TrafficSignalController::getCycleNumber() const { return cycleNumber_; }
const std::vector<Road>& TrafficSignalController::getRoads() const { return roads_; }
const std::vector<TrafficSignal>& TrafficSignalController::getSignals() const { return signals_; }
const EmergencyManager& TrafficSignalController::getEmergencyManager() const { return emergencyManager_; }
const PedestrianCrossing& TrafficSignalController::getPedestrianCrossing() const { return pedestrian_; }

std::string TrafficSignalController::toJsonStatus(bool cameraActive,
                                                  bool detectionRunning,
                                                  const std::string& modelStatus,
                                                  const std::string& cameraError,
                                                  const std::string& modelError) const {
    auto densities = TrafficDensity::compute(roads_);
    int total = TrafficDensity::getTotalVehicles(roads_);
    Direction highest = TrafficDensity::getHighestDensityDirection(roads_);

    std::string phaseStr = "IDLE";
    if (phase_ == ControllerPhase::GREEN) phaseStr = "ROAD_GREEN";
    else if (phase_ == ControllerPhase::YELLOW) phaseStr = "ROAD_YELLOW";
    else if (phase_ == ControllerPhase::ALL_RED_CLEARANCE) phaseStr = "RED_CLEARANCE";
    else if (phase_ == ControllerPhase::PEDESTRIAN_WALK) phaseStr = "PEDESTRIAN_CROSSING";

    std::ostringstream ss;
    ss << "{";
    ss << "\"cameraActive\":" << (cameraActive ? "true" : "false") << ",";
    ss << "\"detectionRunning\":" << (detectionRunning ? "true" : "false") << ",";
    ss << "\"modelStatus\":\"" << modelStatus << "\",";
    ss << "\"cameraError\":\"" << cameraError << "\",";
    ss << "\"modelError\":\"" << modelError << "\",";
    ss << "\"paused\":" << (paused_ ? "true" : "false") << ",";
    ss << "\"stopped\":" << (stopped_ ? "true" : "false") << ",";
    ss << "\"phase\":\"" << phaseStr << "\",";
    ss << "\"activeDirection\":\"" << Road::directionToString(activeDirection_) << "\",";
    ss << "\"cycleNumber\":" << cycleNumber_ << ",";
    ss << "\"totalVehicles\":" << total << ",";
    ss << "\"highestDensityDirection\":\"" << Road::directionToString(highest) << "\",";
    ss << "\"priorityMode\":" << (emergencyManager_.isPriorityMode() ? "true" : "false") << ",";
    ss << "\"pedestrianActive\":" << (pedestrian_.isActive() ? "true" : "false") << ",";
    ss << "\"pedestrianRemaining\":" << pedestrian_.getRemainingSeconds() << ",";
    ss << "\"roads\":[";
    for (size_t i = 0; i < roads_.size(); ++i) {
        if (i > 0) ss << ",";
        ss << "{"
           << "\"direction\":\"" << roads_[i].getName() << "\","
           << "\"count\":" << roads_[i].getVehicleCount() << ","
           << "\"cars\":" << roads_[i].getCarCount() << ","
           << "\"buses\":" << roads_[i].getBusCount() << ","
           << "\"trucks\":" << roads_[i].getTruckCount() << ","
           << "\"motorcycles\":" << roads_[i].getMotorcycleCount() << ","
           << "\"densityPercent\":" << densities[i].percentage << ","
           << "\"status\":\"" << TrafficDensity::levelToString(densities[i].status) << "\","
           << "\"signal\":\"" << TrafficSignal::stateToString(signals_[i].getState()) << "\","
           << "\"remainingSeconds\":" << signals_[i].getRemainingSeconds() << ","
           << "\"allocatedGreenSeconds\":" << allocatedDurations_[i] << ","
           << "\"emergency\":\"" << Road::emergencyToString(roads_[i].getEmergency()) << "\""
           << "}";
    }
    ss << "]}";
    return ss.str();
}
