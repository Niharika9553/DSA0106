#include "VehicleDetector.hpp"
#include <algorithm>
#include <iostream>

VehicleDetector::VehicleDetector(float confThreshold, float nmsThreshold)
    : modelLoaded_(false),
      confThreshold_(confThreshold),
      nmsThreshold_(nmsThreshold),
      inputWidth_(640),
      inputHeight_(640) {
    // Subset of COCO classes relevant to road traffic (YOLOv8 indices: 2=car, 3=motorcycle, 5=bus, 7=truck)
    classNames_ = {"car", "motorcycle", "bus", "truck"};
}

bool VehicleDetector::loadModel(const std::string& onnxModelPath) {
    try {
        net_ = cv::dnn::readNetFromONNX(onnxModelPath);
        if (net_.empty()) {
            modelLoaded_ = false;
            return false;
        }
        net_.setPreferableBackend(cv::dnn::DNN_BACKEND_OPENCV);
        net_.setPreferableTarget(cv::dnn::DNN_TARGET_CPU);
        modelLoaded_ = true;
        return true;
    } catch (const cv::Exception& ex) {
        std::cerr << "[VehicleDetector] Failed to load YOLO ONNX model: " << ex.what() << std::endl;
        modelLoaded_ = false;
        return false;
    }
}

bool VehicleDetector::isModelLoaded() const {
    return modelLoaded_;
}

Direction VehicleDetector::classifyDirection(const cv::Point& center, const cv::Size& frameSize) const {
    double nx = static_cast<double>(center.x) / std::max(1, frameSize.width);
    double ny = static_cast<double>(center.y) / std::max(1, frameSize.height);

    // Quadrant-based directional ROI assignment around intersection center (0.5, 0.5)
    double dx = nx - 0.5;
    double dy = ny - 0.5;
    if (std::abs(dy) >= std::abs(dx)) {
        return (dy < 0) ? Direction::NORTH : Direction::SOUTH;
    }
    return (dx < 0) ? Direction::WEST : Direction::EAST;
}

std::vector<Detection> VehicleDetector::detect(const cv::Mat& frame) {
    std::vector<Detection> results;
    if (!modelLoaded_ || frame.empty()) {
        return results;
    }

    cv::Mat blob;
    cv::dnn::blobFromImage(frame, blob, 1.0 / 255.0,
                           cv::Size(inputWidth_, inputHeight_),
                           cv::Scalar(), true, false);
    net_.setInput(blob);

    std::vector<cv::Mat> outputs;
    net_.forward(outputs, net_.getUnconnectedOutLayersNames());
    if (outputs.empty()) {
        return results;
    }

    // YOLOv8 ONNX output tensor shape: [1, 84, 8400]
    cv::Mat output = outputs[0];
    int rows = output.size[2];
    int dimensions = output.size[1];

    output = output.reshape(1, dimensions);
    cv::Mat transposed;
    cv::transpose(output, transposed);

    float xFactor = static_cast<float>(frame.cols) / inputWidth_;
    float yFactor = static_cast<float>(frame.rows) / inputHeight_;

    std::vector<int> classIds;
    std::vector<float> confidences;
    std::vector<cv::Rect> boxes;

    const int targetCocoIds[4] = {2, 3, 5, 7}; // car, motorcycle, bus, truck

    for (int i = 0; i < rows; ++i) {
        const float* data = transposed.ptr<float>(i);
        const float* classesScores = data + 4;

        int bestTargetIdx = -1;
        float bestScore = 0.0f;

        for (int t = 0; t < 4; ++t) {
            int cocoId = targetCocoIds[t];
            if (cocoId + 4 < dimensions && classesScores[cocoId] > bestScore) {
                bestScore = classesScores[cocoId];
                bestTargetIdx = t;
            }
        }

        if (bestTargetIdx >= 0 && bestScore >= confThreshold_) {
            float cx = data[0];
            float cy = data[1];
            float w = data[2];
            float h = data[3];

            int left = static_cast<int>((cx - 0.5f * w) * xFactor);
            int top = static_cast<int>((cy - 0.5f * h) * yFactor);
            int width = static_cast<int>(w * xFactor);
            int height = static_cast<int>(h * yFactor);

            boxes.emplace_back(left, top, width, height);
            confidences.push_back(bestScore);
            classIds.push_back(bestTargetIdx);
        }
    }

    std::vector<int> nmsIndices;
    cv::dnn::NMSBoxes(boxes, confidences, confThreshold_, nmsThreshold_, nmsIndices);

    for (int idx : nmsIndices) {
        Detection det;
        det.box = boxes[idx] & cv::Rect(0, 0, frame.cols, frame.rows);
        det.classId = classIds[idx];
        det.className = classNames_[classIds[idx]];
        det.confidence = confidences[idx];
        cv::Point center(det.box.x + det.box.width / 2, det.box.y + det.box.height / 2);
        det.direction = classifyDirection(center, frame.size());
        results.push_back(det);
    }

    return results;
}

void VehicleDetector::drawDetections(cv::Mat& frame, const std::vector<Detection>& detections) const {
    for (const auto& det : detections) {
        cv::Scalar color(56, 189, 248); // Sky blue bounding box
        cv::rectangle(frame, det.box, color, 2);

        std::string label = det.className + " " +
                            std::to_string(static_cast<int>(det.confidence * 100)) + "% [" +
                            Road::directionToString(det.direction) + "]";
        int baseline = 0;
        cv::Size textSize = cv::getTextSize(label, cv::FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseline);
        int top = std::max(det.box.y, textSize.height + 6);
        cv::rectangle(frame,
                      cv::Point(det.box.x, top - textSize.height - 6),
                      cv::Point(det.box.x + textSize.width + 6, top),
                      color, cv::FILLED);
        cv::putText(frame, label, cv::Point(det.box.x + 3, top - 4),
                    cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(10, 15, 25), 1);
    }
}
