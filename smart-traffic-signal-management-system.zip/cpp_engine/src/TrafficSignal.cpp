#include "TrafficSignal.hpp"
#include <algorithm>

TrafficSignal::TrafficSignal(Direction direction)
    : direction_(direction),
      state_(SignalState::RED),
      remainingSeconds_(0),
      allocatedGreenSeconds_(0) {}

Direction TrafficSignal::getDirection() const { return direction_; }
SignalState TrafficSignal::getState() const { return state_; }
int TrafficSignal::getRemainingSeconds() const { return remainingSeconds_; }
int TrafficSignal::getAllocatedGreenSeconds() const { return allocatedGreenSeconds_; }

void TrafficSignal::setGreen(int durationSeconds) {
    state_ = SignalState::GREEN;
    remainingSeconds_ = durationSeconds;
    allocatedGreenSeconds_ = durationSeconds;
}

void TrafficSignal::setYellow(int durationSeconds) {
    state_ = SignalState::YELLOW;
    remainingSeconds_ = durationSeconds;
}

void TrafficSignal::setRed() {
    state_ = SignalState::RED;
    remainingSeconds_ = 0;
}

void TrafficSignal::decrementSecond() {
    if (remainingSeconds_ > 0) {
        remainingSeconds_--;
    }
}

int TrafficSignal::calculateGreenDuration(int vehicleCount, bool isEmergency) {
    if (isEmergency) {
        return std::max(20, vehicleCount * 2);
    }
    if (vehicleCount <= 0) {
        return 0;
    }
    return vehicleCount * 2;
}

std::string TrafficSignal::stateToString(SignalState state) {
    switch (state) {
        case SignalState::RED:    return "RED";
        case SignalState::GREEN:  return "GREEN";
        case SignalState::YELLOW: return "YELLOW";
    }
    return "RED";
}
