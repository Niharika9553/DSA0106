#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstring>
#include <iostream>
#include <mutex>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/videoio.hpp>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "TrafficSignalController.hpp"
#include "VehicleDetector.hpp"
#include "VehicleTracker.hpp"

struct EngineRuntime {
    std::mutex mtx;
    TrafficSignalController controller;
    VehicleDetector detector;
    VehicleTracker tracker;
    cv::VideoCapture cap;
    std::vector<unsigned char> latestJpegFrame;

    std::atomic<bool> running{true};
    std::atomic<bool> cameraActive{false};
    std::atomic<bool> detectionRunning{false};
    std::string videoSourcePath;
    std::string modelPath = "models/yolov8n.onnx";
    std::string cameraError;
    std::string modelError;
};

static void sendHttpResponse(int clientFd,
                             const std::string& status,
                             const std::string& contentType,
                             const std::string& body) {
    std::ostringstream res;
    res << "HTTP/1.1 " << status << "\r\n"
        << "Access-Control-Allow-Origin: *\r\n"
        << "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        << "Access-Control-Allow-Headers: Content-Type\r\n"
        << "Content-Type: " << contentType << "\r\n"
        << "Content-Length: " << body.size() << "\r\n"
        << "Connection: close\r\n\r\n";

    std::string header = res.str();
    send(clientFd, header.data(), header.size(), 0);
    if (!body.empty()) {
        send(clientFd, body.data(), body.size(), 0);
    }
}

static void handleApiRequest(int clientFd, EngineRuntime& rt) {
    char buffer[4096];
    ssize_t bytesRead = recv(clientFd, buffer, sizeof(buffer) - 1, 0);
    if (bytesRead <= 0) {
        close(clientFd);
        return;
    }
    buffer[bytesRead] = '\0';
    std::string req(buffer);

    std::istringstream iss(req);
    std::string method, path;
    iss >> method >> path;

    if (method == "OPTIONS") {
        sendHttpResponse(clientFd, "204 No Content", "text/plain", "");
        close(clientFd);
        return;
    }

    if (method == "GET" && path == "/api/status") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        std::string modelStatus = rt.detector.isModelLoaded() ? "YOLO_ONNX_LOADED" : "MODEL_UNAVAILABLE";
        std::string json = rt.controller.toJsonStatus(
            rt.cameraActive.load(),
            rt.detectionRunning.load(),
            modelStatus,
            rt.cameraError,
            rt.modelError);
        sendHttpResponse(clientFd, "200 OK", "application/json", json);
    } else if (method == "GET" && path == "/api/frame.jpg") {
        std::vector<unsigned char> frameBytes;
        {
            std::lock_guard<std::mutex> lock(rt.mtx);
            frameBytes = rt.latestJpegFrame;
        }
        if (frameBytes.empty()) {
            sendHttpResponse(clientFd, "404 Not Found", "text/plain", "No frame available");
        } else {
            std::string body(frameBytes.begin(), frameBytes.end());
            sendHttpResponse(clientFd, "200 OK", "image/jpeg", body);
        }
    } else if (method == "POST" && path == "/api/camera/start") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.cameraError.clear();
        if (!rt.detector.isModelLoaded()) {
            if (!rt.detector.loadModel(rt.modelPath)) {
                rt.modelError = "Failed to load YOLO ONNX model at " + rt.modelPath;
            } else {
                rt.modelError.clear();
            }
        }
        if (!rt.cameraActive.load()) {
            bool opened = rt.videoSourcePath.empty() ? rt.cap.open(0) : rt.cap.open(rt.videoSourcePath);
            if (opened && rt.cap.isOpened()) {
                rt.cameraActive.store(true);
                rt.detectionRunning.store(rt.detector.isModelLoaded());
                sendHttpResponse(clientFd, "200 OK", "application/json",
                                 "{\"ok\":true,\"cameraActive\":true}");
            } else {
                rt.cameraError = "Unable to open camera device (index 0) or video source.";
                sendHttpResponse(clientFd, "503 Service Unavailable", "application/json",
                                 "{\"ok\":false,\"error\":\"" + rt.cameraError + "\"}");
            }
        } else {
            sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true,\"cameraActive\":true}");
        }
    } else if (method == "POST" && path == "/api/camera/stop") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.detectionRunning.store(false);
        rt.cameraActive.store(false);
        if (rt.cap.isOpened()) {
            rt.cap.release();
        }
        rt.latestJpegFrame.clear();
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true,\"cameraActive\":false}");
    } else if (method == "POST" && path == "/api/simulation/start") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.controller.startSimulation();
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true}");
    } else if (method == "POST" && path == "/api/simulation/pause") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.controller.pauseSimulation();
        rt.detectionRunning.store(false);
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true}");
    } else if (method == "POST" && path == "/api/simulation/resume") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.controller.resumeSimulation();
        if (rt.cameraActive.load() && rt.detector.isModelLoaded()) {
            rt.detectionRunning.store(true);
        }
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true}");
    } else if (method == "POST" && path == "/api/simulation/stop") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.controller.stopSimulation();
        rt.detectionRunning.store(false);
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true}");
    } else if (method == "POST" && path == "/api/pedestrian/start") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.controller.requestPedestrianCrossing();
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true}");
    } else if (method == "POST" && path == "/api/reset") {
        std::lock_guard<std::mutex> lock(rt.mtx);
        rt.controller.reset();
        rt.tracker.reset();
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true,\"reset\":true}");
    } else if (method == "POST" && path.rfind("/api/emergency/exited/", 0) == 0) {
        std::lock_guard<std::mutex> lock(rt.mtx);
        std::string dirStr = path.substr(22);
        Direction dir = Direction::NORTH;
        if (dirStr == "South") dir = Direction::SOUTH;
        else if (dirStr == "East") dir = Direction::EAST;
        else if (dirStr == "West") dir = Direction::WEST;

        rt.controller.notifyEmergencyVehicleExited(dir);
        sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true,\"exited\":true}");
    } else if (method == "POST" && path.rfind("/api/emergency/", 0) == 0) {
        std::lock_guard<std::mutex> lock(rt.mtx);
        std::string rest = path.substr(15);
        size_t slash = rest.find('/');
        if (slash != std::string::npos) {
            std::string dirStr = rest.substr(0, slash);
            std::string typeStr = rest.substr(slash + 1);
            Direction dir = Direction::NORTH;
            if (dirStr == "South") dir = Direction::SOUTH;
            else if (dirStr == "East") dir = Direction::EAST;
            else if (dirStr == "West") dir = Direction::WEST;

            EmergencyType eType = EmergencyType::NONE;
            if (typeStr == "AMBULANCE") eType = EmergencyType::AMBULANCE;
            else if (typeStr == "FIRE_ENGINE") eType = EmergencyType::FIRE_ENGINE;

            rt.controller.setRoadEmergency(dir, eType);
            sendHttpResponse(clientFd, "200 OK", "application/json", "{\"ok\":true}");
        } else {
            sendHttpResponse(clientFd, "400 Bad Request", "application/json", "{\"ok\":false}");
        }
    } else {
        sendHttpResponse(clientFd, "404 Not Found", "application/json", "{\"error\":\"Endpoint not found\"}");
    }

    close(clientFd);
}

int main(int argc, char** argv) {
    EngineRuntime runtime;

    if (argc > 1) {
        runtime.modelPath = argv[1];
    }
    if (argc > 2) {
        runtime.videoSourcePath = argv[2];
    }

    std::cout << "=== Smart Traffic Signal Management System (C++11 + OpenCV + YOLO ONNX) ===" << std::endl;
    if (runtime.detector.loadModel(runtime.modelPath)) {
        std::cout << "[OK] Loaded YOLO ONNX model: " << runtime.modelPath << std::endl;
    } else {
        runtime.modelError = "YOLO ONNX model not found at " + runtime.modelPath;
        std::cout << "[WARN] " << runtime.modelError << std::endl;
    }

    // Thread 1: Centralized 1-second Traffic Signal State Machine Loop
    std::thread signalThread([&runtime]() {
        while (runtime.running.load()) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            std::lock_guard<std::mutex> lock(runtime.mtx);
            runtime.controller.tickSecond();
        }
    });

    // Thread 2: Controlled-interval OpenCV Camera & YOLO ONNX Detection Loop (10 FPS / 100ms)
    std::thread detectionThread([&runtime]() {
        cv::Mat frame;
        while (runtime.running.load()) {
            if (!runtime.cameraActive.load()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                continue;
            }

            bool hasFrame = false;
            {
                std::lock_guard<std::mutex> lock(runtime.mtx);
                if (runtime.cap.isOpened()) {
                    hasFrame = runtime.cap.read(frame);
                    if (!hasFrame && !runtime.videoSourcePath.empty()) {
                        runtime.cap.set(cv::CAP_PROP_POS_FRAMES, 0);
                        hasFrame = runtime.cap.read(frame);
                    }
                }
            }

            if (!hasFrame || frame.empty()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(80));
                continue;
            }

            if (runtime.detectionRunning.load() && runtime.detector.isModelLoaded()) {
                auto detections = runtime.detector.detect(frame);
                std::lock_guard<std::mutex> lock(runtime.mtx);
                auto newlyCounted = runtime.tracker.update(detections, frame.size());
                for (const auto& vehicle : newlyCounted) {
                    runtime.controller.recordDetectedVehicle(vehicle.direction, vehicle.className);
                }
                runtime.detector.drawDetections(frame, detections);
            }

            std::vector<unsigned char> encoded;
            cv::imencode(".jpg", frame, encoded);
            {
                std::lock_guard<std::mutex> lock(runtime.mtx);
                runtime.latestJpegFrame = std::move(encoded);
            }

            // Controlled 100ms interval (10 FPS) to prevent blocking CPU
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    });

    // Thread 3 (Main): HTTP/JSON Local API Server on Port 8080
    int serverFd = socket(AF_INET, SOCK_STREAM, 0);
    if (serverFd < 0) {
        std::cerr << "[ERROR] Failed to create API socket." << std::endl;
        runtime.running.store(false);
        signalThread.join();
        detectionThread.join();
        return 1;
    }

    int opt = 1;
    setsockopt(serverFd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(8080);

    if (bind(serverFd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        std::cerr << "[ERROR] Failed to bind HTTP API server on port 8080." << std::endl;
        close(serverFd);
        runtime.running.store(false);
        signalThread.join();
        detectionThread.join();
        return 1;
    }

    listen(serverFd, 16);
    std::cout << "[API] C++ Traffic Engine listening at http://localhost:8080/api/status" << std::endl;

    while (runtime.running.load()) {
        sockaddr_in clientAddr{};
        socklen_t clientLen = sizeof(clientAddr);
        int clientFd = accept(serverFd, reinterpret_cast<sockaddr*>(&clientAddr), &clientLen);
        if (clientFd >= 0) {
            handleApiRequest(clientFd, runtime);
        }
    }

    close(serverFd);
    signalThread.join();
    detectionThread.join();
    return 0;
}
