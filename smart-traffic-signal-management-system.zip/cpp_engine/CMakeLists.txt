cmake_minimum_required(VERSION 3.16)
project(SmartTrafficSignalEngine LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 11)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(OpenCV REQUIRED)
find_package(Threads REQUIRED)

include_directories(
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${OpenCV_INCLUDE_DIRS}
)

add_executable(smart_traffic_engine
    src/main.cpp
    src/Road.cpp
    src/TrafficSignal.cpp
    src/VehicleDetector.cpp
    src/VehicleTracker.cpp
    src/TrafficDensity.cpp
    src/EmergencyManager.cpp
    src/PedestrianCrossing.cpp
    src/TrafficSignalController.cpp
    src/TrafficLogger.cpp
)

target_link_libraries(smart_traffic_engine
    ${OpenCV_LIBS}
    Threads::Threads
)
