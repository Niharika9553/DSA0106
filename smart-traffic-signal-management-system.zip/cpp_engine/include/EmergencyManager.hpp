#ifndef EMERGENCY_MANAGER_HPP
#define EMERGENCY_MANAGER_HPP

#include <vector>
#include "Road.hpp"

struct EmergencyAlert {
    Direction direction;
    EmergencyType type;
    bool servedInCurrentCycle;
};

class EmergencyManager {
private:
    std::vector<EmergencyAlert> alerts_;

public:
    void registerEmergency(Direction direction, EmergencyType type);
    void clearEmergency(Direction direction);
    void clearAll();

    bool isPriorityMode() const;
    bool hasPendingEmergency() const;
    Direction getNextPriorityDirection() const;
    void markServed(Direction direction);
    void resetCycleFlags();

    const std::vector<EmergencyAlert>& getAlerts() const;
};

#endif // EMERGENCY_MANAGER_HPP
