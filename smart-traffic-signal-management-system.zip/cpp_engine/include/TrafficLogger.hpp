#ifndef TRAFFIC_LOGGER_HPP
#define TRAFFIC_LOGGER_HPP

#include <string>
#include <vector>
#include "Road.hpp"
#include "TrafficDensity.hpp"

struct CycleLogEntry {
    int cycleNumber;
    std::string timestamp;
    int counts[4];
    int greenDurations[4];
    std::vector<Direction> signalOrder;
    std::string emergencySummary;
    CongestionLevel congestionLevel;
};

class TrafficLogger {
private:
    std::string csvFilePath_;
    std::vector<CycleLogEntry> entries_;

    static std::string currentTimestamp();

public:
    explicit TrafficLogger(const std::string& csvFilePath = "traffic_history.csv");

    void logCycle(int cycleNumber,
                  const int counts[4],
                  const int greenDurations[4],
                  const std::vector<Direction>& signalOrder,
                  const std::string& emergencySummary,
                  CongestionLevel congestionLevel);

    const std::vector<CycleLogEntry>& getEntries() const;
    void clear();
};

#endif // TRAFFIC_LOGGER_HPP
