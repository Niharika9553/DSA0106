#ifndef TRAFFIC_DENSITY_HPP
#define TRAFFIC_DENSITY_HPP

#include <string>
#include <vector>
#include "Road.hpp"

enum class CongestionLevel {
    LOW = 0,
    MEDIUM = 1,
    HIGH = 2
};

struct DirectionDensity {
    Direction direction;
    int vehicleCount;
    double percentage;
    CongestionLevel status;
};

class TrafficDensity {
public:
    static std::vector<DirectionDensity> compute(const std::vector<Road>& roads);
    static int getTotalVehicles(const std::vector<Road>& roads);
    static Direction getHighestDensityDirection(const std::vector<Road>& roads);
    static CongestionLevel classifyRoadCount(int count);
    static CongestionLevel classifyIntersectionWeighted(int currentTotal, int previousTotal);
    static std::string levelToString(CongestionLevel level);
};

#endif // TRAFFIC_DENSITY_HPP
