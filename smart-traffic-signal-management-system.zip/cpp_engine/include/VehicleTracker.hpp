#ifndef VEHICLE_TRACKER_HPP
#define VEHICLE_TRACKER_HPP

#include <set>
#include <vector>
#include "VehicleDetector.hpp"

struct TrackedVehicle {
    int trackId;
    cv::Rect box;
    cv::Point centroid;
    cv::Point prevCentroid;
    std::string className;
    float confidence;
    Direction direction;
    int framesMissing;
    bool counted;
};

class VehicleTracker {
private:
    int nextTrackId_;
    int maxMissingFrames_;
    double maxCentroidDistance_;
    std::vector<TrackedVehicle> activeTracks_;
    std::set<int> countedTrackIds_;

    bool crossedVirtualCountingLine(const TrackedVehicle& track, const cv::Size& frameSize) const;

public:
    VehicleTracker(int maxMissingFrames = 12, double maxCentroidDistance = 65.0);

    // Updates tracks and returns only vehicles newly crossing their directional virtual counting line/zone
    std::vector<TrackedVehicle> update(const std::vector<Detection>& detections, const cv::Size& frameSize);
    const std::vector<TrackedVehicle>& getActiveTracks() const;
    void reset();
};

#endif // VEHICLE_TRACKER_HPP
