#ifndef TRAFFIC_SIGNAL_CONTROLLER_HPP
#define TRAFFIC_SIGNAL_CONTROLLER_HPP

#include <string>
#include <vector>
#include "EmergencyManager.hpp"
#include "PedestrianCrossing.hpp"
#include "Road.hpp"
#include "TrafficDensity.hpp"
#include "TrafficLogger.hpp"
#include "TrafficSignal.hpp"

enum class ControllerPhase {
    IDLE = 0,
    GREEN = 1,
    YELLOW = 2,
    ALL_RED_CLEARANCE = 3,
    PEDESTRIAN_WALK = 4
};

class TrafficSignalController {
private:
    std::vector<Road> roads_;
    std::vector<TrafficSignal> signals_;
    EmergencyManager emergencyManager_;
    PedestrianCrossing pedestrian_;
    TrafficLogger logger_;

    ControllerPhase phase_;
    Direction activeDirection_;
    int clearanceRemainingSeconds_;
    int cycleNumber_;
    int previousCycleVehicles_;
    bool intersectionOccupied_;
    bool paused_;
    bool stopped_;
    bool pendingPedestrian_;
    bool emergencyClearancePending_;
    Direction lastEmergencyDirection_;

    std::vector<Direction> cycleQueue_;
    size_t queueIndex_;
    std::vector<Direction> servedOrder_;
    int allocatedDurations_[4];

    void buildCycleQueue();
    void analyzeLatestDensityAndBuildSchedule(Direction lastServed);
    void startDirectionGreen(Direction dir);
    void setAllSignalsRed();
    void completeCycleAndRestart();

public:
    TrafficSignalController();

    void recordDetectedVehicle(Direction dir, const std::string& vehicleClass);
    void setRoadCountManual(Direction dir, int count);
    void setRoadEmergency(Direction dir, EmergencyType type);
    void notifyEmergencyVehicleExited(Direction dir);
    void setIntersectionOccupied(bool occupied);

    void startSimulation();
    void pauseSimulation();
    void resumeSimulation();
    void stopSimulation();
    void requestPedestrianCrossing();
    void reset();

    void tickSecond();

    ControllerPhase getPhase() const;
    Direction getActiveDirection() const;
    bool isPaused() const;
    bool isStopped() const;
    int getCycleNumber() const;
    const std::vector<Road>& getRoads() const;
    const std::vector<TrafficSignal>& getSignals() const;
    const EmergencyManager& getEmergencyManager() const;
    const PedestrianCrossing& getPedestrianCrossing() const;

    std::string toJsonStatus(bool cameraActive,
                             bool detectionRunning,
                             const std::string& modelStatus,
                             const std::string& cameraError,
                             const std::string& modelError) const;
};

#endif // TRAFFIC_SIGNAL_CONTROLLER_HPP
