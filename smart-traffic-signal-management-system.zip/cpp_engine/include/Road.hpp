#ifndef ROAD_HPP
#define ROAD_HPP

#include <opencv2/core.hpp>
#include <string>

enum class Direction {
    NORTH = 0,
    SOUTH = 1,
    EAST = 2,
    WEST = 3
};

enum class EmergencyType {
    NONE = 0,
    AMBULANCE = 1,
    FIRE_ENGINE = 2
};

class Road {
private:
    Direction direction_;
    std::string name_;
    cv::Rect detectionROI_;
    int vehicleCount_;
    int carCount_;
    int busCount_;
    int truckCount_;
    int motorcycleCount_;
    EmergencyType emergency_;

public:
    Road(Direction direction, const std::string& name, const cv::Rect& roi);

    Direction getDirection() const;
    std::string getName() const;
    cv::Rect getDetectionROI() const;
    void setDetectionROI(const cv::Rect& roi);

    void incrementVehicle(const std::string& vehicleClass);
    void resetCounts();

    int getVehicleCount() const;
    int getCarCount() const;
    int getBusCount() const;
    int getTruckCount() const;
    int getMotorcycleCount() const;

    void setEmergency(EmergencyType type);
    EmergencyType getEmergency() const;
    bool hasEmergency() const;

    static std::string directionToString(Direction dir);
    static std::string emergencyToString(EmergencyType type);
};

#endif // ROAD_HPP
