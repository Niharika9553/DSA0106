#ifndef VEHICLE_DETECTOR_HPP
#define VEHICLE_DETECTOR_HPP

#include <opencv2/dnn.hpp>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include "Road.hpp"

struct Detection {
    cv::Rect box;
    int classId;
    std::string className;
    float confidence;
    Direction direction;
};

class VehicleDetector {
private:
    cv::dnn::Net net_;
    bool modelLoaded_;
    float confThreshold_;
    float nmsThreshold_;
    int inputWidth_;
    int inputHeight_;
    std::vector<std::string> classNames_;

    Direction classifyDirection(const cv::Point& center, const cv::Size& frameSize) const;

public:
    VehicleDetector(float confThreshold = 0.40f, float nmsThreshold = 0.45f);

    bool loadModel(const std::string& onnxModelPath);
    bool isModelLoaded() const;

    std::vector<Detection> detect(const cv::Mat& frame);
    void drawDetections(cv::Mat& frame, const std::vector<Detection>& detections) const;
};

#endif // VEHICLE_DETECTOR_HPP
