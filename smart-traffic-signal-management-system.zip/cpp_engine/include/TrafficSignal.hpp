#ifndef TRAFFIC_SIGNAL_HPP
#define TRAFFIC_SIGNAL_HPP

#include <string>
#include "Road.hpp"

enum class SignalState {
    RED = 0,
    GREEN = 1,
    YELLOW = 2
};

class TrafficSignal {
private:
    Direction direction_;
    SignalState state_;
    int remainingSeconds_;
    int allocatedGreenSeconds_;

public:
    explicit TrafficSignal(Direction direction);

    Direction getDirection() const;
    SignalState getState() const;
    int getRemainingSeconds() const;
    int getAllocatedGreenSeconds() const;

    void setGreen(int durationSeconds);
    void setYellow(int durationSeconds);
    void setRed();
    void decrementSecond();

    // Formula: Green Time = Vehicle Count * 2 seconds (no 60s cap).
    // Emergency priority receives at least 20s if count * 2 < 20.
    static int calculateGreenDuration(int vehicleCount, bool isEmergency);
    static std::string stateToString(SignalState state);
};

#endif // TRAFFIC_SIGNAL_HPP
