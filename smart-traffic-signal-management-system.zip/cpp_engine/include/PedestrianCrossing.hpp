#ifndef PEDESTRIAN_CROSSING_HPP
#define PEDESTRIAN_CROSSING_HPP

class PedestrianCrossing {
private:
    bool active_;
    int durationSeconds_;
    int remainingSeconds_;

public:
    explicit PedestrianCrossing(int durationSeconds = 15);

    void activate();
    void deactivate();
    void tick();

    bool isActive() const;
    int getRemainingSeconds() const;
    int getDurationSeconds() const;
};

#endif // PEDESTRIAN_CROSSING_HPP
