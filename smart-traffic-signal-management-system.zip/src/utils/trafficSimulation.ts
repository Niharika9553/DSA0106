import {
  EmergencyEventInfo,
  EmergencyResolutionInfo,
  EmergencyType,
  OperatingMode,
  RoadDirection,
  RoadInput,
  ScheduledRoad,
  SignalColor,
  SimVehicle,
  SimulationPhase,
  SimulationSpeed,
  SimulationStatus,
  TrafficCycleRecord,
  VehicleClass,
} from '../types/traffic';
import {
  ALL_RED_CLEARANCE_SECONDS,
  analyzeLatestTrafficDensity,
  buildRoadInputFromCount,
  buildSignalSchedule,
  calculateCongestion,
  calculateGreenDuration,
  createZeroRoadsState,
  getTotalVehicles,
  INITIAL_ROADS_STATE,
  PEDESTRIAN_DURATION_SECONDS,
  ROAD_DIRECTIONS,
  YELLOW_CLEARANCE_SECONDS,
} from './trafficEngine';

export const STOP_LINE_POS = -112;
export const INTERSECTION_EXIT_POS = 84;
export const LANE_ENTRY_POS = -355;
export const LANE_DESPAWN_POS = 405;
export const SAFE_FOLLOW_GAP = 14;

export interface TrafficControllerState {
  operatingMode: OperatingMode;
  simulationStatus: SimulationStatus;
  speed: SimulationSpeed;
  roads: Record<RoadDirection, RoadInput>;
  schedule: ScheduledRoad[];
  activeDirection: RoadDirection | null;
  phase: SimulationPhase;
  secondsRemaining: number;
  phaseTotalSeconds: number;
  servedDirections: RoadDirection[];
  lastServedDirection: RoadDirection | null;
  activeEmergency: EmergencyEventInfo | null;
  lastEmergencyResolution: EmergencyResolutionInfo | null;
  pendingPedestrian: boolean;
  emergencyExitTriggered: RoadDirection | null;
  postEmergencyDensityPending: RoadDirection | null;
  vehicles: SimVehicle[];
  crossedByDir: Record<RoadDirection, number>;
  totalCrossed: number;
  history: TrafficCycleRecord[];
  clockAccum: number;
  nextVehicleId: number;
}

export function getVehicleDimensions(
  vClass: VehicleClass,
  emergency: EmergencyType
): { length: number; width: number; maxSpeed: number } {
  if (emergency !== 'NONE') {
    return { length: 34, width: 18, maxSpeed: 135 };
  }
  switch (vClass) {
    case 'bus':
      return { length: 42, width: 19, maxSpeed: 90 };
    case 'truck':
      return { length: 38, width: 19, maxSpeed: 94 };
    case 'motorcycle':
      return { length: 18, width: 10, maxSpeed: 122 };
    case 'car':
    default:
      return { length: 26, width: 16, maxSpeed: 112 };
  }
}

export function getLaneLabel(dir: RoadDirection): string {
  switch (dir) {
    case 'North':
      return 'NB-Inbound (Southbound)';
    case 'South':
      return 'SB-Inbound (Northbound)';
    case 'East':
      return 'EB-Inbound (Westbound)';
    case 'West':
      return 'WB-Inbound (Eastbound)';
  }
}

/**
 * Spawns queued vehicles for each direction behind the stop line AND strictly behind
 * the rearmost clearing vehicle (passedStopLine === true) in that direction so vehicles
 * never overlap or block clearing traffic.
 */
export function buildQueueVehiclesSafely(
  roads: Record<RoadDirection, RoadInput>,
  clearingVehicles: SimVehicle[],
  nextIdBox: { nextVehicleId: number }
): SimVehicle[] {
  const list: SimVehicle[] = [];

  for (const dir of ROAD_DIRECTIONS) {
    const road = roads[dir];
    const hasEmergency = road.emergency !== 'NONE';
    const totalToSpawn = hasEmergency && road.vehicleCount === 0 ? 1 : road.vehicleCount;

    let cursorPos = STOP_LINE_POS - 8;

    const dirClearing = clearingVehicles.filter((v) => v.direction === dir);
    if (dirClearing.length > 0) {
      let minRear = Infinity;
      for (const cv of dirClearing) {
        const rear = cv.position - cv.length;
        if (rear < minRear) minRear = rear;
      }
      if (minRear - SAFE_FOLLOW_GAP < cursorPos) {
        cursorPos = minRear - SAFE_FOLLOW_GAP;
      }
    }

    for (let i = 0; i < totalToSpawn; i++) {
      let vClass: VehicleClass = 'car';
      if (i < road.classCounts.bus) vClass = 'bus';
      else if (i < road.classCounts.bus + road.classCounts.truck) vClass = 'truck';
      else if (
        i <
        road.classCounts.bus + road.classCounts.truck + road.classCounts.motorcycle
      ) {
        vClass = 'motorcycle';
      }

      const emergency: EmergencyType = i === 0 && hasEmergency ? road.emergency : 'NONE';
      const dims = getVehicleDimensions(vClass, emergency);

      list.push({
        id: nextIdBox.nextVehicleId++,
        direction: dir,
        lane: getLaneLabel(dir),
        vehicleClass: vClass,
        emergency,
        position: cursorPos,
        speed: 0,
        targetPosition: LANE_DESPAWN_POS,
        stoppingPosition: STOP_LINE_POS - 4,
        movementState: 'QUEUED',
        length: dims.length,
        width: dims.width,
        passedStopLine: false,
      });

      cursorPos -= dims.length + SAFE_FOLLOW_GAP;
    }
  }

  return list;
}

export function createInitialControllerState(
  initialHistory: TrafficCycleRecord[],
  operatingMode: OperatingMode = 'MANUAL'
): TrafficControllerState {
  const roads = operatingMode === 'CAMERA' ? createZeroRoadsState() : INITIAL_ROADS_STATE;
  const schedule = buildSignalSchedule(roads);
  const activeQueue = schedule.filter((s) => !s.skipped);
  const first = activeQueue[0] ?? null;

  const state: TrafficControllerState = {
    operatingMode,
    simulationStatus: 'RUNNING',
    speed: 1,
    roads,
    schedule,
    activeDirection: first ? first.direction : null,
    phase: first ? 'ROAD_GREEN' : 'IDLE',
    secondsRemaining: first ? first.greenDuration : 0,
    phaseTotalSeconds: first ? first.greenDuration : 0,
    servedDirections: [],
    lastServedDirection: null,
    activeEmergency: null,
    lastEmergencyResolution: null,
    pendingPedestrian: false,
    emergencyExitTriggered: null,
    postEmergencyDensityPending: null,
    vehicles: [],
    crossedByDir: { North: 0, South: 0, East: 0, West: 0 },
    totalCrossed: 0,
    history: initialHistory,
    clockAccum: 0,
    nextVehicleId: 1,
  };

  state.vehicles = buildQueueVehiclesSafely(roads, [], state);
  return state;
}

export function computeRoadSignals(
  ctrl: Pick<TrafficControllerState, 'simulationStatus' | 'phase' | 'activeDirection'>
): Record<RoadDirection, SignalColor> {
  const map: Record<RoadDirection, SignalColor> = {
    North: 'RED',
    South: 'RED',
    East: 'RED',
    West: 'RED',
  };

  if (ctrl.simulationStatus === 'STOPPED') {
    return map;
  }

  if (ctrl.phase === 'ROAD_GREEN' && ctrl.activeDirection) {
    map[ctrl.activeDirection] = 'GREEN';
  } else if (ctrl.phase === 'ROAD_YELLOW' && ctrl.activeDirection) {
    map[ctrl.activeDirection] = 'YELLOW';
  }

  return map;
}

export function countInsideIntersection(vehicles: SimVehicle[]): number {
  let inside = 0;
  for (const v of vehicles) {
    if (v.position > STOP_LINE_POS && v.position - v.length < INTERSECTION_EXIT_POS) {
      inside += 1;
    }
  }
  return inside;
}

export function countQueuedByDirection(vehicles: SimVehicle[]): Record<RoadDirection, number> {
  const queued: Record<RoadDirection, number> = { North: 0, South: 0, East: 0, West: 0 };
  for (const v of vehicles) {
    if (!v.passedStopLine) {
      queued[v.direction] += 1;
    }
  }
  return queued;
}

export function spawnPhysicalVehicleInCtrl(
  ctrl: TrafficControllerState,
  direction: RoadDirection,
  vehicleClass: VehicleClass,
  emergency: EmergencyType
): void {
  const dims = getVehicleDimensions(vehicleClass, emergency);
  const sameLane = ctrl.vehicles.filter((v) => v.direction === direction);
  let spawnPos = LANE_ENTRY_POS;

  if (sameLane.length > 0) {
    const rearmost = sameLane.reduce((minV, item) =>
      item.position - item.length < minV.position - minV.length ? item : minV
    );
    const rearBumper = rearmost.position - rearmost.length;
    if (rearBumper - SAFE_FOLLOW_GAP < spawnPos) {
      spawnPos = rearBumper - SAFE_FOLLOW_GAP;
    }
  }

  ctrl.vehicles.push({
    id: ctrl.nextVehicleId++,
    direction,
    lane: getLaneLabel(direction),
    vehicleClass,
    emergency,
    position: spawnPos,
    speed: 0,
    targetPosition: LANE_DESPAWN_POS,
    stoppingPosition: STOP_LINE_POS - 4,
    movementState: 'QUEUED',
    length: dims.length,
    width: dims.width,
    passedStopLine: false,
  });
}

function enterYellowPhase(ctrl: TrafficControllerState, dir: RoadDirection | null): void {
  ctrl.phase = 'ROAD_YELLOW';
  ctrl.activeDirection = dir;
  ctrl.secondsRemaining = YELLOW_CLEARANCE_SECONDS;
  ctrl.phaseTotalSeconds = YELLOW_CLEARANCE_SECONDS;
  ctrl.clockAccum = 0;
}

function enterRedClearanceOnce(ctrl: TrafficControllerState): void {
  ctrl.phase = 'RED_CLEARANCE';
  ctrl.activeDirection = null;
  ctrl.secondsRemaining = ALL_RED_CLEARANCE_SECONDS;
  ctrl.phaseTotalSeconds = ALL_RED_CLEARANCE_SECONDS;
  ctrl.clockAccum = 0;
}

function releaseEmergencyAndAnalyze(
  ctrl: TrafficControllerState,
  exitedDir: RoadDirection,
  emgType: Exclude<EmergencyType, 'NONE'>
): void {
  const cleanedRoads: Record<RoadDirection, RoadInput> = {
    ...ctrl.roads,
    [exitedDir]: { ...ctrl.roads[exitedDir], emergency: 'NONE' },
  };
  const analysis = analyzeLatestTrafficDensity(cleanedRoads, exitedDir);

  ctrl.activeEmergency = null;
  ctrl.roads = cleanedRoads;
  ctrl.schedule = analysis.schedule;
  ctrl.servedDirections = [];
  ctrl.lastServedDirection = exitedDir;
  ctrl.postEmergencyDensityPending = exitedDir;
  ctrl.lastEmergencyResolution = {
    exitedDirection: exitedDir,
    emergencyType: emgType,
    nextDirection: analysis.highestDirection,
    nextGreenDuration: analysis.highestGreenDuration,
    latestCounts: analysis.latestCounts,
    timestamp: new Date().toISOString(),
  };
}

/**
 * Transitions out of RED_CLEARANCE once the safety countdown has finished (<= 0)
 * AND no vehicle remains inside the intersection box.
 * Returns true if a transition occurred.
 */
export function tryResolveRedClearance(ctrl: TrafficControllerState): boolean {
  if (ctrl.phase !== 'RED_CLEARANCE' || ctrl.simulationStatus !== 'RUNNING') {
    return false;
  }
  if (ctrl.secondsRemaining > 0) {
    return false;
  }
  if (countInsideIntersection(ctrl.vehicles) > 0) {
    return false;
  }

  // Priority 1: Pending Pedestrian Crossing
  if (ctrl.pendingPedestrian) {
    ctrl.pendingPedestrian = false;
    ctrl.phase = 'PEDESTRIAN_CROSSING';
    ctrl.activeDirection = null;
    ctrl.secondsRemaining = PEDESTRIAN_DURATION_SECONDS;
    ctrl.phaseTotalSeconds = PEDESTRIAN_DURATION_SECONDS;
    ctrl.clockAccum = 0;
    return true;
  }

  // Priority 2: Pending Emergency Preemption
  if (ctrl.activeEmergency && ctrl.activeEmergency.pending) {
    const emgDir = ctrl.activeEmergency.direction;
    const latestSched = buildSignalSchedule(ctrl.roads, ctrl.lastServedDirection);
    ctrl.schedule = latestSched;
    const duration = calculateGreenDuration(
      ctrl.roads[emgDir].vehicleCount,
      ctrl.activeEmergency.type
    );
    ctrl.emergencyExitTriggered = null;
    ctrl.activeEmergency = { ...ctrl.activeEmergency, pending: false };
    ctrl.phase = 'ROAD_GREEN';
    ctrl.activeDirection = emgDir;
    ctrl.secondsRemaining = duration;
    ctrl.phaseTotalSeconds = duration;
    ctrl.clockAccum = 0;
    return true;
  }

  // Priority 3: Immediate Post-Emergency Latest 4-Direction Density Selection
  if (ctrl.postEmergencyDensityPending !== null) {
    const exitedDir = ctrl.postEmergencyDensityPending;
    ctrl.postEmergencyDensityPending = null;

    const latestAnalysis = analyzeLatestTrafficDensity(ctrl.roads, exitedDir);
    ctrl.schedule = latestAnalysis.schedule;
    ctrl.servedDirections = [];

    if (!latestAnalysis.hasTraffic) {
      ctrl.phase = 'IDLE';
      ctrl.activeDirection = null;
      ctrl.secondsRemaining = 0;
      ctrl.phaseTotalSeconds = 0;
      ctrl.clockAccum = 0;
      return true;
    }

    const highest = latestAnalysis.activeQueue[0];
    ctrl.phase = 'ROAD_GREEN';
    ctrl.activeDirection = highest.direction;
    ctrl.secondsRemaining = highest.greenDuration;
    ctrl.phaseTotalSeconds = highest.greenDuration;
    ctrl.clockAccum = 0;
    return true;
  }

  // Priority 4: Read latest 4-direction counts & select highest-density unserved eligible direction
  const latestSched = buildSignalSchedule(ctrl.roads, ctrl.lastServedDirection);
  ctrl.schedule = latestSched;
  const activeQueue = latestSched.filter((item) => !item.skipped);
  const nextRoad = activeQueue.find(
    (item) => !ctrl.servedDirections.includes(item.direction)
  );

  if (nextRoad) {
    ctrl.phase = 'ROAD_GREEN';
    ctrl.activeDirection = nextRoad.direction;
    ctrl.secondsRemaining = nextRoad.greenDuration;
    ctrl.phaseTotalSeconds = nextRoad.greenDuration;
    ctrl.clockAccum = 0;
    return true;
  }

  // All eligible directions served -> complete cycle, log record, and evaluate next cycle
  const prevTotal =
    ctrl.history.length > 0 ? ctrl.history[ctrl.history.length - 1].totalVehicles : null;
  const total = getTotalVehicles(ctrl.roads);
  const congestion = calculateCongestion(total, prevTotal);
  const greenDurations: Record<RoadDirection, number> = {
    North: 0,
    South: 0,
    East: 0,
    West: 0,
  };
  for (const item of latestSched) {
    greenDurations[item.direction] = item.greenDuration;
  }

  const nextCycleNum =
    ctrl.history.length > 0 ? ctrl.history[ctrl.history.length - 1].cycleNumber + 1 : 1;

  const record: TrafficCycleRecord = {
    id: `cycle-${Date.now()}-${nextCycleNum}`,
    cycleNumber: nextCycleNum,
    timestamp: new Date().toISOString(),
    vehicleCounts: {
      North: ctrl.roads.North.vehicleCount,
      South: ctrl.roads.South.vehicleCount,
      East: ctrl.roads.East.vehicleCount,
      West: ctrl.roads.West.vehicleCount,
    },
    totalVehicles: total,
    signalOrder: [...ctrl.servedDirections],
    greenDurations,
    emergencies: ctrl.activeEmergency
      ? [{ direction: ctrl.activeEmergency.direction, type: ctrl.activeEmergency.type }]
      : [],
    congestionLevel: congestion.level,
    weightedScore: congestion.weightedScore,
    pedestrianDuration: PEDESTRIAN_DURATION_SECONDS,
    sourceMode: ctrl.operatingMode === 'CAMERA' ? 'CAMERA MODE' : 'MANUAL MODE',
  };

  ctrl.history = [...ctrl.history, record];
  ctrl.servedDirections = [];

  if (activeQueue.length === 0) {
    ctrl.phase = 'IDLE';
    ctrl.activeDirection = null;
    ctrl.secondsRemaining = 0;
    ctrl.phaseTotalSeconds = 0;
    ctrl.clockAccum = 0;
    return true;
  }

  const first = activeQueue[0];
  ctrl.phase = 'ROAD_GREEN';
  ctrl.activeDirection = first.direction;
  ctrl.secondsRemaining = first.greenDuration;
  ctrl.phaseTotalSeconds = first.greenDuration;
  ctrl.clockAccum = 0;

  if (ctrl.operatingMode === 'MANUAL') {
    const clearing = ctrl.vehicles.filter((v) => v.passedStopLine);
    const freshQueue = buildQueueVehiclesSafely(ctrl.roads, clearing, ctrl);
    ctrl.vehicles = [...clearing, ...freshQueue];
  }

  return true;
}

/**
 * Advances the traffic signal state machine by exactly 1 simulation second.
 */
export function stepSignalSecond(ctrl: TrafficControllerState): void {
  if (ctrl.simulationStatus !== 'RUNNING' || ctrl.phase === 'IDLE') {
    return;
  }

  if (ctrl.phase === 'ROAD_GREEN') {
    if (ctrl.secondsRemaining > 1) {
      ctrl.secondsRemaining -= 1;
      return;
    }
    // GREEN -> YELLOW
    enterYellowPhase(ctrl, ctrl.activeDirection);
    return;
  }

  if (ctrl.phase === 'ROAD_YELLOW') {
    if (ctrl.secondsRemaining > 1) {
      ctrl.secondsRemaining -= 1;
      return;
    }
    // YELLOW -> ALL-RED CLEARANCE
    const currDir = ctrl.activeDirection;
    if (currDir) {
      if (!ctrl.servedDirections.includes(currDir)) {
        ctrl.servedDirections = [...ctrl.servedDirections, currDir];
      }
      ctrl.lastServedDirection = currDir;

      // Fallback if emergency green expired before early exit detection triggered
      if (
        ctrl.activeEmergency &&
        ctrl.activeEmergency.direction === currDir &&
        !ctrl.activeEmergency.pending
      ) {
        releaseEmergencyAndAnalyze(ctrl, currDir, ctrl.activeEmergency.type);
      }
    }

    enterRedClearanceOnce(ctrl);
    return;
  }

  if (ctrl.phase === 'RED_CLEARANCE') {
    if (ctrl.secondsRemaining > 0) {
      ctrl.secondsRemaining -= 1;
    }
    tryResolveRedClearance(ctrl);
    return;
  }

  if (ctrl.phase === 'PEDESTRIAN_CROSSING') {
    if (ctrl.secondsRemaining > 1) {
      ctrl.secondsRemaining -= 1;
      return;
    }

    // Pedestrian WALK complete -> safe transition back to highest-density / emergency GREEN
    const nextSched = buildSignalSchedule(ctrl.roads, ctrl.lastServedDirection);
    const nextActive = nextSched.filter((item) => !item.skipped);
    ctrl.schedule = nextSched;
    ctrl.servedDirections = [];

    if (ctrl.activeEmergency && ctrl.activeEmergency.pending) {
      const emgDir = ctrl.activeEmergency.direction;
      const duration = calculateGreenDuration(
        ctrl.roads[emgDir].vehicleCount,
        ctrl.activeEmergency.type
      );
      ctrl.emergencyExitTriggered = null;
      ctrl.activeEmergency = { ...ctrl.activeEmergency, pending: false };
      ctrl.phase = 'ROAD_GREEN';
      ctrl.activeDirection = emgDir;
      ctrl.secondsRemaining = duration;
      ctrl.phaseTotalSeconds = duration;
      ctrl.clockAccum = 0;
    } else if (nextActive.length > 0) {
      ctrl.phase = 'ROAD_GREEN';
      ctrl.activeDirection = nextActive[0].direction;
      ctrl.secondsRemaining = nextActive[0].greenDuration;
      ctrl.phaseTotalSeconds = nextActive[0].greenDuration;
      ctrl.clockAccum = 0;
    } else {
      ctrl.phase = 'IDLE';
      ctrl.activeDirection = null;
      ctrl.secondsRemaining = 0;
      ctrl.phaseTotalSeconds = 0;
      ctrl.clockAccum = 0;
    }
  }
}

export interface SimulationStepEvents {
  emergencyExited: { direction: RoadDirection; type: Exclude<EmergencyType, 'NONE'> } | null;
  stateChanged: boolean;
}

/**
 * Steps both vehicle physics AND the 1-second traffic signal clock using a single
 * authoritative delta-time frame step. Zero duplicate timers, zero stale React state.
 */
export function stepSimulationFrame(
  ctrl: TrafficControllerState,
  rawDtSeconds: number
): SimulationStepEvents {
  const events: SimulationStepEvents = {
    emergencyExited: null,
    stateChanged: false,
  };

  if (ctrl.simulationStatus === 'STOPPED') {
    for (const v of ctrl.vehicles) {
      if (v.speed !== 0 || v.movementState !== 'QUEUED') {
        v.speed = 0;
        v.movementState = 'QUEUED';
      }
    }
    return events;
  }

  if (ctrl.simulationStatus !== 'RUNNING') {
    return events;
  }

  const dt = rawDtSeconds * ctrl.speed;
  const signals = computeRoadSignals(ctrl);
  let emergencyExitedThisFrame = false;

  if (ctrl.vehicles.length > 0) {
    let hasDespawn = false;

    for (const dir of ROAD_DIRECTIONS) {
      const laneVehicles = ctrl.vehicles
        .filter((v) => v.direction === dir)
        .sort((a, b) => b.position - a.position);

      const signal = signals[dir];
      const isPed = ctrl.phase === 'PEDESTRIAN_CROSSING';
      const mustStopAtLine = signal === 'RED' || signal === 'YELLOW' || isPed;

      let ahead: SimVehicle | null = null;

      for (const v of laneVehicles) {
        const dims = getVehicleDimensions(v.vehicleClass, v.emergency);
        const accel = 165;
        const decel = 270;

        let maxFrontLimit = LANE_DESPAWN_POS + dims.length + 40;
        if (!v.passedStopLine && mustStopAtLine) {
          maxFrontLimit = Math.min(maxFrontLimit, STOP_LINE_POS - 4);
        }
        if (ahead) {
          const aheadRear = ahead.position - ahead.length;
          maxFrontLimit = Math.min(maxFrontLimit, aheadRear - SAFE_FOLLOW_GAP);
        }

        const distToLimit = maxFrontLimit - v.position;
        let nextSpeed = v.speed;

        if (distToLimit <= 0.5) {
          nextSpeed = 0;
        } else {
          const stopDist = (v.speed * v.speed) / (2 * decel);
          if (distToLimit <= stopDist + 4) {
            nextSpeed = Math.max(0, v.speed - decel * dt);
          } else {
            nextSpeed = Math.min(dims.maxSpeed, v.speed + accel * dt);
          }
        }

        let nextPos = v.position + nextSpeed * dt;
        if (nextPos > maxFrontLimit) {
          nextPos = maxFrontLimit;
          nextSpeed = 0;
        }

        const nextPassed = v.passedStopLine || nextPos > STOP_LINE_POS;
        const movementState =
          nextSpeed < 2
            ? 'QUEUED'
            : nextPos > INTERSECTION_EXIT_POS
            ? 'CLEARED'
            : nextPassed
            ? 'CROSSING'
            : 'ACCELERATING';

        v.position = nextPos;
        v.speed = nextSpeed;
        v.stoppingPosition = maxFrontLimit;
        v.movementState = movementState;
        v.passedStopLine = nextPassed;

        if (nextPos - v.length >= LANE_DESPAWN_POS) {
          ctrl.crossedByDir[dir] += 1;
          ctrl.totalCrossed += 1;
          hasDespawn = true;
          if (v.emergency !== 'NONE') {
            emergencyExitedThisFrame = true;
          }
        } else {
          ahead = v;
        }
      }
    }

    if (hasDespawn) {
      ctrl.vehicles = ctrl.vehicles.filter((v) => v.position - v.length < LANE_DESPAWN_POS);
    }
  }

  // Event-driven emergency exit detection: fires immediately once emergency vehicle clears +84
  if (
    ctrl.phase === 'ROAD_GREEN' &&
    ctrl.activeEmergency &&
    !ctrl.activeEmergency.pending &&
    ctrl.activeDirection === ctrl.activeEmergency.direction &&
    ctrl.emergencyExitTriggered !== ctrl.activeEmergency.direction
  ) {
    const emgDir = ctrl.activeEmergency.direction;
    const emgType = ctrl.activeEmergency.type;
    const emgVehicles = ctrl.vehicles.filter(
      (v) => v.direction === emgDir && v.emergency !== 'NONE'
    );
    const stillBeforeOrInside = emgVehicles.some(
      (v) => v.position - v.length < INTERSECTION_EXIT_POS
    );
    const hasExitedVehicle =
      emergencyExitedThisFrame ||
      emgVehicles.some((v) => v.position - v.length >= INTERSECTION_EXIT_POS);

    if (!stillBeforeOrInside && hasExitedVehicle) {
      ctrl.emergencyExitTriggered = emgDir;
      releaseEmergencyAndAnalyze(ctrl, emgDir, emgType);
      enterYellowPhase(ctrl, emgDir);
      events.emergencyExited = { direction: emgDir, type: emgType };
      events.stateChanged = true;
      return events;
    }
  }

  // If RED_CLEARANCE countdown already reached 0 and the last vehicle just exited, resolve immediately
  if (ctrl.phase === 'RED_CLEARANCE' && ctrl.secondsRemaining <= 0) {
    if (tryResolveRedClearance(ctrl)) {
      events.stateChanged = true;
    }
  }

  // Advance signal clock using the single unified delta-time accumulator
  if (ctrl.phase !== 'IDLE') {
    ctrl.clockAccum += dt;
    while (ctrl.clockAccum >= 1.0) {
      ctrl.clockAccum -= 1.0;
      const beforePhase = ctrl.phase as SimulationPhase;
      const beforeDir = ctrl.activeDirection;
      const beforeSec = ctrl.secondsRemaining;
      stepSignalSecond(ctrl);
      const afterPhase = ctrl.phase as SimulationPhase;
      if (
        afterPhase !== beforePhase ||
        ctrl.activeDirection !== beforeDir ||
        ctrl.secondsRemaining !== beforeSec
      ) {
        events.stateChanged = true;
      }
      if (afterPhase === 'IDLE') {
        ctrl.clockAccum = 0;
        break;
      }
    }
  } else {
    ctrl.clockAccum = 0;
  }

  return events;
}

/**
 * Pure controller actions (no React updater nesting or split timers).
 */
export function applyManualTrafficUpdate(
  ctrl: TrafficControllerState,
  counts: Record<RoadDirection, number>
): void {
  ctrl.operatingMode = 'MANUAL';

  const nextRoads: Record<RoadDirection, RoadInput> = {
    North: buildRoadInputFromCount('North', counts.North, ctrl.roads.North.emergency),
    South: buildRoadInputFromCount('South', counts.South, ctrl.roads.South.emergency),
    East: buildRoadInputFromCount('East', counts.East, ctrl.roads.East.emergency),
    West: buildRoadInputFromCount('West', counts.West, ctrl.roads.West.emergency),
  };

  ctrl.roads = nextRoads;
  const nextSched = buildSignalSchedule(nextRoads, ctrl.lastServedDirection);
  const nextActive = nextSched.filter((s) => !s.skipped);
  ctrl.schedule = nextSched;

  // Replace queued waiting vehicles cleanly behind any vehicles currently clearing the intersection
  const clearing = ctrl.vehicles.filter((v) => v.passedStopLine);
  const newQueues = buildQueueVehiclesSafely(nextRoads, clearing, ctrl);
  ctrl.vehicles = [...clearing, ...newQueues];

  // Fresh manual input should re-evaluate all directions fairly unless currently serving a green direction
  if (ctrl.phase === 'ROAD_GREEN' && ctrl.activeDirection) {
    ctrl.servedDirections = [];
  } else {
    ctrl.servedDirections = [];
  }

  if (nextActive.length === 0) {
    const inside = countInsideIntersection(ctrl.vehicles);
    if (ctrl.phase === 'ROAD_GREEN' && ctrl.activeDirection) {
      enterYellowPhase(ctrl, ctrl.activeDirection);
    } else if (ctrl.phase !== 'PEDESTRIAN_CROSSING' && ctrl.phase !== 'ROAD_YELLOW' && inside === 0) {
      ctrl.phase = 'IDLE';
      ctrl.activeDirection = null;
      ctrl.secondsRemaining = 0;
      ctrl.phaseTotalSeconds = 0;
      ctrl.clockAccum = 0;
    }
    return;
  }

  if (ctrl.phase === 'IDLE' || ctrl.simulationStatus === 'STOPPED') {
    ctrl.simulationStatus = 'RUNNING';
    ctrl.phase = 'ROAD_GREEN';
    ctrl.activeDirection = nextActive[0].direction;
    ctrl.secondsRemaining = nextActive[0].greenDuration;
    ctrl.phaseTotalSeconds = nextActive[0].greenDuration;
    ctrl.clockAccum = 0;
    return;
  }

  if (ctrl.phase === 'ROAD_GREEN' && ctrl.activeDirection) {
    const currDir = ctrl.activeDirection;
    if (nextRoads[currDir].vehicleCount === 0 && nextRoads[currDir].emergency === 'NONE') {
      enterYellowPhase(ctrl, currDir);
    } else {
      const updatedDuration = calculateGreenDuration(
        nextRoads[currDir].vehicleCount,
        nextRoads[currDir].emergency
      );
      const elapsed = Math.max(0, ctrl.phaseTotalSeconds - ctrl.secondsRemaining);
      ctrl.phaseTotalSeconds = updatedDuration;
      ctrl.secondsRemaining = Math.max(1, updatedDuration - elapsed);
    }
  }
}

export function applySubmitEmergency(
  ctrl: TrafficControllerState,
  direction: RoadDirection,
  type: Exclude<EmergencyType, 'NONE'>
): void {
  ctrl.emergencyExitTriggered = null;
  ctrl.postEmergencyDensityPending = null;
  ctrl.lastEmergencyResolution = null;

  const updatedRoads: Record<RoadDirection, RoadInput> = {
    ...ctrl.roads,
    [direction]: { ...ctrl.roads[direction], emergency: type },
  };
  ctrl.roads = updatedRoads;
  const nextSched = buildSignalSchedule(updatedRoads, ctrl.lastServedDirection);
  ctrl.schedule = nextSched;

  // Place emergency vehicle cleanly ahead of queued vehicles and behind any clearing vehicles
  const hasEmgAhead = ctrl.vehicles.some(
    (v) =>
      v.direction === direction &&
      v.emergency !== 'NONE' &&
      v.position - v.length < INTERSECTION_EXIT_POS
  );

  if (!hasEmgAhead) {
    const dims = getVehicleDimensions('car', type);
    const shift = dims.length + SAFE_FOLLOW_GAP;
    let frontPos = STOP_LINE_POS - 8;

    const dirClearing = ctrl.vehicles.filter(
      (v) => v.direction === direction && v.passedStopLine
    );
    if (dirClearing.length > 0) {
      let minRear = Infinity;
      for (const cv of dirClearing) {
        const rear = cv.position - cv.length;
        if (rear < minRear) minRear = rear;
      }
      if (minRear - SAFE_FOLLOW_GAP < frontPos) {
        frontPos = minRear - SAFE_FOLLOW_GAP;
      }
    }

    for (const v of ctrl.vehicles) {
      if (v.direction === direction && !v.passedStopLine) {
        v.position -= shift;
      }
    }

    ctrl.vehicles.push({
      id: ctrl.nextVehicleId++,
      direction,
      lane: getLaneLabel(direction),
      vehicleClass: 'car',
      emergency: type,
      position: frontPos,
      speed: 0,
      targetPosition: LANE_DESPAWN_POS,
      stoppingPosition: STOP_LINE_POS - 4,
      movementState: 'QUEUED',
      length: dims.length,
      width: dims.width,
      passedStopLine: false,
    });
  }

  const duration = calculateGreenDuration(updatedRoads[direction].vehicleCount, type);

  if (ctrl.phase === 'IDLE' || ctrl.simulationStatus === 'STOPPED') {
    ctrl.simulationStatus = 'RUNNING';
    ctrl.activeEmergency = { direction, type, pending: false };
    ctrl.phase = 'ROAD_GREEN';
    ctrl.activeDirection = direction;
    ctrl.secondsRemaining = duration;
    ctrl.phaseTotalSeconds = duration;
    ctrl.clockAccum = 0;
  } else if (ctrl.phase === 'ROAD_GREEN') {
    if (ctrl.activeDirection && ctrl.activeDirection !== direction) {
      ctrl.activeEmergency = { direction, type, pending: true };
      enterYellowPhase(ctrl, ctrl.activeDirection);
    } else if (ctrl.activeDirection === direction) {
      ctrl.activeEmergency = { direction, type, pending: false };
      ctrl.secondsRemaining = Math.max(ctrl.secondsRemaining, duration);
      ctrl.phaseTotalSeconds = Math.max(ctrl.phaseTotalSeconds, duration);
    }
  } else {
    // Already in ROAD_YELLOW, RED_CLEARANCE, or PEDESTRIAN_CROSSING -> queue pending emergency
    ctrl.activeEmergency = { direction, type, pending: true };
  }
}

export function applyActivatePedestrian(ctrl: TrafficControllerState): void {
  if (ctrl.simulationStatus === 'STOPPED') {
    ctrl.simulationStatus = 'RUNNING';
  }
  if (ctrl.phase === 'IDLE' || ctrl.phase === 'RED_CLEARANCE') {
    if (countInsideIntersection(ctrl.vehicles) > 0) {
      ctrl.pendingPedestrian = true;
    } else {
      ctrl.pendingPedestrian = false;
      ctrl.phase = 'PEDESTRIAN_CROSSING';
      ctrl.activeDirection = null;
      ctrl.secondsRemaining = PEDESTRIAN_DURATION_SECONDS;
      ctrl.phaseTotalSeconds = PEDESTRIAN_DURATION_SECONDS;
      ctrl.clockAccum = 0;
    }
  } else if (ctrl.phase === 'ROAD_GREEN') {
    ctrl.pendingPedestrian = true;
    enterYellowPhase(ctrl, ctrl.activeDirection);
  } else if (ctrl.phase === 'ROAD_YELLOW') {
    ctrl.pendingPedestrian = true;
  }
}

export function applyRecordDetectedVehicle(
  ctrl: TrafficControllerState,
  direction: RoadDirection,
  vehicleClass: VehicleClass,
  emergency: EmergencyType = 'NONE'
): void {
  if (ctrl.simulationStatus !== 'RUNNING') return;

  const target = ctrl.roads[direction];
  const nextRoad: RoadInput = {
    ...target,
    vehicleCount: target.vehicleCount + 1,
    classCounts: {
      ...target.classCounts,
      [vehicleClass]: target.classCounts[vehicleClass] + 1,
    },
    emergency: emergency !== 'NONE' ? emergency : target.emergency,
  };
  ctrl.roads = { ...ctrl.roads, [direction]: nextRoad };
  const nextSched = buildSignalSchedule(ctrl.roads, ctrl.lastServedDirection);
  ctrl.schedule = nextSched;

  spawnPhysicalVehicleInCtrl(ctrl, direction, vehicleClass, emergency);

  if (ctrl.phase === 'IDLE') {
    const nextActive = nextSched.filter((s) => !s.skipped);
    if (nextActive.length > 0) {
      ctrl.servedDirections = [];
      ctrl.phase = 'ROAD_GREEN';
      ctrl.activeDirection = nextActive[0].direction;
      ctrl.secondsRemaining = nextActive[0].greenDuration;
      ctrl.phaseTotalSeconds = nextActive[0].greenDuration;
      ctrl.clockAccum = 0;
    }
  }
}
