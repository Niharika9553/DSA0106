import {
  CongestionLevel,
  CongestionMetrics,
  EmergencyType,
  RoadDirection,
  RoadInput,
  ScheduledRoad,
  TrafficCycleRecord,
} from '../types/traffic';

export const ROAD_DIRECTIONS: RoadDirection[] = ['North', 'South', 'East', 'West'];
export const PEDESTRIAN_DURATION_SECONDS = 15;
export const YELLOW_CLEARANCE_SECONDS = 2;
export const ALL_RED_CLEARANCE_SECONDS = 1;
export const EMERGENCY_MIN_GREEN_SECONDS = 20;

export const STORAGE_KEY_HISTORY = 'stsms_traffic_history_v3';

export const EMPTY_CLASS_COUNTS = () => ({
  car: 0,
  bus: 0,
  truck: 0,
  motorcycle: 0,
});

export function createZeroRoadsState(): Record<RoadDirection, RoadInput> {
  return {
    North: { direction: 'North', vehicleCount: 0, classCounts: EMPTY_CLASS_COUNTS(), emergency: 'NONE' },
    South: { direction: 'South', vehicleCount: 0, classCounts: EMPTY_CLASS_COUNTS(), emergency: 'NONE' },
    East: { direction: 'East', vehicleCount: 0, classCounts: EMPTY_CLASS_COUNTS(), emergency: 'NONE' },
    West: { direction: 'West', vehicleCount: 0, classCounts: EMPTY_CLASS_COUNTS(), emergency: 'NONE' },
  };
}

export function buildRoadInputFromCount(
  direction: RoadDirection,
  count: number,
  emergency: EmergencyType = 'NONE'
): RoadInput {
  const buses = Math.floor(count * 0.1);
  const trucks = Math.floor(count * 0.15);
  const motorcycles = Math.floor(count * 0.1);
  const cars = Math.max(0, count - buses - trucks - motorcycles);

  return {
    direction,
    vehicleCount: count,
    classCounts: { car: cars, bus: buses, truck: trucks, motorcycle: motorcycles },
    emergency,
  };
}

// Initial state matching proportional density demonstration (N=10 -> 20s, S=20 -> 40s, E=30 -> 60s, W=5 -> 10s)
export const INITIAL_ROADS_STATE: Record<RoadDirection, RoadInput> = {
  North: buildRoadInputFromCount('North', 10, 'NONE'),
  South: buildRoadInputFromCount('South', 20, 'NONE'),
  East: buildRoadInputFromCount('East', 30, 'NONE'),
  West: buildRoadInputFromCount('West', 5, 'NONE'),
};

export const SAMPLE_TRAFFIC_HISTORY: TrafficCycleRecord[] = [
  {
    id: 'cycle-seed-1',
    cycleNumber: 1,
    timestamp: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
    vehicleCounts: { North: 8, South: 14, East: 22, West: 6 },
    totalVehicles: 50,
    signalOrder: ['East', 'South', 'North', 'West'],
    greenDurations: { North: 16, South: 28, East: 44, West: 12 },
    emergencies: [],
    congestionLevel: 'MEDIUM',
    weightedScore: 50,
    pedestrianDuration: 15,
    sourceMode: 'MANUAL MODE',
  },
  {
    id: 'cycle-seed-2',
    cycleNumber: 2,
    timestamp: new Date(Date.now() - 1000 * 60 * 7).toISOString(),
    vehicleCounts: { North: 12, South: 18, East: 26, West: 9 },
    totalVehicles: 65,
    signalOrder: ['South', 'East', 'North', 'West'],
    greenDurations: { North: 24, South: 36, East: 52, West: 18 },
    emergencies: [{ direction: 'South', type: 'AMBULANCE' }],
    congestionLevel: 'MEDIUM',
    weightedScore: 59,
    pedestrianDuration: 15,
    sourceMode: 'MANUAL MODE',
  },
];

/**
 * Proportional Green Signal Timing Formula:
 * Green Time = Vehicle Count * 2 seconds (no artificial 60-second cap).
 * - Roads with zero vehicles are skipped (0s).
 * - Emergency roads receive at least 20s priority green (or Vehicle Count * 2 if higher).
 */
export function calculateGreenDuration(vehicleCount: number, emergency: EmergencyType): number {
  if (emergency !== 'NONE') {
    return Math.max(EMERGENCY_MIN_GREEN_SECONDS, vehicleCount * 2);
  }
  if (vehicleCount <= 0) {
    return 0;
  }
  return vehicleCount * 2;
}

/**
 * Fair density-based scheduling:
 * 1. Emergency directions first.
 * 2. Remaining non-zero directions ordered from highest density (longest green) to lowest density.
 * 3. Equal-density ties break fairly: avoid immediately repeating lastServedDirection when peers have equal count,
 *    then follow deterministic North -> South -> East -> West rotation.
 * 4. Zero-vehicle directions are skipped.
 */
export function buildSignalSchedule(
  roads: Record<RoadDirection, RoadInput>,
  lastServedDirection?: RoadDirection | null
): ScheduledRoad[] {
  const allRoads = ROAD_DIRECTIONS.map((dir) => roads[dir]);

  const compareByDensityFair = (a: RoadInput, b: RoadInput): number => {
    if (b.vehicleCount !== a.vehicleCount) {
      return b.vehicleCount - a.vehicleCount;
    }
    if (lastServedDirection) {
      if (a.direction === lastServedDirection && b.direction !== lastServedDirection) return 1;
      if (b.direction === lastServedDirection && a.direction !== lastServedDirection) return -1;
    }
    return ROAD_DIRECTIONS.indexOf(a.direction) - ROAD_DIRECTIONS.indexOf(b.direction);
  };

  const emergencyRoads = allRoads
    .filter((r) => r.emergency !== 'NONE')
    .sort(compareByDensityFair);

  const normalRoads = allRoads
    .filter((r) => r.emergency === 'NONE' && r.vehicleCount > 0)
    .sort(compareByDensityFair);

  const zeroRoads = allRoads.filter(
    (r) => r.emergency === 'NONE' && r.vehicleCount <= 0
  );

  const ordered: ScheduledRoad[] = [];
  let rank = 1;

  for (const r of emergencyRoads) {
    const label = r.emergency === 'AMBULANCE' ? 'Ambulance' : 'Fire Engine';
    ordered.push({
      direction: r.direction,
      vehicleCount: r.vehicleCount,
      emergency: r.emergency,
      greenDuration: calculateGreenDuration(r.vehicleCount, r.emergency),
      skipped: false,
      priorityRank: rank++,
      reason: `Emergency Priority (${label})`,
    });
  }

  for (const r of normalRoads) {
    ordered.push({
      direction: r.direction,
      vehicleCount: r.vehicleCount,
      emergency: 'NONE',
      greenDuration: calculateGreenDuration(r.vehicleCount, 'NONE'),
      skipped: false,
      priorityRank: rank++,
      reason: `${r.vehicleCount} vehicles × 2s = ${r.vehicleCount * 2}s`,
    });
  }

  for (const r of zeroRoads) {
    ordered.push({
      direction: r.direction,
      vehicleCount: 0,
      emergency: 'NONE',
      greenDuration: 0,
      skipped: true,
      priorityRank: 0,
      reason: 'Zero Vehicles (Skipped)',
    });
  }

  return ordered;
}

export interface DensityAnalysisResult {
  schedule: ScheduledRoad[];
  activeQueue: ScheduledRoad[];
  highestDirection: RoadDirection | null;
  highestGreenDuration: number;
  latestCounts: Record<RoadDirection, number>;
  hasTraffic: boolean;
}

/**
 * Immediate post-emergency / cycle traffic density analysis across all four directions.
 */
export function analyzeLatestTrafficDensity(
  roads: Record<RoadDirection, RoadInput>,
  lastServedDirection?: RoadDirection | null
): DensityAnalysisResult {
  const schedule = buildSignalSchedule(roads, lastServedDirection);
  const activeQueue = schedule.filter((s) => !s.skipped);
  const highest = activeQueue[0] ?? null;

  return {
    schedule,
    activeQueue,
    highestDirection: highest ? highest.direction : null,
    highestGreenDuration: highest ? highest.greenDuration : 0,
    latestCounts: {
      North: roads.North.vehicleCount,
      South: roads.South.vehicleCount,
      East: roads.East.vehicleCount,
      West: roads.West.vehicleCount,
    },
    hasTraffic: activeQueue.length > 0,
  };
}

export function classifyRoadDensityStatus(count: number): CongestionLevel {
  if (count >= 25) return 'HIGH';
  if (count >= 12) return 'MEDIUM';
  return 'LOW';
}

export function calculateCongestion(
  currentTotal: number,
  previousTotal: number | null
): CongestionMetrics {
  const weightedScore =
    previousTotal !== null
      ? Math.round(0.6 * currentTotal + 0.4 * previousTotal)
      : currentTotal;

  let level: CongestionLevel = 'LOW';
  if (weightedScore > 90) {
    level = 'HIGH';
  } else if (weightedScore >= 40) {
    level = 'MEDIUM';
  }

  const formulaText =
    previousTotal !== null
      ? `0.6 × ${currentTotal} + 0.4 × ${previousTotal} = ${weightedScore}`
      : `${currentTotal} (Initial cycle)`;

  return {
    currentTotal,
    previousTotal,
    weightedScore,
    level,
    formulaText,
  };
}

export function getTotalVehicles(roads: Record<RoadDirection, RoadInput>): number {
  return ROAD_DIRECTIONS.reduce((sum, dir) => sum + roads[dir].vehicleCount, 0);
}

export function getHighestDensityDirection(
  roads: Record<RoadDirection, RoadInput>
): { direction: RoadDirection; count: number } | null {
  let bestDir: RoadDirection | null = null;
  let bestCount = 0;

  for (const dir of ROAD_DIRECTIONS) {
    if (roads[dir].vehicleCount > bestCount) {
      bestCount = roads[dir].vehicleCount;
      bestDir = dir;
    }
  }

  if (!bestDir) return null;
  return { direction: bestDir, count: bestCount };
}

export function formatEmergencyLabel(type: EmergencyType): string {
  if (type === 'AMBULANCE') return 'Ambulance';
  if (type === 'FIRE_ENGINE') return 'Fire Engine';
  return 'None';
}

export function exportHistoryToCSV(history: TrafficCycleRecord[]): string {
  const headers = [
    'Cycle #',
    'Date & Time',
    'Mode',
    'North',
    'South',
    'East',
    'West',
    'Total Vehicles',
    'Signal Order',
    'North Green (s)',
    'South Green (s)',
    'East Green (s)',
    'West Green (s)',
    'Emergency Priority',
    'Weighted Score',
    'Congestion Level',
  ];

  const rows = history.map((item) => {
    const emergencyText =
      item.emergencies.length > 0
        ? item.emergencies
            .map((e) => `${e.direction}: ${formatEmergencyLabel(e.type)}`)
            .join(' | ')
        : 'None';

    return [
      item.cycleNumber,
      new Date(item.timestamp).toLocaleString(),
      item.sourceMode,
      item.vehicleCounts.North,
      item.vehicleCounts.South,
      item.vehicleCounts.East,
      item.vehicleCounts.West,
      item.totalVehicles,
      item.signalOrder.join(' -> ') || 'All Skipped',
      item.greenDurations.North,
      item.greenDurations.South,
      item.greenDurations.East,
      item.greenDurations.West,
      emergencyText,
      item.weightedScore,
      item.congestionLevel,
    ]
      .map((cell) => `"${String(cell).replace(/"/g, '""')}"`)
      .join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

export function exportHistoryToTextReport(history: TrafficCycleRecord[]): string {
  const totalVehiclesHandled = history.reduce((acc, c) => acc + c.totalVehicles, 0);
  const emergencyCycles = history.filter((c) => c.emergencies.length > 0).length;

  const lines: string[] = [
    '====================================================================',
    'SMART TRAFFIC SIGNAL MANAGEMENT SYSTEM - TRAFFIC ENGINEERING REPORT',
    '====================================================================',
    `Generated At       : ${new Date().toLocaleString()}`,
    `Total Cycles Logged: ${history.length}`,
    `Total Vehicles     : ${totalVehiclesHandled}`,
    `Emergency Cycles   : ${emergencyCycles}`,
    '--------------------------------------------------------------------',
    '',
  ];

  history.forEach((c) => {
    const emg =
      c.emergencies.length > 0
        ? c.emergencies.map((e) => `${e.direction} (${formatEmergencyLabel(e.type)})`).join(', ')
        : 'None';

    lines.push(`Cycle #${c.cycleNumber} | ${new Date(c.timestamp).toLocaleString()} | ${c.sourceMode}`);
    lines.push(
      `  Vehicle Counts : N=${c.vehicleCounts.North}, S=${c.vehicleCounts.South}, E=${c.vehicleCounts.East}, W=${c.vehicleCounts.West} (Total: ${c.totalVehicles})`
    );
    lines.push(`  Signal Order   : ${c.signalOrder.join(' -> ') || 'None (All Zero)'}`);
    lines.push(
      `  Green Durations: N=${c.greenDurations.North}s, S=${c.greenDurations.South}s, E=${c.greenDurations.East}s, W=${c.greenDurations.West}s`
    );
    lines.push(`  Emergency Info : ${emg}`);
    lines.push(`  Congestion     : ${c.congestionLevel} (Weighted Score: ${c.weightedScore})`);
    lines.push(`  Pedestrian     : ${c.pedestrianDuration}s All-Red Crossing Phase`);
    lines.push('--------------------------------------------------------------------');
  });

  return lines.join('\n');
}
