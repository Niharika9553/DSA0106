import { DetectedObjectBox, EmergencyType, RoadDirection, VehicleClass } from '../types/traffic';

interface InternalTrack {
  trackId: number;
  cx: number;
  cy: number;
  box: DetectedObjectBox;
  missingFrames: number;
  counted: boolean;
}

/**
 * Deterministic multi-frame ROI detector & centroid tracker.
 * Processes real <video> or prerecorded demo <canvas> pixel frames
 * without any random counts, ensuring each tracked vehicle is counted once.
 */
export class FrameVehicleDetectorAndTracker {
  private bgLuma: Float32Array | null = null;
  private gridCols = 32;
  private gridRows = 18;
  private nextTrackId = 1;
  private tracks: InternalTrack[] = [];
  private countedIds = new Set<number>();

  public reset(): void {
    this.bgLuma = null;
    this.nextTrackId = 1;
    this.tracks = [];
    this.countedIds.clear();
  }

  public classifyDirection(cxNorm: number, cyNorm: number): RoadDirection {
    const dx = cxNorm - 0.5;
    const dy = cyNorm - 0.5;
    if (Math.abs(dy) >= Math.abs(dx)) {
      return dy < 0 ? 'North' : 'South';
    }
    return dx < 0 ? 'West' : 'East';
  }

  private classifyVehicleFromBox(wNorm: number, hNorm: number): VehicleClass {
    const area = wNorm * hNorm;
    const ratio = Math.max(wNorm, hNorm) / Math.max(0.01, Math.min(wNorm, hNorm));
    if (area > 0.016 && ratio > 1.7) return 'bus';
    if (area > 0.011) return 'truck';
    if (area < 0.0032) return 'motorcycle';
    return 'car';
  }

  /**
   * Analyzes pixel frames from a video or canvas element using background subtraction
   * + connected grid clustering + nearest-centroid tracking.
   * Returns active bounding boxes and ONLY newly detected (never-before-counted) tracks.
   */
  public processFrame(
    source: HTMLVideoElement | HTMLCanvasElement,
    workCanvas: HTMLCanvasElement
  ): {
    boxes: DetectedObjectBox[];
    newlyCounted: DetectedObjectBox[];
  } {
    const w = 320;
    const h = 180;
    if (workCanvas.width !== w || workCanvas.height !== h) {
      workCanvas.width = w;
      workCanvas.height = h;
    }

    const ctx = workCanvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return { boxes: [], newlyCounted: [] };

    ctx.drawImage(source, 0, 0, w, h);
    const img = ctx.getImageData(0, 0, w, h).data;

    if (!this.bgLuma) {
      this.bgLuma = new Float32Array(w * h);
      for (let i = 0; i < w * h; i++) {
        const idx = i * 4;
        this.bgLuma[i] = 0.299 * img[idx] + 0.587 * img[idx + 1] + 0.114 * img[idx + 2];
      }
      return { boxes: [], newlyCounted: [] };
    }

    // Build motion energy grid (32x18 cells of 10x10 px)
    const cellW = w / this.gridCols;
    const cellH = h / this.gridRows;
    const activeGrid = new Uint8Array(this.gridCols * this.gridRows);
    const cellEnergy = new Float32Array(this.gridCols * this.gridRows);

    for (let gy = 0; gy < this.gridRows; gy++) {
      for (let gx = 0; gx < this.gridCols; gx++) {
        let diffSum = 0;
        let samples = 0;
        const startY = Math.floor(gy * cellH);
        const endY = Math.floor((gy + 1) * cellH);
        const startX = Math.floor(gx * cellW);
        const endX = Math.floor((gx + 1) * cellW);

        for (let py = startY; py < endY; py += 2) {
          for (let px = startX; px < endX; px += 2) {
            const pIdx = py * w + px;
            const dIdx = pIdx * 4;
            const luma =
              0.299 * img[dIdx] + 0.587 * img[dIdx + 1] + 0.114 * img[dIdx + 2];
            const diff = Math.abs(luma - this.bgLuma[pIdx]);
            this.bgLuma[pIdx] = this.bgLuma[pIdx] * 0.96 + luma * 0.04;
            diffSum += diff;
            samples++;
          }
        }

        const avgDiff = samples > 0 ? diffSum / samples : 0;
        const gIdx = gy * this.gridCols + gx;
        cellEnergy[gIdx] = avgDiff;
        if (avgDiff > 18) {
          activeGrid[gIdx] = 1;
        }
      }
    }

    // Connected components clustering on activeGrid
    const visited = new Uint8Array(this.gridCols * this.gridRows);
    const rawDetections: Omit<DetectedObjectBox, 'trackId'>[] = [];

    for (let gy = 0; gy < this.gridRows; gy++) {
      for (let gx = 0; gx < this.gridCols; gx++) {
        const startIdx = gy * this.gridCols + gx;
        if (!activeGrid[startIdx] || visited[startIdx]) continue;

        const queue: number[] = [startIdx];
        visited[startIdx] = 1;
        let minX = gx;
        let maxX = gx;
        let minY = gy;
        let maxY = gy;
        let cellCount = 0;
        let energySum = 0;

        while (queue.length > 0) {
          const curr = queue.pop()!;
          const cx = curr % this.gridCols;
          const cy = Math.floor(curr / this.gridCols);
          cellCount++;
          energySum += cellEnergy[curr];

          if (cx < minX) minX = cx;
          if (cx > maxX) maxX = cx;
          if (cy < minY) minY = cy;
          if (cy > maxY) maxY = cy;

          const neighbors = [
            [cx - 1, cy],
            [cx + 1, cy],
            [cx, cy - 1],
            [cx, cy + 1],
          ];
          for (const [nx, ny] of neighbors) {
            if (nx >= 0 && nx < this.gridCols && ny >= 0 && ny < this.gridRows) {
              const nIdx = ny * this.gridCols + nx;
              if (activeGrid[nIdx] && !visited[nIdx]) {
                visited[nIdx] = 1;
                queue.push(nIdx);
              }
            }
          }
        }

        // Ignore tiny sensor noise; accept vehicle-sized blobs
        if (cellCount >= 2 && cellCount <= 48) {
          const xNorm = minX / this.gridCols;
          const yNorm = minY / this.gridRows;
          const wNorm = (maxX - minX + 1) / this.gridCols;
          const hNorm = (maxY - minY + 1) / this.gridRows;
          const cxNorm = xNorm + wNorm / 2;
          const cyNorm = yNorm + hNorm / 2;

          const meanEnergy = energySum / cellCount;
          const confidence = Math.min(0.96, Math.max(0.68, 0.62 + meanEnergy / 120));

          rawDetections.push({
            x: xNorm,
            y: yNorm,
            w: wNorm,
            h: hNorm,
            vehicleClass: this.classifyVehicleFromBox(wNorm, hNorm),
            confidence,
            direction: this.classifyDirection(cxNorm, cyNorm),
            emergency: 'NONE',
          });
        }
      }
    }

    return this.updateTracks(rawDetections);
  }

  /**
   * Shared track updater (used for both pixel blob detector and structured prerecorded stream)
   */
  public updateTracks(
    detections: Omit<DetectedObjectBox, 'trackId'>[]
  ): { boxes: DetectedObjectBox[]; newlyCounted: DetectedObjectBox[] } {
    const matched = new Array<boolean>(detections.length).fill(false);
    const maxDist = 0.14;

    for (const track of this.tracks) {
      let bestDist = Infinity;
      let bestIdx = -1;

      for (let i = 0; i < detections.length; i++) {
        if (matched[i]) continue;
        const d = detections[i];
        const dcx = d.x + d.w / 2;
        const dcy = d.y + d.h / 2;
        const dist = Math.hypot(dcx - track.cx, dcy - track.cy);
        if (dist < bestDist && dist <= maxDist) {
          bestDist = dist;
          bestIdx = i;
        }
      }

      if (bestIdx >= 0) {
        matched[bestIdx] = true;
        const d = detections[bestIdx];
        track.cx = d.x + d.w / 2;
        track.cy = d.y + d.h / 2;
        track.box = { ...d, trackId: track.trackId };
        track.missingFrames = 0;
      } else {
        track.missingFrames++;
      }
    }

    this.tracks = this.tracks.filter((t) => t.missingFrames <= 8);

    const newlyCounted: DetectedObjectBox[] = [];
    for (let i = 0; i < detections.length; i++) {
      if (matched[i]) continue;
      const d = detections[i];
      const trackId = this.nextTrackId++;
      const box: DetectedObjectBox = { ...d, trackId };
      this.tracks.push({
        trackId,
        cx: d.x + d.w / 2,
        cy: d.y + d.h / 2,
        box,
        missingFrames: 0,
        counted: true,
      });
      if (!this.countedIds.has(trackId)) {
        this.countedIds.add(trackId);
        newlyCounted.push(box);
      }
    }

    return {
      boxes: this.tracks.filter((t) => t.missingFrames === 0).map((t) => t.box),
      newlyCounted,
    };
  }
}

export interface PrerecordedVehicleSpec {
  id: number;
  direction: RoadDirection;
  vehicleClass: VehicleClass;
  emergency: EmergencyType;
  startSec: number;
  durationSec: number;
  confidence: number;
}

/**
 * Deterministic prerecorded-video vehicle schedule (no random values).
 * Represents vehicles passing through the 4 directional camera ROIs in a recorded intersection clip.
 */
export const PRERECORDED_DEMO_SCHEDULE: PrerecordedVehicleSpec[] = [
  { id: 101, direction: 'East', vehicleClass: 'car', emergency: 'NONE', startSec: 0.4, durationSec: 4.5, confidence: 0.94 },
  { id: 102, direction: 'East', vehicleClass: 'bus', emergency: 'NONE', startSec: 1.5, durationSec: 5.0, confidence: 0.91 },
  { id: 103, direction: 'North', vehicleClass: 'car', emergency: 'NONE', startSec: 2.0, durationSec: 4.2, confidence: 0.89 },
  { id: 104, direction: 'South', vehicleClass: 'truck', emergency: 'NONE', startSec: 3.1, durationSec: 4.8, confidence: 0.92 },
  { id: 105, direction: 'West', vehicleClass: 'motorcycle', emergency: 'NONE', startSec: 4.0, durationSec: 3.8, confidence: 0.84 },
  { id: 106, direction: 'East', vehicleClass: 'car', emergency: 'NONE', startSec: 5.2, durationSec: 4.4, confidence: 0.95 },
  { id: 107, direction: 'South', vehicleClass: 'car', emergency: 'NONE', startSec: 6.3, durationSec: 4.2, confidence: 0.90 },
  { id: 108, direction: 'North', vehicleClass: 'truck', emergency: 'NONE', startSec: 7.4, durationSec: 4.6, confidence: 0.88 },
  { id: 109, direction: 'East', vehicleClass: 'car', emergency: 'AMBULANCE', startSec: 9.0, durationSec: 4.5, confidence: 0.96 },
  { id: 110, direction: 'South', vehicleClass: 'bus', emergency: 'NONE', startSec: 11.2, durationSec: 4.8, confidence: 0.93 },
  { id: 111, direction: 'West', vehicleClass: 'car', emergency: 'NONE', startSec: 12.5, durationSec: 4.0, confidence: 0.87 },
  { id: 112, direction: 'North', vehicleClass: 'car', emergency: 'NONE', startSec: 14.0, durationSec: 4.3, confidence: 0.91 },
];

export function renderPrerecordedDemoFrame(
  canvas: HTMLCanvasElement,
  elapsedSec: number
): Omit<DetectedObjectBox, 'trackId'>[] {
  const ctx = canvas.getContext('2d');
  if (!ctx) return [];
  const w = canvas.width;
  const h = canvas.height;

  // Draw deterministic recorded road camera background
  ctx.fillStyle = '#0b1220';
  ctx.fillRect(0, 0, w, h);

  // Road surfaces
  ctx.fillStyle = '#182235';
  ctx.fillRect(w * 0.38, 0, w * 0.24, h);
  ctx.fillRect(0, h * 0.36, w, h * 0.28);

  // Dashed lane lines
  ctx.strokeStyle = 'rgba(250, 204, 21, 0.45)';
  ctx.lineWidth = 2;
  ctx.setLineDash([8, 8]);
  ctx.beginPath();
  ctx.moveTo(w * 0.5, 0);
  ctx.lineTo(w * 0.5, h);
  ctx.moveTo(0, h * 0.5);
  ctx.lineTo(w, h * 0.5);
  ctx.stroke();
  ctx.setLineDash([]);

  // Loop 18-second recorded clip deterministically
  const clipTime = elapsedSec % 18;
  const activeBoxes: Omit<DetectedObjectBox, 'trackId'>[] = [];

  for (const spec of PRERECORDED_DEMO_SCHEDULE) {
    if (clipTime < spec.startSec || clipTime > spec.startSec + spec.durationSec) {
      continue;
    }
    const progress = (clipTime - spec.startSec) / spec.durationSec;

    let xNorm = 0.5;
    let yNorm = 0.5;
    let bw = 0.06;
    let bh = 0.09;

    if (spec.direction === 'North') {
      xNorm = 0.415;
      yNorm = 0.05 + progress * 0.30;
      bw = spec.vehicleClass === 'bus' ? 0.065 : 0.052;
      bh = spec.vehicleClass === 'bus' ? 0.11 : 0.085;
    } else if (spec.direction === 'South') {
      xNorm = 0.53;
      yNorm = 0.88 - progress * 0.28;
      bw = spec.vehicleClass === 'bus' ? 0.065 : 0.052;
      bh = spec.vehicleClass === 'bus' ? 0.11 : 0.085;
    } else if (spec.direction === 'West') {
      xNorm = 0.06 + progress * 0.28;
      yNorm = 0.53;
      bw = spec.vehicleClass === 'truck' ? 0.09 : 0.07;
      bh = 0.065;
    } else {
      xNorm = 0.88 - progress * 0.28;
      yNorm = 0.40;
      bw = spec.vehicleClass === 'bus' ? 0.095 : 0.072;
      bh = 0.068;
    }

    const px = xNorm * w;
    const py = yNorm * h;
    const pw = bw * w;
    const ph = bh * h;

    // Vehicle body in prerecorded clip
    ctx.fillStyle =
      spec.emergency === 'AMBULANCE'
        ? '#f97316'
        : spec.vehicleClass === 'bus'
        ? '#eab308'
        : spec.vehicleClass === 'truck'
        ? '#64748b'
        : '#38bdf8';
    ctx.fillRect(px, py, pw, ph);

    ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
    ctx.fillRect(px + 3, py + 3, pw - 6, ph * 0.32);

    activeBoxes.push({
      x: xNorm,
      y: yNorm,
      w: bw,
      h: bh,
      vehicleClass: spec.vehicleClass,
      confidence: spec.confidence,
      direction: spec.direction,
      emergency: spec.emergency,
    });
  }

  // Clearly watermark recorded demo footage
  ctx.fillStyle = 'rgba(7, 13, 25, 0.85)';
  ctx.fillRect(10, 10, 275, 26);
  ctx.fillStyle = '#fbbf24';
  ctx.font = '600 11px "JetBrains Mono", monospace';
  ctx.fillText(`PRERECORDED DEMO CLIP · ${clipTime.toFixed(1)}s / 18.0s`, 18, 27);

  return activeBoxes;
}
