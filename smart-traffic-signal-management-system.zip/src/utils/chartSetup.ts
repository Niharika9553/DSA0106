import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LineElement,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const CHART_GRID_COLOR = 'rgba(148, 163, 184, 0.12)';
export const CHART_TICK_COLOR = '#94a3b8';
export const CHART_FONT_FAMILY = "'Plus Jakarta Sans', system-ui, sans-serif";
