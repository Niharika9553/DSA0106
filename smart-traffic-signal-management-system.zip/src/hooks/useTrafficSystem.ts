import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CongestionMetrics,
  DetectedObjectBox,
  DetectionSourceMode,
  EmergencyEventInfo,
  EmergencyResolutionInfo,
  EmergencyType,
  OperatingMode,
  RoadDirection,
  RoadInput,
  ScheduledRoad,
  SignalColor,
  SimVehicle,
  SimulationPhase,
  SimulationSpeed,
  SimulationStatus,
  TrafficCycleRecord,
  VehicleClass,
} from '../types/traffic';
import {
  buildSignalSchedule,
  calculateCongestion,
  createZeroRoadsState,
  getHighestDensityDirection,
  getTotalVehicles,
  INITIAL_ROADS_STATE,
  ROAD_DIRECTIONS,
  SAMPLE_TRAFFIC_HISTORY,
  STORAGE_KEY_HISTORY,
} from '../utils/trafficEngine';
import {
  applyActivatePedestrian,
  applyManualTrafficUpdate,
  applyRecordDetectedVehicle,
  applySubmitEmergency,
  buildQueueVehiclesSafely,
  computeRoadSignals,
  countInsideIntersection,
  countQueuedByDirection,
  createInitialControllerState,
  spawnPhysicalVehicleInCtrl,
  stepSimulationFrame,
  TrafficControllerState,
} from '../utils/trafficSimulation';

function loadHistory(): TrafficCycleRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Ignore storage errors
  }
  return SAMPLE_TRAFFIC_HISTORY;
}

export interface CppEngineTelemetry {
  connected: boolean;
  cameraActive: boolean;
  detectionRunning: boolean;
  modelStatus: string;
  cameraError: string | null;
  modelError: string | null;
}

export interface LiveVehicleMetrics {
  queuedByDir: Record<RoadDirection, number>;
  crossedByDir: Record<RoadDirection, number>;
  totalCrossed: number;
  insideIntersection: number;
}

interface ControllerUiSnapshot {
  operatingMode: OperatingMode;
  simulationStatus: SimulationStatus;
  speed: SimulationSpeed;
  roads: Record<RoadDirection, RoadInput>;
  schedule: ScheduledRoad[];
  activeDirection: RoadDirection | null;
  phase: SimulationPhase;
  secondsRemaining: number;
  phaseTotalSeconds: number;
  servedDirections: RoadDirection[];
  activeEmergency: EmergencyEventInfo | null;
  lastEmergencyResolution: EmergencyResolutionInfo | null;
  pendingPedestrian: boolean;
  history: TrafficCycleRecord[];
}

function takeSnapshot(ctrl: TrafficControllerState): ControllerUiSnapshot {
  return {
    operatingMode: ctrl.operatingMode,
    simulationStatus: ctrl.simulationStatus,
    speed: ctrl.speed,
    roads: ctrl.roads,
    schedule: ctrl.schedule,
    activeDirection: ctrl.activeDirection,
    phase: ctrl.phase,
    secondsRemaining: ctrl.secondsRemaining,
    phaseTotalSeconds: ctrl.phaseTotalSeconds,
    servedDirections: ctrl.servedDirections,
    activeEmergency: ctrl.activeEmergency,
    lastEmergencyResolution: ctrl.lastEmergencyResolution,
    pendingPedestrian: ctrl.pendingPedestrian,
    history: ctrl.history,
  };
}

export function useTrafficSystem() {
  // Authoritative single-source-of-truth simulation controller & physics state
  const ctrlRef = useRef<TrafficControllerState | null>(null);
  if (ctrlRef.current === null) {
    ctrlRef.current = createInitialControllerState(loadHistory(), 'MANUAL');
  }

  const [ui, setUi] = useState<ControllerUiSnapshot>(() => takeSnapshot(ctrlRef.current!));

  // Shared physics array ref passed directly to canvas renderer (zero 60Hz React re-renders)
  const vehiclesRef = useRef<SimVehicle[]>(ctrlRef.current.vehicles);
  const canvasRenderCallbackRef = useRef<((nowMs: number) => void) | null>(null);

  const [vehicleMetrics, setVehicleMetrics] = useState<LiveVehicleMetrics>(() => ({
    queuedByDir: countQueuedByDirection(ctrlRef.current!.vehicles),
    crossedByDir: { ...ctrlRef.current!.crossedByDir },
    totalCrossed: ctrlRef.current!.totalCrossed,
    insideIntersection: countInsideIntersection(ctrlRef.current!.vehicles),
  }));

  // Camera / Video Detection State
  const [sourceMode, setSourceMode] = useState<DetectionSourceMode>('NONE');
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [detectionRunning, setDetectionRunning] = useState<boolean>(false);
  const [detectedBoxes, setDetectedBoxes] = useState<DetectedObjectBox[]>([]);
  const [cppEngine, setCppEngine] = useState<CppEngineTelemetry>({
    connected: false,
    cameraActive: false,
    detectionRunning: false,
    modelStatus: 'MODEL_NOT_CONNECTED',
    cameraError: null,
    modelError: null,
  });

  const cppConnectedRef = useRef<boolean>(false);
  cppConnectedRef.current = cppEngine.connected;

  const syncUiFromCtrl = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    vehiclesRef.current = ctrl.vehicles;
    setUi(takeSnapshot(ctrl));
  }, []);

  const syncMetricsFromCtrl = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    const queued = countQueuedByDirection(ctrl.vehicles);
    const inside = countInsideIntersection(ctrl.vehicles);

    setVehicleMetrics((prev) => {
      if (
        prev.totalCrossed === ctrl.totalCrossed &&
        prev.insideIntersection === inside &&
        prev.queuedByDir.North === queued.North &&
        prev.queuedByDir.South === queued.South &&
        prev.queuedByDir.East === queued.East &&
        prev.queuedByDir.West === queued.West &&
        prev.crossedByDir.North === ctrl.crossedByDir.North &&
        prev.crossedByDir.South === ctrl.crossedByDir.South &&
        prev.crossedByDir.East === ctrl.crossedByDir.East &&
        prev.crossedByDir.West === ctrl.crossedByDir.West
      ) {
        return prev;
      }
      return {
        queuedByDir: queued,
        crossedByDir: { ...ctrl.crossedByDir },
        totalCrossed: ctrl.totalCrossed,
        insideIntersection: inside,
      };
    });
  }, []);

  // Sync history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(ui.history));
    } catch {
      // Ignore quota errors
    }
  }, [ui.history]);

  // Single unified 60fps requestAnimationFrame loop:
  // Drives vehicle physics, the 1-second signal controller state machine, emergency exit tracking,
  // and canvas rendering from the exact same clock with zero duplicate timers.
  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();
    let lastMetricsSyncMs = 0;

    const tickFrame = (now: number) => {
      const rawDt = Math.min(0.05, Math.max(0, (now - lastTime) / 1000));
      lastTime = now;

      const ctrl = ctrlRef.current!;
      const events = stepSimulationFrame(ctrl, rawDt);
      vehiclesRef.current = ctrl.vehicles;

      if (events.stateChanged) {
        setUi(takeSnapshot(ctrl));
      }

      if (events.emergencyExited && cppConnectedRef.current) {
        fetch(`http://localhost:8080/api/emergency/exited/${events.emergencyExited.direction}`, {
          method: 'POST',
        }).catch(() => {});
      }

      // Render canvas directly in the same single RAF loop
      if (canvasRenderCallbackRef.current) {
        canvasRenderCallbackRef.current(now);
      }

      // Sync lightweight discrete telemetry (~5Hz max) or immediately on phase transition
      if (events.stateChanged || now - lastMetricsSyncMs >= 200) {
        lastMetricsSyncMs = now;
        syncMetricsFromCtrl();
      }

      rafId = window.requestAnimationFrame(tickFrame);
    };

    rafId = window.requestAnimationFrame(tickFrame);
    return () => window.cancelAnimationFrame(rafId);
  }, [syncMetricsFromCtrl]);

  const activeQueue = useMemo(() => ui.schedule.filter((s) => !s.skipped), [ui.schedule]);

  const activeQueueIndex = useMemo(() => {
    if (!ui.activeDirection) return 0;
    const idx = activeQueue.findIndex((item) => item.direction === ui.activeDirection);
    return idx >= 0 ? idx : 0;
  }, [activeQueue, ui.activeDirection]);

  const currentRoadItem: ScheduledRoad | null = useMemo(() => {
    if ((ui.phase === 'ROAD_GREEN' || ui.phase === 'ROAD_YELLOW') && ui.activeDirection) {
      return (
        activeQueue.find((item) => item.direction === ui.activeDirection) ??
        ui.schedule.find((item) => item.direction === ui.activeDirection) ??
        null
      );
    }
    return null;
  }, [activeQueue, ui.schedule, ui.phase, ui.activeDirection]);

  const roadSignals: Record<RoadDirection, SignalColor> = useMemo(
    () =>
      computeRoadSignals({
        simulationStatus: ui.simulationStatus,
        phase: ui.phase,
        activeDirection: ui.activeDirection,
      }),
    [ui.simulationStatus, ui.phase, ui.activeDirection]
  );

  const totalVehicles = useMemo(() => getTotalVehicles(ui.roads), [ui.roads]);
  const highestDensity = useMemo(() => getHighestDensityDirection(ui.roads), [ui.roads]);
  const previousCycleTraffic =
    ui.history.length > 0 ? ui.history[ui.history.length - 1].totalVehicles : null;
  const congestionMetrics: CongestionMetrics = useMemo(
    () => calculateCongestion(totalVehicles, previousCycleTraffic),
    [totalVehicles, previousCycleTraffic]
  );

  const activeEmergencies: EmergencyEventInfo[] = useMemo(() => {
    if (ui.activeEmergency) return [ui.activeEmergency];
    return ROAD_DIRECTIONS.filter((d) => ui.roads[d].emergency !== 'NONE').map((d) => ({
      direction: d,
      type: ui.roads[d].emergency as Exclude<EmergencyType, 'NONE'>,
      pending: true,
    }));
  }, [ui.activeEmergency, ui.roads]);

  const setSpeed = useCallback(
    (nextSpeed: SimulationSpeed) => {
      const ctrl = ctrlRef.current;
      if (!ctrl) return;
      ctrl.speed = nextSpeed;
      syncUiFromCtrl();
    },
    [syncUiFromCtrl]
  );

  // Record a unique newly detected vehicle from Camera / Video ROI
  const recordDetectedVehicle = useCallback(
    (direction: RoadDirection, vehicleClass: VehicleClass, emergency: EmergencyType = 'NONE') => {
      const ctrl = ctrlRef.current;
      if (!ctrl || ctrl.simulationStatus !== 'RUNNING') return;
      applyRecordDetectedVehicle(ctrl, direction, vehicleClass, emergency);
      syncUiFromCtrl();
      syncMetricsFromCtrl();
    },
    [syncUiFromCtrl, syncMetricsFromCtrl]
  );

  // Traffic Input Controller: Manual Vehicle Counts Update
  const updateManualTraffic = useCallback(
    (counts: Record<RoadDirection, number>) => {
      const ctrl = ctrlRef.current;
      if (!ctrl) return;
      applyManualTrafficUpdate(ctrl, counts);
      syncUiFromCtrl();
      syncMetricsFromCtrl();
    },
    [syncUiFromCtrl, syncMetricsFromCtrl]
  );

  // Emergency Priority Controller: SUBMIT EMERGENCY
  const submitEmergency = useCallback(
    (direction: RoadDirection, type: Exclude<EmergencyType, 'NONE'>) => {
      const ctrl = ctrlRef.current;
      if (!ctrl) return;
      applySubmitEmergency(ctrl, direction, type);
      syncUiFromCtrl();
      syncMetricsFromCtrl();

      if (cppConnectedRef.current) {
        fetch(`http://localhost:8080/api/emergency/${direction}/${type}`, {
          method: 'POST',
        }).catch(() => {});
      }
    },
    [syncUiFromCtrl, syncMetricsFromCtrl]
  );

  // Pedestrian Controller
  const activatePedestrianCrossing = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    applyActivatePedestrian(ctrl);
    syncUiFromCtrl();
  }, [syncUiFromCtrl]);

  // Simulation Control Buttons (START, PAUSE, RESUME, STOP, RESET)
  const startSimulation = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    ctrl.simulationStatus = 'RUNNING';
    ctrl.clockAccum = 0;

    if (ctrl.phase === 'IDLE') {
      const nextSched = buildSignalSchedule(ctrl.roads, ctrl.lastServedDirection);
      const nextActive = nextSched.filter((i) => !i.skipped);
      ctrl.schedule = nextSched;
      if (nextActive.length > 0) {
        if (ctrl.operatingMode === 'MANUAL' && ctrl.vehicles.length === 0) {
          ctrl.vehicles = buildQueueVehiclesSafely(ctrl.roads, [], ctrl);
        }
        ctrl.servedDirections = [];
        ctrl.phase = 'ROAD_GREEN';
        ctrl.activeDirection = nextActive[0].direction;
        ctrl.secondsRemaining = nextActive[0].greenDuration;
        ctrl.phaseTotalSeconds = nextActive[0].greenDuration;
      }
    }

    syncUiFromCtrl();
    syncMetricsFromCtrl();

    if (cppConnectedRef.current) {
      fetch('http://localhost:8080/api/simulation/start', { method: 'POST' }).catch(() => {});
    }
  }, [syncUiFromCtrl, syncMetricsFromCtrl]);

  const pauseSimulation = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    ctrl.simulationStatus = 'PAUSED';
    ctrl.clockAccum = 0;
    setDetectionRunning(false);
    syncUiFromCtrl();

    if (cppConnectedRef.current) {
      fetch('http://localhost:8080/api/simulation/pause', { method: 'POST' }).catch(() => {});
    }
  }, [syncUiFromCtrl]);

  const resumeSimulation = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    ctrl.simulationStatus = 'RUNNING';
    ctrl.clockAccum = 0;

    if (ctrl.phase === 'IDLE') {
      const nextSched = buildSignalSchedule(ctrl.roads, ctrl.lastServedDirection);
      const nextActive = nextSched.filter((i) => !i.skipped);
      ctrl.schedule = nextSched;
      if (nextActive.length > 0) {
        if (ctrl.operatingMode === 'MANUAL' && ctrl.vehicles.length === 0) {
          ctrl.vehicles = buildQueueVehiclesSafely(ctrl.roads, [], ctrl);
        }
        ctrl.servedDirections = [];
        ctrl.phase = 'ROAD_GREEN';
        ctrl.activeDirection = nextActive[0].direction;
        ctrl.secondsRemaining = nextActive[0].greenDuration;
        ctrl.phaseTotalSeconds = nextActive[0].greenDuration;
      }
    }

    if (cameraActive) setDetectionRunning(true);
    syncUiFromCtrl();
    syncMetricsFromCtrl();

    if (cppConnectedRef.current) {
      fetch('http://localhost:8080/api/simulation/resume', { method: 'POST' }).catch(() => {});
    }
  }, [cameraActive, syncUiFromCtrl, syncMetricsFromCtrl]);

  const stopSimulation = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;
    ctrl.simulationStatus = 'STOPPED';
    ctrl.phase = 'IDLE';
    ctrl.activeDirection = null;
    ctrl.secondsRemaining = 0;
    ctrl.phaseTotalSeconds = 0;
    ctrl.servedDirections = [];
    ctrl.pendingPedestrian = false;
    ctrl.postEmergencyDensityPending = null;
    ctrl.clockAccum = 0;
    ctrl.vehicles = ctrl.vehicles.map((v) => ({
      ...v,
      speed: 0,
      movementState: 'QUEUED',
    }));

    setDetectionRunning(false);
    syncUiFromCtrl();
    syncMetricsFromCtrl();

    if (cppConnectedRef.current) {
      fetch('http://localhost:8080/api/simulation/stop', { method: 'POST' }).catch(() => {});
    }
  }, [syncUiFromCtrl, syncMetricsFromCtrl]);

  const resetSimulation = useCallback(() => {
    const ctrl = ctrlRef.current;
    if (!ctrl) return;

    const fresh = createInitialControllerState(ctrl.history, ctrl.operatingMode);
    ctrlRef.current = fresh;

    setDetectionRunning(false);
    setCameraActive(false);
    setSourceMode('NONE');
    setDetectedBoxes([]);
    syncUiFromCtrl();
    syncMetricsFromCtrl();

    if (cppConnectedRef.current) {
      fetch('http://localhost:8080/api/reset', { method: 'POST' }).catch(() => {});
    }
  }, [syncUiFromCtrl, syncMetricsFromCtrl]);

  const switchOperatingMode = useCallback(
    (mode: OperatingMode) => {
      const ctrl = ctrlRef.current;
      if (!ctrl) return;

      ctrl.operatingMode = mode;
      ctrl.simulationStatus = 'RUNNING';
      ctrl.emergencyExitTriggered = null;
      ctrl.postEmergencyDensityPending = null;
      ctrl.activeEmergency = null;
      ctrl.lastEmergencyResolution = null;
      ctrl.pendingPedestrian = false;
      ctrl.servedDirections = [];
      ctrl.lastServedDirection = null;
      ctrl.clockAccum = 0;

      if (mode === 'CAMERA') {
        const zeros = createZeroRoadsState();
        ctrl.roads = zeros;
        ctrl.vehicles = [];
        ctrl.schedule = buildSignalSchedule(zeros);
        ctrl.phase = 'IDLE';
        ctrl.activeDirection = null;
        ctrl.secondsRemaining = 0;
        ctrl.phaseTotalSeconds = 0;
      } else {
        setDetectionRunning(false);
        setCameraActive(false);
        setSourceMode('NONE');
        ctrl.roads = INITIAL_ROADS_STATE;
        ctrl.vehicles = buildQueueVehiclesSafely(INITIAL_ROADS_STATE, [], ctrl);
        const nextSched = buildSignalSchedule(INITIAL_ROADS_STATE);
        const nextActive = nextSched.filter((s) => !s.skipped);
        ctrl.schedule = nextSched;
        if (nextActive.length > 0) {
          ctrl.phase = 'ROAD_GREEN';
          ctrl.activeDirection = nextActive[0].direction;
          ctrl.secondsRemaining = nextActive[0].greenDuration;
          ctrl.phaseTotalSeconds = nextActive[0].greenDuration;
        } else {
          ctrl.phase = 'IDLE';
          ctrl.activeDirection = null;
          ctrl.secondsRemaining = 0;
          ctrl.phaseTotalSeconds = 0;
        }
      }

      syncUiFromCtrl();
      syncMetricsFromCtrl();
    },
    [syncUiFromCtrl, syncMetricsFromCtrl]
  );

  const prepareForLiveDetection = useCallback(
    (mode: DetectionSourceMode) => {
      const ctrl = ctrlRef.current;
      if (!ctrl) return;

      const zeros = createZeroRoadsState();
      ctrl.operatingMode = 'CAMERA';
      ctrl.simulationStatus = 'RUNNING';
      ctrl.roads = zeros;
      ctrl.vehicles = [];
      ctrl.schedule = buildSignalSchedule(zeros);
      ctrl.servedDirections = [];
      ctrl.lastServedDirection = null;
      ctrl.activeDirection = null;
      ctrl.phase = 'IDLE';
      ctrl.secondsRemaining = 0;
      ctrl.phaseTotalSeconds = 0;
      ctrl.activeEmergency = null;
      ctrl.lastEmergencyResolution = null;
      ctrl.pendingPedestrian = false;
      ctrl.emergencyExitTriggered = null;
      ctrl.postEmergencyDensityPending = null;
      ctrl.clockAccum = 0;

      setSourceMode(mode);
      setDetectedBoxes([]);
      syncUiFromCtrl();
      syncMetricsFromCtrl();
    },
    [syncUiFromCtrl, syncMetricsFromCtrl]
  );

  // C++ Engine HTTP Connection (never fakes detection if offline)
  const connectCppEngine = useCallback(async (): Promise<{
    ok: boolean;
    error?: string;
  }> => {
    try {
      const res = await fetch('http://localhost:8080/api/status', {
        signal: AbortSignal.timeout(2000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setCppEngine({
        connected: true,
        cameraActive: Boolean(data.cameraActive),
        detectionRunning: Boolean(data.detectionRunning),
        modelStatus: data.modelStatus || 'CONNECTED',
        cameraError: data.cameraError || null,
        modelError: data.modelError || null,
      });
      if (ctrlRef.current) {
        ctrlRef.current.operatingMode = 'CAMERA';
        syncUiFromCtrl();
      }
      setSourceMode('CPP_ENGINE');
      return { ok: true };
    } catch {
      const msg =
        'C++ OpenCV & YOLO engine is unavailable at http://localhost:8080. Compile and run ./smart_traffic_engine locally, or switch to MANUAL MODE.';
      setCppEngine({
        connected: false,
        cameraActive: false,
        detectionRunning: false,
        modelStatus: 'OFFLINE',
        cameraError: msg,
        modelError: 'YOLO ONNX backend not connected',
      });
      return { ok: false, error: msg };
    }
  }, [syncUiFromCtrl]);

  const disconnectCppEngine = useCallback(() => {
    setCppEngine({
      connected: false,
      cameraActive: false,
      detectionRunning: false,
      modelStatus: 'OFFLINE',
      cameraError: null,
      modelError: null,
    });
    if (sourceMode === 'CPP_ENGINE') {
      setSourceMode('NONE');
    }
  }, [sourceMode]);

  // Controlled 1s poll for C++ OpenCV + YOLO detection backend (only updates if counts actually changed)
  useEffect(() => {
    if (!cppEngine.connected || sourceMode !== 'CPP_ENGINE') return;

    const timer = window.setInterval(async () => {
      try {
        const res = await fetch('http://localhost:8080/api/status', {
          signal: AbortSignal.timeout(1500),
        });
        if (!res.ok) throw new Error('Disconnected');
        const data = await res.json();

        setCppEngine({
          connected: true,
          cameraActive: Boolean(data.cameraActive),
          detectionRunning: Boolean(data.detectionRunning),
          modelStatus: data.modelStatus || 'CONNECTED',
          cameraError: data.cameraError || null,
          modelError: data.modelError || null,
        });

        const ctrl = ctrlRef.current;
        if (ctrl && Array.isArray(data.roads)) {
          let changed = false;
          const next = { ...ctrl.roads };
          for (const r of data.roads) {
            const dir = r.direction as RoadDirection;
            const newCount = Number(r.count) || 0;
            if (next[dir] && next[dir].vehicleCount !== newCount) {
              changed = true;
              const diff = Math.max(0, newCount - next[dir].vehicleCount);
              for (let k = 0; k < diff; k++) {
                spawnPhysicalVehicleInCtrl(ctrl, dir, 'car', 'NONE');
              }
              next[dir] = {
                direction: dir,
                vehicleCount: newCount,
                classCounts: {
                  car: Number(r.cars) || 0,
                  bus: Number(r.buses) || 0,
                  truck: Number(r.trucks) || 0,
                  motorcycle: Number(r.motorcycles) || 0,
                },
                emergency: (r.emergency as EmergencyType) || 'NONE',
              };
            }
          }
          if (changed) {
            ctrl.roads = next;
            ctrl.schedule = buildSignalSchedule(next, ctrl.lastServedDirection);
            syncUiFromCtrl();
            syncMetricsFromCtrl();
          }
        }
      } catch {
        setCppEngine({
          connected: false,
          cameraActive: false,
          detectionRunning: false,
          modelStatus: 'OFFLINE',
          cameraError: 'Lost connection to C++ OpenCV engine at http://localhost:8080.',
          modelError: null,
        });
      }
    }, 1000);

    return () => window.clearInterval(timer);
  }, [cppEngine.connected, sourceMode, syncUiFromCtrl, syncMetricsFromCtrl]);

  const registerCanvasRenderer = useCallback((fn: ((nowMs: number) => void) | null) => {
    canvasRenderCallbackRef.current = fn;
  }, []);

  const clearHistory = useCallback(() => {
    if (ctrlRef.current) {
      ctrlRef.current.history = [];
      syncUiFromCtrl();
    }
  }, [syncUiFromCtrl]);

  const restoreSampleHistory = useCallback(() => {
    if (ctrlRef.current) {
      ctrlRef.current.history = SAMPLE_TRAFFIC_HISTORY;
      syncUiFromCtrl();
    }
  }, [syncUiFromCtrl]);

  return {
    operatingMode: ui.operatingMode,
    simulationStatus: ui.simulationStatus,
    speed: ui.speed,
    roads: ui.roads,
    vehiclesRef,
    vehicleMetrics,
    schedule: ui.schedule,
    activeQueue,
    activeQueueIndex,
    currentRoadItem,
    phase: ui.phase,
    secondsRemaining: ui.secondsRemaining,
    phaseTotalSeconds: ui.phaseTotalSeconds,
    servedDirections: ui.servedDirections,
    roadSignals,
    totalVehicles,
    highestDensity,
    congestionMetrics,
    activeEmergencies,
    lastEmergencyResolution: ui.lastEmergencyResolution,
    pendingPedestrian: ui.pendingPedestrian,
    history: ui.history,
    sourceMode,
    cameraActive,
    detectionRunning,
    detectedBoxes,
    cppEngine,
    setSpeed,
    setCameraActive,
    setDetectionRunning,
    setDetectedBoxes,
    setSourceMode,
    switchOperatingMode,
    updateManualTraffic,
    submitEmergency,
    activatePedestrianCrossing,
    startSimulation,
    pauseSimulation,
    resumeSimulation,
    stopSimulation,
    resetSimulation,
    prepareForLiveDetection,
    recordDetectedVehicle,
    connectCppEngine,
    disconnectCppEngine,
    registerCanvasRenderer,
    clearHistory,
    restoreSampleHistory,
  };
}
