import React from 'react';
import { Code2, Cpu, FolderTree, Terminal } from 'lucide-react';

const CPP_MODULES = [
  { name: 'VehicleDetector', file: 'include/VehicleDetector.hpp · src/VehicleDetector.cpp', role: 'Loads yolov8n.onnx via OpenCV DNN, runs NMS, filters car/bus/truck/motorcycle, maps bounding boxes to North/South/East/West ROIs.' },
  { name: 'VehicleTracker', file: 'include/VehicleTracker.hpp · src/VehicleTracker.cpp', role: 'Nearest-centroid object tracker with virtual counting lines so each unique vehicle is counted once across consecutive frames.' },
  { name: 'TrafficDensity', file: 'include/TrafficDensity.hpp · src/TrafficDensity.cpp', role: 'Computes directional counts, traffic density %, highest-density direction, and LOW / MEDIUM / HIGH status.' },
  { name: 'Road', file: 'include/Road.hpp · src/Road.cpp', role: 'Encapsulates directional ROI, vehicle class counters, and emergency state.' },
  { name: 'TrafficSignal', file: 'include/TrafficSignal.hpp · src/TrafficSignal.cpp', role: 'Manages RED / GREEN / YELLOW states and proportional Green Time = Vehicle Count × 2 seconds (no 60s cap; zero-vehicle roads skipped).' },
  { name: 'TrafficSignalController', file: 'include/TrafficSignalController.hpp · src/TrafficSignalController.cpp', role: 'Executes GREEN -> YELLOW -> ALL_RED_CLEARANCE transitions with intersection occupancy safety lock, emergency preemption, and simulation start/pause/resume/stop.' },
  { name: 'EmergencyManager', file: 'include/EmergencyManager.hpp · src/EmergencyManager.cpp', role: 'Registers Ambulance and Fire Engine alerts and triggers safe next-phase priority.' },
  { name: 'PedestrianCrossing', file: 'include/PedestrianCrossing.hpp · src/PedestrianCrossing.cpp', role: 'Runs the 15-second all-red pedestrian WALK countdown phase.' },
  { name: 'TrafficLogger', file: 'include/TrafficLogger.hpp · src/TrafficLogger.cpp', role: 'Logs completed traffic cycles to traffic_history.csv via std::ofstream file handling.' },
  { name: 'main.cpp', file: 'src/main.cpp', role: 'Coordinates controlled 100ms OpenCV VideoCapture thread, 1s signal controller thread, and POSIX HTTP/JSON API server on port 8080.' },
];

export const CppEngineGuide: React.FC = React.memo(() => {
  return (
    <div className="space-y-6">
      <section className="glass-panel rounded-2xl p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-700/60 pb-5">
          <div>
            <p className="text-xs font-medium text-sky-400">C++11 + OpenCV + YOLO ONNX Architecture</p>
            <h2 className="mt-1 font-display text-2xl font-bold text-white">
              Smart Traffic Signal Management System
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-slate-300 leading-relaxed">
              The C++ detection and signal engine lives in <span className="font-mono text-sky-300">cpp_engine/</span>.
              When compiled locally with OpenCV 4.7+ and <span className="font-mono text-sky-300">yolov8n.onnx</span>, it exposes
              a real-time HTTP/JSON API on <span className="font-mono text-sky-300">http://localhost:8080</span> that
              connects directly to this React dashboard in CAMERA MODE.
            </p>
          </div>
          <div className="rounded-xl border border-sky-500/25 bg-slate-900 px-4 py-3">
            <span className="text-xs text-slate-400 block">Backend Stack</span>
            <span className="font-mono text-sm font-semibold text-sky-300">
              C++11 · OpenCV DNN · YOLOv8 ONNX
            </span>
          </div>
        </div>

        {/* Compilation & Model Setup */}
        <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Cpu className="h-4 w-4 text-sky-400" />
              <span>1. Dependencies & YOLO ONNX Model Setup</span>
            </div>
            <pre className="overflow-x-auto rounded-lg bg-slate-900 p-3.5 font-mono text-xs text-slate-200 leading-relaxed">
{`# Ubuntu / Debian dependencies
sudo apt update && sudo apt install -y build-essential cmake libopencv-dev

# Place YOLOv8n ONNX model inside cpp_engine/models/
mkdir -p cpp_engine/models
yolo export model=yolov8n.pt format=onnx imgsz=640 simplify=True
mv yolov8n.onnx cpp_engine/models/yolov8n.onnx`}
            </pre>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Terminal className="h-4 w-4 text-emerald-400" />
              <span>2. Compilation & Execution Commands</span>
            </div>
            <pre className="overflow-x-auto rounded-lg bg-slate-900 p-3.5 font-mono text-xs text-slate-200 leading-relaxed">
{`cd cpp_engine && mkdir -p build && cd build
cmake .. && make -j4

# Run with live webcam (index 0)
./smart_traffic_engine ../models/yolov8n.onnx

# Or run with a traffic video file
./smart_traffic_engine ../models/yolov8n.onnx traffic_sample.mp4`}
            </pre>
          </div>
        </div>

        <div className="mt-5 rounded-xl border border-slate-800 bg-slate-950/80 p-4">
          <p className="text-xs font-semibold text-white mb-2">Local HTTP/JSON Control Endpoints (port 8080)</p>
          <p className="font-mono text-[11px] text-slate-300 leading-relaxed">
            GET /api/status · GET /api/frame.jpg · POST /api/camera/start · POST /api/camera/stop · POST /api/simulation/start · POST /api/simulation/pause · POST /api/simulation/resume · POST /api/simulation/stop · POST /api/pedestrian/start · POST /api/reset · POST /api/emergency/&lt;Direction&gt;/&lt;Type&gt;
          </p>
        </div>
      </section>

      {/* C++ Module Inventory */}
      <section className="glass-panel rounded-2xl p-6">
        <div className="flex items-center gap-2.5 border-b border-slate-700/60 pb-4">
          <FolderTree className="h-5 w-5 text-sky-400" />
          <h3 className="font-display text-lg font-semibold text-white">
            C++ Source Modules (<span className="font-mono text-sky-300">cpp_engine/</span>)
          </h3>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3.5 md:grid-cols-2">
          {CPP_MODULES.map((m) => (
            <div
              key={m.name}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-4"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-display text-sm font-semibold text-white flex items-center gap-2">
                  <Code2 className="h-4 w-4 text-sky-400 shrink-0" />
                  {m.name}
                </span>
              </div>
              <p className="mt-1 font-mono text-[11px] text-sky-300">{m.file}</p>
              <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">{m.role}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
});
CppEngineGuide.displayName = 'CppEngineGuide';
