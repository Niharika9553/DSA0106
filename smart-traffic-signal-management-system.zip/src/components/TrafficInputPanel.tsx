import React, { useCallback, useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, RefreshCw, SlidersHorizontal } from 'lucide-react';
import { OperatingMode, RoadDirection, RoadInput } from '../types/traffic';
import { calculateGreenDuration, ROAD_DIRECTIONS } from '../utils/trafficEngine';

interface TrafficInputPanelProps {
  roads: Record<RoadDirection, RoadInput>;
  operatingMode: OperatingMode;
  onUpdateTraffic: (counts: Record<RoadDirection, number>) => void;
}

export const TrafficInputPanel: React.FC<TrafficInputPanelProps> = React.memo(
  ({ roads, operatingMode, onUpdateTraffic }) => {
    const [inputs, setInputs] = useState<Record<RoadDirection, string>>({
      North: String(roads.North.vehicleCount),
      South: String(roads.South.vehicleCount),
      East: String(roads.East.vehicleCount),
      West: String(roads.West.vehicleCount),
    });

    const [errors, setErrors] = useState<Partial<Record<RoadDirection, string>>>({});
    const [successNotice, setSuccessNotice] = useState<string | null>(null);

    // Sync inputs if external reset or mode change happens
    useEffect(() => {
      setInputs({
        North: String(roads.North.vehicleCount),
        South: String(roads.South.vehicleCount),
        East: String(roads.East.vehicleCount),
        West: String(roads.West.vehicleCount),
      });
      setErrors({});
    }, [
      roads.North.vehicleCount,
      roads.South.vehicleCount,
      roads.East.vehicleCount,
      roads.West.vehicleCount,
    ]);

    const validateField = useCallback((raw: string): string | null => {
      const trimmed = raw.trim();
      if (trimmed === '') {
        return 'Value cannot be empty.';
      }
      if (!/^\d+$/.test(trimmed)) {
        return 'Enter a non-negative whole number only (no decimals, signs, or letters).';
      }
      return null;
    }, []);

    const handleChange = (dir: RoadDirection, value: string) => {
      setInputs((prev) => ({ ...prev, [dir]: value }));
      const err = validateField(value);
      setErrors((prev) => ({ ...prev, [dir]: err ?? undefined }));
      setSuccessNotice(null);
    };

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      const nextErrors: Partial<Record<RoadDirection, string>> = {};
      let invalid = false;

      for (const dir of ROAD_DIRECTIONS) {
        const err = validateField(inputs[dir]);
        if (err) {
          nextErrors[dir] = err;
          invalid = true;
        }
      }

      setErrors(nextErrors);
      if (invalid) {
        setSuccessNotice(null);
        return;
      }

      const parsed: Record<RoadDirection, number> = {
        North: Number(inputs.North.trim()),
        South: Number(inputs.South.trim()),
        East: Number(inputs.East.trim()),
        West: Number(inputs.West.trim()),
      };

      onUpdateTraffic(parsed);
      setSuccessNotice(
        `Updated: N=${parsed.North} (${parsed.North * 2}s), S=${parsed.South} (${parsed.South * 2}s), E=${parsed.East} (${parsed.East * 2}s), W=${parsed.West} (${parsed.West * 2}s).`
      );
    };

    const applyQuickTest = (n: number, s: number, e: number, w: number) => {
      setInputs({
        North: String(n),
        South: String(s),
        East: String(e),
        West: String(w),
      });
      setErrors({});
      setSuccessNotice(null);
    };

    return (
      <section className="glass-panel rounded-2xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/60 pb-4">
          <div className="flex items-center gap-2.5">
            <SlidersHorizontal className="h-5 w-5 text-sky-400 shrink-0" />
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Traffic Input Panel (Manual Vehicle Density)
              </h2>
              <p className="text-xs text-slate-400">
                Formula: <span className="font-mono text-sky-300">Green Time = Vehicle Count × 2s</span> · Zero-vehicle roads skipped
              </p>
            </div>
          </div>

          <span className="font-mono text-xs font-semibold text-sky-300">
            {operatingMode === 'MANUAL' ? 'MANUAL MODE' : 'SWITCHES TO MANUAL MODE ON UPDATE'}
          </span>
        </div>

        <form onSubmit={handleSubmit} noValidate className="mt-4 space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ROAD_DIRECTIONS.map((dir) => {
              const raw = inputs[dir];
              const err = errors[dir];
              const isValid = !err && /^\d+$/.test(raw.trim());
              const previewCount = isValid ? Number(raw.trim()) : 0;
              const previewGreen = isValid
                ? calculateGreenDuration(previewCount, 'NONE')
                : null;

              return (
                <div
                  key={dir}
                  className={`rounded-xl border p-3.5 ${
                    err
                      ? 'border-red-500/60 bg-red-950/20'
                      : 'border-slate-700/70 bg-slate-900/60'
                  }`}
                >
                  <label
                    htmlFor={`manual-input-${dir}`}
                    className="block font-display text-xs font-semibold text-slate-200"
                  >
                    {dir} Road – Vehicle Count
                  </label>
                  <input
                    id={`manual-input-${dir}`}
                    type="text"
                    inputMode="numeric"
                    value={raw}
                    onChange={(e) => handleChange(dir, e.target.value)}
                    placeholder="0"
                    className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-sm text-white placeholder-slate-500 focus:border-sky-400 focus:outline-none tabular-nums"
                  />
                  <div className="mt-2 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Green Time:</span>
                    <span className={previewGreen === 0 ? 'text-slate-400' : 'text-emerald-300 font-semibold'}>
                      {previewGreen === null
                        ? 'Invalid'
                        : previewGreen === 0
                        ? 'Skipped (0s)'
                        : `${previewGreen}s`}
                    </span>
                  </div>
                  {err && (
                    <p className="mt-1.5 flex items-start gap-1 text-[11px] text-red-400">
                      <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                      <span>{err}</span>
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          {successNotice && (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-3.5 py-2.5 text-xs text-emerald-200">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>{successNotice}</span>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => applyQuickTest(10, 20, 30, 5)}
                className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
              >
                Preset: N10 S20 E30 W5
              </button>
              <button
                type="button"
                onClick={() => applyQuickTest(0, 15, 0, 10)}
                className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
              >
                Preset: Zero-Skip (N0 S15 E0 W10)
              </button>
              <button
                type="button"
                onClick={() => applyQuickTest(0, 0, 0, 0)}
                className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white"
              >
                Preset: All Zero
              </button>
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg bg-sky-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors whitespace-nowrap shrink-0"
            >
              <RefreshCw className="h-4 w-4" />
              <span>UPDATE TRAFFIC</span>
            </button>
          </div>
        </form>
      </section>
    );
  }
);
TrafficInputPanel.displayName = 'TrafficInputPanel';
