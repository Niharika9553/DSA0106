import React from 'react';
import { Hand, PersonStanding, ShieldCheck, TrafficCone } from 'lucide-react';
import {
  RoadDirection,
  ScheduledRoad,
  SignalColor,
  SimulationPhase,
  SimulationSpeed,
  SimulationStatus,
} from '../types/traffic';
import {
  formatEmergencyLabel,
  PEDESTRIAN_DURATION_SECONDS,
  ROAD_DIRECTIONS,
} from '../utils/trafficEngine';
import { TrafficLightUnit } from './TrafficLightUnit';

interface SignalControllerProps {
  schedule: ScheduledRoad[];
  activeQueue: ScheduledRoad[];
  activeQueueIndex: number;
  currentRoadItem: ScheduledRoad | null;
  roadSignals: Record<RoadDirection, SignalColor>;
  phase: SimulationPhase;
  secondsRemaining: number;
  servedDirections: RoadDirection[];
  vehiclesInsideIntersection: number;
  simulationStatus: SimulationStatus;
  pendingPedestrian: boolean;
  speed: SimulationSpeed;
  onChangeSpeed: (speed: SimulationSpeed) => void;
  onTriggerPedestrian: () => void;
}

export const SignalController: React.FC<SignalControllerProps> = React.memo(
  ({
    schedule,
    activeQueue,
    activeQueueIndex,
    currentRoadItem,
    roadSignals,
    phase,
    secondsRemaining,
    servedDirections,
    vehiclesInsideIntersection,
    simulationStatus,
    pendingPedestrian,
    speed,
    onChangeSpeed,
    onTriggerPedestrian,
  }) => {
    const isPed = phase === 'PEDESTRIAN_CROSSING';

    return (
      <div className="space-y-6">
        {/* State Machine & Timing Status */}
        <section className="glass-panel rounded-2xl p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-700/60 pb-4">
            <div>
              <h2 className="font-display text-lg font-semibold text-white">
                Intelligent Traffic Signal Controller
              </h2>
              <p className="text-xs text-slate-400">
                State Machine: RED → GREEN → YELLOW → ALL-RED CLEARANCE · Formula: Green Time = Vehicle Count × 2s (No 60s cap)
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Speed:</span>
              <div className="flex items-center rounded-lg border border-slate-700 bg-slate-900 p-1">
                {([1, 2, 5] as SimulationSpeed[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => onChangeSpeed(s)}
                    className={`rounded px-2.5 py-1 font-mono text-xs font-semibold transition-colors ${
                      speed === s ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Four Signal Heads Live Grid */}
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ROAD_DIRECTIONS.map((dir) => {
              const sig = roadSignals[dir];
              const sched = schedule.find((s) => s.direction === dir);
              const isCurrent = currentRoadItem?.direction === dir;

              return (
                <div
                  key={dir}
                  className={`rounded-xl border p-4 transition-colors ${
                    isCurrent
                      ? 'border-sky-400/50 bg-sky-500/10'
                      : 'border-slate-700/70 bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <h3 className="font-display text-sm font-semibold text-white">
                        {dir} Signal
                      </h3>
                      <p
                        className={`mt-0.5 font-mono text-xs font-bold ${
                          sig === 'GREEN'
                            ? 'text-emerald-400'
                            : sig === 'YELLOW'
                            ? 'text-yellow-300'
                            : 'text-red-400'
                        }`}
                      >
                        {sched?.skipped ? 'SKIPPED (RED)' : sig}
                      </p>
                    </div>
                    <TrafficLightUnit signal={sig} compact />
                  </div>

                  <div className="mt-3 flex items-center justify-between border-t border-slate-800 pt-2.5 font-mono text-xs text-slate-300 tabular-nums">
                    <span>
                      Allocated: {sched?.skipped ? '0s' : `${sched?.greenDuration ?? 0}s`}
                    </span>
                    <span>
                      {isCurrent ? `${secondsRemaining}s left` : 'Hold RED'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Clearance Safety Lock & Pedestrian Crossing Module */}
          <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
            <div className="rounded-xl border border-slate-700/70 bg-slate-900/60 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-sky-400" />
                  <span className="font-display text-sm font-semibold text-white">
                    Intersection Clearance Lock
                  </span>
                </div>
                <span
                  className={`font-mono text-xs font-semibold ${
                    vehiclesInsideIntersection > 0 ? 'text-amber-300' : 'text-emerald-400'
                  }`}
                >
                  {vehiclesInsideIntersection > 0
                    ? `OCCUPIED (${vehiclesInsideIntersection})`
                    : 'CLEAR'}
                </span>
              </div>
              <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                The signal controller holds all four lanes RED during transition until{' '}
                <span className="font-mono text-slate-200">insideIntersection === 0</span>,
                preventing conflicting cross-traffic entry.
                {simulationStatus !== 'RUNNING' && (
                  <span className="ml-1 font-semibold text-amber-300">
                    (Simulation {simulationStatus})
                  </span>
                )}
              </p>
            </div>

            <div
              className={`rounded-xl border p-4 transition-colors ${
                isPed
                  ? 'border-emerald-400/55 bg-emerald-950/30'
                  : 'border-slate-700/70 bg-slate-900/60'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {isPed ? (
                    <PersonStanding className="h-5 w-5 text-emerald-300" />
                  ) : (
                    <Hand className="h-4 w-4 text-red-400" />
                  )}
                  <span className="font-display text-sm font-semibold text-white">
                    Pedestrian Crossing ({PEDESTRIAN_DURATION_SECONDS}s)
                  </span>
                </div>
                <span
                  className={`font-mono text-xs font-bold tabular-nums ${
                    isPed
                      ? 'text-emerald-300'
                      : pendingPedestrian
                      ? 'text-amber-300'
                      : 'text-slate-400'
                  }`}
                >
                  {isPed
                    ? `WALK · ${secondsRemaining}s`
                    : pendingPedestrian
                    ? 'QUEUED (CLEARING)'
                    : "DON'T WALK"}
                </span>
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs text-slate-400">
                  Transitions GREEN → YELLOW → ALL-RED before starting the 15-second WALK phase.
                </p>
                <button
                  type="button"
                  onClick={onTriggerPedestrian}
                  disabled={isPed}
                  className="rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3 py-1.5 text-xs font-semibold text-emerald-200 hover:bg-emerald-500/25 disabled:opacity-40 transition-colors whitespace-nowrap"
                >
                  Start 15s WALK Phase
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Priority Execution Table */}
        <section className="glass-panel rounded-2xl p-5 sm:p-6">
          <div className="flex items-center gap-2 border-b border-slate-700/60 pb-3.5">
            <TrafficCone className="h-4 w-4 text-sky-400" />
            <h3 className="font-display text-base font-semibold text-white">
              Active Cycle Signal Queue
            </h3>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400">
                  <th className="py-2.5 pr-3 font-medium">Order</th>
                  <th className="py-2.5 px-3 font-medium">Direction</th>
                  <th className="py-2.5 px-3 font-medium text-right">Count</th>
                  <th className="py-2.5 px-3 font-medium">Emergency</th>
                  <th className="py-2.5 px-3 font-medium">Timing Formula</th>
                  <th className="py-2.5 px-3 font-medium text-right">Green Time</th>
                  <th className="py-2.5 pl-3 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {schedule.map((item) => {
                  const isServing =
                    (phase === 'ROAD_GREEN' || phase === 'ROAD_YELLOW') &&
                    activeQueue[activeQueueIndex]?.direction === item.direction;
                  const isDone = servedDirections.includes(item.direction);

                  return (
                    <tr
                      key={item.direction}
                      className={isServing ? 'bg-sky-500/10' : ''}
                    >
                      <td className="py-2.5 pr-3 font-mono text-slate-300">
                        {item.skipped ? '—' : `#${item.priorityRank}`}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-white">
                        {item.direction} Road
                      </td>
                      <td className="py-2.5 px-3 font-mono text-right text-slate-200 tabular-nums">
                        {item.vehicleCount}
                      </td>
                      <td className="py-2.5 px-3 text-xs">
                        <span
                          className={
                            item.emergency !== 'NONE'
                              ? 'font-semibold text-orange-300'
                              : 'text-slate-400'
                          }
                        >
                          {formatEmergencyLabel(item.emergency)}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-xs text-slate-300">
                        {item.emergency !== 'NONE'
                          ? `max(20, ${item.vehicleCount} × 2)`
                          : item.skipped
                          ? '0 Vehicles = Skipped'
                          : `${item.vehicleCount} × 2s`}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-right font-semibold text-sky-300 tabular-nums">
                        {item.skipped ? '0s' : `${item.greenDuration}s`}
                      </td>
                      <td className="py-2.5 pl-3 text-right font-mono text-xs">
                        <span
                          className={
                            item.skipped
                              ? 'text-slate-500'
                              : isServing
                              ? 'text-emerald-400 font-semibold'
                              : isDone
                              ? 'text-slate-300'
                              : 'text-red-400'
                          }
                        >
                          {item.skipped
                            ? 'SKIPPED'
                            : isServing
                            ? phase === 'ROAD_YELLOW'
                              ? 'YELLOW'
                              : 'GREEN'
                            : isDone
                            ? 'SERVED'
                            : 'QUEUED'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  }
);
SignalController.displayName = 'SignalController';
