import React from 'react';
import { Ambulance, Flame, ShieldAlert, Siren } from 'lucide-react';
import {
  EmergencyEventInfo,
  EmergencyResolutionInfo,
  EmergencyType,
  RoadDirection,
  RoadInput,
  ScheduledRoad,
  SimulationPhase,
} from '../types/traffic';
import { formatEmergencyLabel, ROAD_DIRECTIONS } from '../utils/trafficEngine';
import { EmergencyInputPanel } from './EmergencyInputPanel';

interface EmergencyAlertsProps {
  roads: Record<RoadDirection, RoadInput>;
  activeEmergencies: EmergencyEventInfo[];
  lastEmergencyResolution: EmergencyResolutionInfo | null;
  currentRoadItem: ScheduledRoad | null;
  phase: SimulationPhase;
  onSubmitEmergency: (
    direction: RoadDirection,
    type: Exclude<EmergencyType, 'NONE'>
  ) => void;
}

export const EmergencyAlerts: React.FC<EmergencyAlertsProps> = React.memo(
  ({
    roads,
    activeEmergencies,
    lastEmergencyResolution,
    currentRoadItem,
    phase,
    onSubmitEmergency,
  }) => {
    const isPriorityMode = activeEmergencies.length > 0;

    return (
      <div className="space-y-5">
        {/* Prominent PRIORITY MODE Status Bar */}
        {isPriorityMode ? (
          <div
            role="alert"
            className="rounded-2xl border border-orange-500/50 bg-gradient-to-r from-orange-950/85 via-red-950/75 to-slate-900/90 p-5 shadow-lg shadow-orange-950/30"
          >
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-orange-400/50 bg-orange-500/20 text-orange-300">
                  <Siren className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-display text-base font-bold tracking-wide text-orange-300">
                    PRIORITY MODE — EMERGENCY PREEMPTION ACTIVE
                  </p>
                  <p className="mt-0.5 text-sm text-slate-200">
                    {activeEmergencies.map((em, i) => (
                      <React.Fragment key={em.direction}>
                        {i > 0 && ' · '}
                        <strong>{formatEmergencyLabel(em.type)}</strong> on{' '}
                        <strong className="text-orange-300">{em.direction} Road</strong>
                        {currentRoadItem?.direction === em.direction
                          ? ' (Active Green — Tracking Exit)'
                          : em.pending
                          ? ' (Safe Transition Queued)'
                          : ''}
                      </React.Fragment>
                    ))}
                  </p>
                </div>
              </div>
              <span className="font-mono text-xs font-semibold text-orange-200">
                Emergency GREEN → YELLOW → Required ALL-RED → Highest-Density GREEN
              </span>
            </div>
          </div>
        ) : (
          <div className="glass-panel rounded-xl px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-xs text-slate-300">
              <ShieldAlert className="h-4 w-4 text-sky-400 shrink-0" />
              <span>
                Normal Traffic Mode — Priority releases immediately upon emergency exit and selects the highest-density lane.
              </span>
            </div>
            <span className="font-mono text-xs text-slate-400">PRIORITY MODE: STANDBY</span>
          </div>
        )}

        {/* Dedicated Emergency Vehicle Input Panel */}
        <EmergencyInputPanel
          activeEmergencies={activeEmergencies}
          lastEmergencyResolution={lastEmergencyResolution}
          currentRoadItem={currentRoadItem}
          phase={phase}
          onSubmitEmergency={onSubmitEmergency}
        />

        {/* Road-by-Road Emergency Status Overview */}
        <section className="glass-panel rounded-2xl p-5 sm:p-6">
          <div className="border-b border-slate-700/60 pb-3.5">
            <h3 className="font-display text-base font-semibold text-white">
              Directional Emergency Dispatch Status
            </h3>
            <p className="text-xs text-slate-400">
              All conflicting approaches remain strictly RED during priority preemption and resume normal density scheduling afterward
            </p>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            {ROAD_DIRECTIONS.map((dir) => {
              const road = roads[dir];
              const isActiveEmergency = road.emergency !== 'NONE';

              return (
                <div
                  key={dir}
                  className={`rounded-xl border p-4 transition-colors ${
                    isActiveEmergency
                      ? 'border-orange-500/50 bg-orange-950/20'
                      : 'border-slate-700/70 bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <h4 className="font-display text-sm font-semibold text-white">
                        {dir} Road
                      </h4>
                      <p className="font-mono text-xs text-slate-400 tabular-nums">
                        Queue: {road.vehicleCount} · Status: {formatEmergencyLabel(road.emergency)}
                      </p>
                    </div>
                    {road.emergency === 'AMBULANCE' && (
                      <Ambulance className="h-5 w-5 text-orange-300" />
                    )}
                    {road.emergency === 'FIRE_ENGINE' && (
                      <Flame className="h-5 w-5 text-red-400" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    );
  }
);
EmergencyAlerts.displayName = 'EmergencyAlerts';
