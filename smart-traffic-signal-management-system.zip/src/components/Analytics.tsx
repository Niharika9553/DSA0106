import React, { useMemo } from 'react';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import { Ambulance, BarChart3, Clock, Flame, Layers, Siren } from 'lucide-react';
import { RoadDirection, RoadInput, ScheduledRoad, TrafficCycleRecord } from '../types/traffic';
import { LiveVehicleMetrics } from '../hooks/useTrafficSystem';
import { CHART_FONT_FAMILY, CHART_GRID_COLOR, CHART_TICK_COLOR } from '../utils/chartSetup';
import { ALL_RED_CLEARANCE_SECONDS, ROAD_DIRECTIONS, YELLOW_CLEARANCE_SECONDS } from '../utils/trafficEngine';

interface AnalyticsProps {
  roads: Record<RoadDirection, RoadInput>;
  schedule: ScheduledRoad[];
  history: TrafficCycleRecord[];
  vehicleMetrics: LiveVehicleMetrics;
}

export const Analytics: React.FC<AnalyticsProps> = React.memo(
  ({ roads, schedule, history, vehicleMetrics }) => {
    const stats = useMemo(() => {
      const cumulative: Record<RoadDirection, number> = {
        North: roads.North.vehicleCount,
        South: roads.South.vehicleCount,
        East: roads.East.vehicleCount,
        West: roads.West.vehicleCount,
      };

      let ambulanceCount = 0;
      let fireEngineCount = 0;
      let emergencyCycles = 0;

      for (const dir of ROAD_DIRECTIONS) {
        if (roads[dir].emergency === 'AMBULANCE') ambulanceCount++;
        if (roads[dir].emergency === 'FIRE_ENGINE') fireEngineCount++;
      }

      for (const c of history) {
        for (const dir of ROAD_DIRECTIONS) {
          cumulative[dir] += c.vehicleCounts[dir];
        }
        if (c.emergencies.length > 0) emergencyCycles++;
        for (const em of c.emergencies) {
          if (em.type === 'AMBULANCE') ambulanceCount++;
          if (em.type === 'FIRE_ENGINE') fireEngineCount++;
        }
      }

      const totalHandled = ROAD_DIRECTIONS.reduce((sum, d) => sum + cumulative[d], 0);

      // Signal waiting time estimate per direction based on earlier green + yellow + all-red clearance phases
      const waitingTimes: Record<RoadDirection, number> = {
        North: 0,
        South: 0,
        East: 0,
        West: 0,
      };
      let elapsedWait = 0;
      for (const item of schedule) {
        if (item.skipped) {
          waitingTimes[item.direction] = 0;
        } else {
          waitingTimes[item.direction] = elapsedWait;
          elapsedWait +=
            item.greenDuration + YELLOW_CLEARANCE_SECONDS + ALL_RED_CLEARANCE_SECONDS;
        }
      }

      return {
        cumulative,
        totalHandled,
        ambulanceCount,
        fireEngineCount,
        emergencyCycles,
        waitingTimes,
      };
    }, [roads, schedule, history]);

    const countByDirectionData = useMemo(
      () => ({
        labels: ['North', 'South', 'East', 'West'],
        datasets: [
          {
            label: 'Current Detected Count',
            data: ROAD_DIRECTIONS.map((d) => roads[d].vehicleCount),
            backgroundColor: 'rgba(56, 189, 248, 0.85)',
            borderRadius: 6,
          },
          {
            label: 'Crossed Intersection',
            data: ROAD_DIRECTIONS.map((d) => vehicleMetrics.crossedByDir[d]),
            backgroundColor: 'rgba(34, 197, 94, 0.72)',
            borderRadius: 6,
          },
          {
            label: 'Cumulative Count',
            data: ROAD_DIRECTIONS.map((d) => stats.cumulative[d]),
            backgroundColor: 'rgba(148, 163, 184, 0.45)',
            borderRadius: 6,
          },
        ],
      }),
      [roads, stats.cumulative, vehicleMetrics.crossedByDir]
    );

    const densityComparisonData = useMemo(
      () => ({
        labels: ['North', 'South', 'East', 'West'],
        datasets: [
          {
            data: ROAD_DIRECTIONS.map((d) => roads[d].vehicleCount),
            backgroundColor: [
              'rgba(56, 189, 248, 0.85)',
              'rgba(34, 197, 94, 0.85)',
              'rgba(249, 115, 22, 0.85)',
              'rgba(250, 204, 21, 0.85)',
            ],
            borderColor: '#091121',
            borderWidth: 2,
          },
        ],
      }),
      [roads]
    );

    const waitingTimeData = useMemo(
      () => ({
        labels: ['North', 'South', 'East', 'West'],
        datasets: [
          {
            label: 'Signal Waiting Time (seconds)',
            data: ROAD_DIRECTIONS.map((d) => stats.waitingTimes[d]),
            backgroundColor: 'rgba(250, 204, 21, 0.78)',
            borderRadius: 6,
          },
          {
            label: 'Allocated Green Time (seconds)',
            data: ROAD_DIRECTIONS.map(
              (d) => schedule.find((s) => s.direction === d)?.greenDuration ?? 0
            ),
            backgroundColor: 'rgba(34, 197, 94, 0.78)',
            borderRadius: 6,
          },
        ],
      }),
      [stats.waitingTimes, schedule]
    );

    const historyLineData = useMemo(() => {
      const recent = history.slice(-14);
      return {
        labels: recent.map((c) => `Cycle ${c.cycleNumber}`),
        datasets: [
          {
            label: 'Total Vehicles Detected',
            data: recent.map((c) => c.totalVehicles),
            borderColor: '#38bdf8',
            backgroundColor: 'rgba(56, 189, 248, 0.14)',
            borderWidth: 2.5,
            tension: 0.3,
            fill: true,
          },
          {
            label: 'Weighted Density Index',
            data: recent.map((c) => c.weightedScore),
            borderColor: '#22c55e',
            borderWidth: 2,
            tension: 0.3,
            fill: false,
          },
        ],
      };
    }, [history]);

    return (
      <div className="space-y-6">
        {/* Summary KPIs */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <div className="glass-panel rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Vehicles Cleared Live</span>
              <BarChart3 className="h-4 w-4 text-sky-400" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
              {vehicleMetrics.totalCrossed}
            </p>
            <p className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
              Cumulative Logged: {stats.totalHandled}
            </p>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Ambulance Priority Events</span>
              <Ambulance className="h-4 w-4 text-orange-400" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-orange-300 tabular-nums">
              {stats.ambulanceCount}
            </p>
            <p className="mt-1 text-xs text-slate-400">Safe all-red cleared dispatches</p>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Fire Engine Priority Events</span>
              <Flame className="h-4 w-4 text-red-400" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-red-300 tabular-nums">
              {stats.fireEngineCount}
            </p>
            <p className="mt-1 text-xs text-slate-400">Safe all-red cleared dispatches</p>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Emergency Cycles Logged</span>
              <Siren className="h-4 w-4 text-amber-400" />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
              {stats.emergencyCycles}{' '}
              <span className="text-xs font-normal text-slate-400">
                / {history.length} cycles
              </span>
            </p>
            <p className="mt-1 text-xs text-slate-400">Historical priority activations</p>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <section className="glass-panel rounded-2xl p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold text-white">
                  Vehicle Count & Crossed Telemetry by Direction
                </h3>
                <p className="text-xs text-slate-400">Detected vs crossed vs cumulative vehicles</p>
              </div>
              <BarChart3 className="h-4 w-4 text-sky-400" />
            </div>
            <div className="h-72">
              <Bar
                data={countByDirectionData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      labels: { color: '#cbd5e1', font: { family: CHART_FONT_FAMILY, size: 11 } },
                    },
                  },
                  scales: {
                    x: { grid: { color: CHART_GRID_COLOR }, ticks: { color: CHART_TICK_COLOR } },
                    y: { beginAtZero: true, grid: { color: CHART_GRID_COLOR }, ticks: { color: CHART_TICK_COLOR } },
                  },
                }}
              />
            </div>
          </section>

          <section className="glass-panel rounded-2xl p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold text-white">
                  Traffic Density Comparison
                </h3>
                <p className="text-xs text-slate-400">Directional share of active intersection load</p>
              </div>
              <Layers className="h-4 w-4 text-sky-400" />
            </div>
            <div className="h-72 flex items-center justify-center">
              <Doughnut
                data={densityComparisonData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'right',
                      labels: { color: '#cbd5e1', font: { family: CHART_FONT_FAMILY, size: 12 }, padding: 14 },
                    },
                  },
                }}
              />
            </div>
          </section>

          <section className="glass-panel rounded-2xl p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold text-white">
                  Signal Waiting Time vs Green Allocation (Count × 2s)
                </h3>
                <p className="text-xs text-slate-400">Queue wait time before receiving proportional GREEN signal</p>
              </div>
              <Clock className="h-4 w-4 text-sky-400" />
            </div>
            <div className="h-72">
              <Bar
                data={waitingTimeData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      labels: { color: '#cbd5e1', font: { family: CHART_FONT_FAMILY, size: 11 } },
                    },
                  },
                  scales: {
                    x: { grid: { color: CHART_GRID_COLOR }, ticks: { color: CHART_TICK_COLOR } },
                    y: { beginAtZero: true, grid: { color: CHART_GRID_COLOR }, ticks: { color: CHART_TICK_COLOR } },
                  },
                }}
              />
            </div>
          </section>

          <section className="glass-panel rounded-2xl p-5">
            <div className="mb-4">
              <h3 className="font-display text-base font-semibold text-white">
                Traffic History Trend
              </h3>
              <p className="text-xs text-slate-400">Detected vehicle volume across completed cycles</p>
            </div>
            <div className="h-72">
              <Line
                data={historyLineData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      labels: { color: '#cbd5e1', font: { family: CHART_FONT_FAMILY, size: 11 } },
                    },
                  },
                  scales: {
                    x: { grid: { color: CHART_GRID_COLOR }, ticks: { color: CHART_TICK_COLOR } },
                    y: { beginAtZero: true, grid: { color: CHART_GRID_COLOR }, ticks: { color: CHART_TICK_COLOR } },
                  },
                }}
              />
            </div>
          </section>
        </div>
      </div>
    );
  }
);
Analytics.displayName = 'Analytics';
