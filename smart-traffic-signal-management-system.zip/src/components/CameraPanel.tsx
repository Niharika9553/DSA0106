import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Camera,
  CameraOff,
  Cpu,
  Film,
  Pause,
  Play,
  RotateCcw,
  Upload,
} from 'lucide-react';
import {
  DetectedObjectBox,
  DetectionSourceMode,
  EmergencyType,
  OperatingMode,
  RoadDirection,
  SimulationStatus,
  VehicleClass,
} from '../types/traffic';
import { CppEngineTelemetry } from '../hooks/useTrafficSystem';
import {
  FrameVehicleDetectorAndTracker,
  renderPrerecordedDemoFrame,
} from '../utils/videoDetector';

interface CameraPanelProps {
  operatingMode: OperatingMode;
  simulationStatus: SimulationStatus;
  sourceMode: DetectionSourceMode;
  cameraActive: boolean;
  detectionRunning: boolean;
  detectedBoxes: DetectedObjectBox[];
  cppEngine: CppEngineTelemetry;
  onSwitchMode: (mode: OperatingMode) => void;
  onSetCameraActive: (active: boolean) => void;
  onSetDetectionRunning: (running: boolean) => void;
  onSetDetectedBoxes: (boxes: DetectedObjectBox[]) => void;
  onPrepareForLiveDetection: (mode: DetectionSourceMode) => void;
  onRecordDetectedVehicle: (
    direction: RoadDirection,
    vehicleClass: VehicleClass,
    emergency?: EmergencyType
  ) => void;
  onPauseSimulation: () => void;
  onResumeSimulation: () => void;
  onResetSimulation: () => void;
  onConnectCppEngine: () => Promise<{ ok: boolean; error?: string }>;
  onDisconnectCppEngine: () => void;
}

export const CameraPanel: React.FC<CameraPanelProps> = React.memo(
  ({
    operatingMode,
    simulationStatus,
    sourceMode,
    cameraActive,
    detectionRunning,
    detectedBoxes,
    cppEngine,
    onSwitchMode,
    onSetCameraActive,
    onSetDetectionRunning,
    onSetDetectedBoxes,
    onPrepareForLiveDetection,
    onRecordDetectedVehicle,
    onPauseSimulation,
    onResumeSimulation,
    onResetSimulation,
    onConnectCppEngine,
    onDisconnectCppEngine,
  }) => {
    const videoRef = useRef<HTMLVideoElement | null>(null);
    const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const demoSourceCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const workCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const uploadedUrlRef = useRef<string | null>(null);
    const trackerRef = useRef<FrameVehicleDetectorAndTracker>(
      new FrameVehicleDetectorAndTracker()
    );

    const [cameraError, setCameraError] = useState<string | null>(null);
    const [statusMessage, setStatusMessage] = useState<string>(
      'Ready: Connect C++ OpenCV + YOLO engine (:8080), start webcam, upload a traffic video, or use Manual Mode.'
    );
    const [cppFrameTick, setCppFrameTick] = useState<number>(0);

    const stopMediaTracks = () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.pause();
        videoRef.current.srcObject = null;
        videoRef.current.removeAttribute('src');
        videoRef.current.load();
      }
      if (uploadedUrlRef.current) {
        URL.revokeObjectURL(uploadedUrlRef.current);
        uploadedUrlRef.current = null;
      }
    };

    useEffect(() => {
      return () => stopMediaTracks();
    }, []);

    // Controlled 200ms JPEG polling from C++ Engine when connected & active
    useEffect(() => {
      if (sourceMode !== 'CPP_ENGINE' || !cppEngine.connected || !cppEngine.cameraActive) {
        return;
      }
      const timer = window.setInterval(() => {
        setCppFrameTick((t) => t + 1);
      }, 200);
      return () => window.clearInterval(timer);
    }, [sourceMode, cppEngine.connected, cppEngine.cameraActive]);

    // Controlled frame processing loop (only when browser camera / uploaded video / explicit demo is active)
    useEffect(() => {
      if (!cameraActive || sourceMode === 'NONE' || sourceMode === 'CPP_ENGINE') {
        return;
      }

      let rafId = 0;
      let lastProcessMs = 0;
      const demoStartMs = performance.now();

      const drawOverlayBoxes = (
        ctx: CanvasRenderingContext2D,
        w: number,
        h: number,
        boxes: DetectedObjectBox[]
      ) => {
        ctx.save();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
        ctx.setLineDash([6, 6]);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(w, h);
        ctx.moveTo(w, 0);
        ctx.lineTo(0, h);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.font = '600 11px "JetBrains Mono", monospace';
        ctx.fillStyle = 'rgba(148, 163, 184, 0.8)';
        ctx.fillText('NORTH ROI', w / 2 - 32, 18);
        ctx.fillText('SOUTH ROI', w / 2 - 32, h - 10);
        ctx.fillText('WEST ROI', 10, h / 2);
        ctx.fillText('EAST ROI', w - 68, h / 2);

        for (const b of boxes) {
          const bx = b.x * w;
          const by = b.y * h;
          const bw = b.w * w;
          const bh = b.h * h;

          const boxColor =
            b.emergency !== 'NONE'
              ? '#f97316'
              : b.vehicleClass === 'bus'
              ? '#facc15'
              : b.vehicleClass === 'truck'
              ? '#a78bfa'
              : '#38bdf8';

          ctx.strokeStyle = boxColor;
          ctx.lineWidth = 2;
          ctx.strokeRect(bx, by, bw, bh);

          const label = `#${b.trackId} ${b.vehicleClass.toUpperCase()} ${Math.round(
            b.confidence * 100
          )}% [${b.direction}]`;
          const textW = ctx.measureText(label).width + 10;
          const labelY = Math.max(18, by);

          ctx.fillStyle = boxColor;
          ctx.fillRect(bx, labelY - 17, textW, 17);
          ctx.fillStyle = '#070d19';
          ctx.fillText(label, bx + 5, labelY - 4);
        }
        ctx.restore();
      };

      const step = (now: number) => {
        const overlay = overlayCanvasRef.current;
        if (!overlay) {
          rafId = window.requestAnimationFrame(step);
          return;
        }
        const ctx = overlay.getContext('2d');
        if (!ctx) {
          rafId = window.requestAnimationFrame(step);
          return;
        }

        if (sourceMode === 'PRERECORDED_DEMO') {
          if (!demoSourceCanvasRef.current) {
            demoSourceCanvasRef.current = document.createElement('canvas');
            demoSourceCanvasRef.current.width = 640;
            demoSourceCanvasRef.current.height = 360;
          }
          const elapsedSec = (now - demoStartMs) / 1000;
          const rawBoxes = renderPrerecordedDemoFrame(demoSourceCanvasRef.current, elapsedSec);
          ctx.clearRect(0, 0, overlay.width, overlay.height);
          ctx.drawImage(demoSourceCanvasRef.current, 0, 0, overlay.width, overlay.height);

          if (detectionRunning && simulationStatus === 'RUNNING' && now - lastProcessMs >= 160) {
            lastProcessMs = now;
            const { boxes, newlyCounted } = trackerRef.current.updateTracks(rawBoxes);
            onSetDetectedBoxes(boxes);
            for (const item of newlyCounted) {
              onRecordDetectedVehicle(item.direction, item.vehicleClass, item.emergency);
            }
            drawOverlayBoxes(ctx, overlay.width, overlay.height, boxes);
          } else if (detectionRunning) {
            drawOverlayBoxes(ctx, overlay.width, overlay.height, detectedBoxes);
          }
        } else if (sourceMode === 'CAMERA' || sourceMode === 'VIDEO_UPLOAD') {
          const video = videoRef.current;
          if (video && video.readyState >= 2) {
            ctx.drawImage(video, 0, 0, overlay.width, overlay.height);

            if (detectionRunning && simulationStatus === 'RUNNING' && now - lastProcessMs >= 180) {
              lastProcessMs = now;
              if (!workCanvasRef.current) {
                workCanvasRef.current = document.createElement('canvas');
              }
              const { boxes, newlyCounted } = trackerRef.current.processFrame(
                video,
                workCanvasRef.current
              );
              onSetDetectedBoxes(boxes);
              for (const item of newlyCounted) {
                onRecordDetectedVehicle(item.direction, item.vehicleClass, item.emergency);
              }
              drawOverlayBoxes(ctx, overlay.width, overlay.height, boxes);
            } else if (detectionRunning) {
              drawOverlayBoxes(ctx, overlay.width, overlay.height, detectedBoxes);
            }
          }
        }

        rafId = window.requestAnimationFrame(step);
      };

      rafId = window.requestAnimationFrame(step);
      return () => window.cancelAnimationFrame(rafId);
    }, [
      cameraActive,
      sourceMode,
      detectionRunning,
      simulationStatus,
      detectedBoxes,
      onRecordDetectedVehicle,
      onSetDetectedBoxes,
    ]);

    const handleStartCamera = async () => {
      setCameraError(null);
      stopMediaTracks();
      trackerRef.current.reset();

      // First try C++ OpenCV + YOLO ONNX Engine if connected or connecting in CAMERA MODE
      if (cppEngine.connected) {
        try {
          const res = await fetch('http://localhost:8080/api/camera/start', {
            method: 'POST',
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok || data.ok === false) {
            throw new Error(data.error || 'C++ OpenCV failed to open camera device.');
          }
          onSetCameraActive(true);
          onSetDetectionRunning(true);
          setStatusMessage('C++ OpenCV camera & YOLO ONNX detector running.');
          return;
        } catch (err) {
          setCameraError(
            err instanceof Error
              ? err.message
              : 'C++ engine could not open local camera.'
          );
          return;
        }
      }

      // If not connected to C++ backend, attempt browser camera strictly via getUserMedia (never fake!)
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError(
          'Camera unavailable: Local C++ OpenCV engine is offline and browser getUserMedia is unavailable. Switch to MANUAL MODE or upload a video file.'
        );
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 360 } },
          audio: false,
        });
        streamRef.current = stream;
        onPrepareForLiveDetection('CAMERA');
        onSetCameraActive(true);
        onSetDetectionRunning(false);
        setStatusMessage('Browser camera connected. Click START DETECTION to count vehicles.');

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
      } catch {
        setCameraError(
          'No physical camera found or permission denied, and C++ OpenCV engine is offline at http://localhost:8080. Retain MANUAL MODE or upload a real traffic video.'
        );
        onSetCameraActive(false);
      }
    };

    const handleStopCamera = async () => {
      setCameraError(null);
      stopMediaTracks();
      onSetDetectionRunning(false);
      onSetCameraActive(false);
      onSetDetectedBoxes([]);
      trackerRef.current.reset();

      if (cppEngine.connected) {
        await fetch('http://localhost:8080/api/camera/stop', { method: 'POST' }).catch(
          () => {}
        );
      }

      const overlay = overlayCanvasRef.current;
      if (overlay) {
        const ctx = overlay.getContext('2d');
        ctx?.clearRect(0, 0, overlay.width, overlay.height);
      }
      setStatusMessage('Camera stopped and resources released.');
    };

    const handleVideoFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      setCameraError(null);
      stopMediaTracks();
      trackerRef.current.reset();

      const objectUrl = URL.createObjectURL(file);
      uploadedUrlRef.current = objectUrl;
      onPrepareForLiveDetection('VIDEO_UPLOAD');
      onSetCameraActive(true);
      onSetDetectionRunning(true);
      onResumeSimulation();
      setStatusMessage(`Analyzing uploaded traffic video: ${file.name}`);

      if (videoRef.current) {
        videoRef.current.src = objectUrl;
        videoRef.current.loop = true;
        await videoRef.current.play().catch(() => {
          setCameraError('Could not decode the selected video file in this browser.');
        });
      }
      e.target.value = '';
    };

    const handleStartPrerecordedDemo = () => {
      setCameraError(null);
      stopMediaTracks();
      trackerRef.current.reset();
      onPrepareForLiveDetection('PRERECORDED_DEMO');
      onSetCameraActive(true);
      onSetDetectionRunning(true);
      onResumeSimulation();
      setStatusMessage(
        'Prerecorded-Video Demonstration Mode active (18s deterministic multi-lane clip).'
      );
    };

    const handleStartDetection = async () => {
      setCameraError(null);
      if (!cameraActive && !(sourceMode === 'CPP_ENGINE' && cppEngine.connected)) {
        setCameraError('Start camera or load a video source before starting detection.');
        return;
      }
      onResumeSimulation();
      onSetDetectionRunning(true);
      setStatusMessage('Vehicle detection and tracking active.');

      if (cppEngine.connected) {
        await fetch('http://localhost:8080/api/simulation/resume', { method: 'POST' }).catch(
          () => {}
        );
      }
    };

    const handlePauseDetection = async () => {
      onPauseSimulation();
      onSetDetectionRunning(false);
      setStatusMessage('Detection counting and signal updates paused.');
    };

    const handleConnectCpp = async () => {
      setCameraError(null);
      const res = await onConnectCppEngine();
      if (!res.ok && res.error) {
        setCameraError(res.error);
      } else {
        setStatusMessage('Connected to C++11 OpenCV + YOLO ONNX engine at localhost:8080.');
      }
    };

    return (
      <section className="glass-panel rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/60 pb-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-white">
              Camera & YOLO Vehicle Detection Panel
            </h2>
            <p className="text-xs text-slate-400">
              Active Mode:{' '}
              <strong className="font-mono text-sky-300">
                {operatingMode === 'CAMERA' ? 'CAMERA MODE' : 'MANUAL MODE'}
              </strong>{' '}
              · C++ OpenCV + YOLO ONNX Engine (localhost:8080)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {cppEngine.connected ? (
              <button
                type="button"
                onClick={onDisconnectCppEngine}
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/25"
              >
                <Cpu className="h-3.5 w-3.5" />
                <span>C++ Connected · {cppEngine.modelStatus}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleConnectCpp}
                className="inline-flex items-center gap-1.5 rounded-lg border border-sky-500/30 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-sky-300 hover:bg-slate-800"
              >
                <Cpu className="h-3.5 w-3.5" />
                <span>Connect C++ Engine (:8080)</span>
              </button>
            )}
          </div>
        </div>

        {/* Camera & YOLO Model Status Bar */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 px-3.5 py-2.5 text-xs">
            <span className="text-slate-400 block">Camera Connection Status</span>
            <span
              className={`font-mono font-semibold ${
                cppEngine.connected && cppEngine.cameraActive
                  ? 'text-emerald-400'
                  : cameraActive
                  ? 'text-sky-300'
                  : 'text-slate-300'
              }`}
            >
              {cppEngine.connected
                ? cppEngine.cameraActive
                  ? 'Connected (C++ OpenCV Feed)'
                  : 'C++ Engine Ready (Camera Stopped)'
                : cameraActive
                ? `Active (${sourceMode})`
                : 'Disconnected'}
            </span>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/60 px-3.5 py-2.5 text-xs">
            <span className="text-slate-400 block">YOLO ONNX Model Status</span>
            <span
              className={`font-mono font-semibold ${
                cppEngine.modelStatus === 'YOLO_ONNX_LOADED'
                  ? 'text-emerald-400'
                  : 'text-amber-300'
              }`}
            >
              {cppEngine.connected
                ? cppEngine.modelStatus
                : 'C++ Backend Offline (Use Manual Mode or Upload Video)'}
            </span>
          </div>
        </div>

        {/* Honest Error Display */}
        {(cameraError || cppEngine.cameraError || cppEngine.modelError) && (
          <div
            role="alert"
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-red-500/40 bg-red-950/30 px-4 py-3 text-xs text-red-200"
          >
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
              <span>
                {cameraError || cppEngine.cameraError || cppEngine.modelError}
              </span>
            </div>
            {operatingMode === 'CAMERA' && (
              <button
                type="button"
                onClick={() => onSwitchMode('MANUAL')}
                className="rounded-lg border border-sky-400/40 bg-sky-500/15 px-3 py-1.5 text-xs font-semibold text-sky-200 hover:bg-sky-500/25 whitespace-nowrap"
              >
                Switch to MANUAL MODE
              </button>
            )}
          </div>
        )}

        {/* Camera & Detection Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleStartCamera}
            className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-500 transition-colors whitespace-nowrap"
          >
            <Camera className="h-3.5 w-3.5" />
            <span>START CAMERA</span>
          </button>

          <button
            type="button"
            onClick={handleStopCamera}
            disabled={!cameraActive && !cppEngine.cameraActive}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 disabled:opacity-40 transition-colors whitespace-nowrap"
          >
            <CameraOff className="h-3.5 w-3.5 text-red-400" />
            <span>STOP CAMERA</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-sky-500/35 bg-sky-500/15 px-3.5 py-2 text-xs font-semibold text-sky-200 hover:bg-sky-500/25 transition-colors whitespace-nowrap"
          >
            <Upload className="h-3.5 w-3.5" />
            <span>UPLOAD VIDEO</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleVideoFileSelected}
            className="hidden"
            aria-label="Upload traffic video file"
          />

          <button
            type="button"
            onClick={handleStartDetection}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap"
          >
            <Play className="h-3.5 w-3.5" />
            <span>START DETECTION</span>
          </button>

          <button
            type="button"
            onClick={handlePauseDetection}
            className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500/35 bg-amber-500/15 px-3.5 py-2 text-xs font-semibold text-amber-200 hover:bg-amber-500/25 transition-colors whitespace-nowrap"
          >
            <Pause className="h-3.5 w-3.5" />
            <span>PAUSE DETECTION</span>
          </button>

          <button
            type="button"
            onClick={handleStartPrerecordedDemo}
            className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/35 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <Film className="h-3.5 w-3.5" />
            <span>PRERECORDED DEMO VIDEO</span>
          </button>

          <button
            type="button"
            onClick={() => {
              stopMediaTracks();
              trackerRef.current.reset();
              setCameraError(null);
              onResetSimulation();
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-red-500/35 bg-red-500/15 px-3.5 py-2 text-xs font-semibold text-red-200 hover:bg-red-500/25 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>RESET</span>
          </button>
        </div>

        {/* Inspection Viewport */}
        <div className="relative overflow-hidden rounded-xl border border-slate-700/80 bg-slate-950 aspect-video max-h-[340px] w-full flex items-center justify-center">
          <video ref={videoRef} muted playsInline className="hidden" />

          {sourceMode === 'CPP_ENGINE' && cppEngine.connected && cppEngine.cameraActive ? (
            <img
              src={`http://localhost:8080/api/frame.jpg?t=${cppFrameTick}`}
              alt="C++ OpenCV YOLO detection stream"
              referrerPolicy="no-referrer"
              className="h-full w-full object-contain"
            />
          ) : cameraActive ? (
            <canvas
              ref={overlayCanvasRef}
              width={640}
              height={360}
              className="h-full w-full object-contain"
            />
          ) : (
            <div className="flex flex-col items-center justify-center px-6 py-8 text-center">
              <CameraOff className="h-9 w-9 text-slate-600" />
              <p className="mt-2 font-display text-sm font-semibold text-slate-300">
                Camera Feed Inactive
              </p>
              <p className="mt-1 max-w-md text-xs text-slate-400">
                No fake live camera stream is shown. Connect the C++ OpenCV + YOLO backend,
                start a webcam, upload a traffic video, or launch Prerecorded Demo Video.
              </p>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <span>{statusMessage}</span>
          <span className="font-mono text-sky-300 tabular-nums">
            Tracked Objects: {detectedBoxes.length}
          </span>
        </div>
      </section>
    );
  }
);
CameraPanel.displayName = 'CameraPanel';
