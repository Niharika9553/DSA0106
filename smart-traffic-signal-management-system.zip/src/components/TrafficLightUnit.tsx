import React from 'react';
import { SignalColor } from '../types/traffic';

interface TrafficLightUnitProps {
  signal: SignalColor;
  orientation?: 'vertical' | 'horizontal';
  compact?: boolean;
}

export const TrafficLightUnit: React.FC<TrafficLightUnitProps> = ({
  signal,
  orientation = 'vertical',
  compact = false,
}) => {
  const sizeClass = compact ? 'h-3 w-3' : 'h-4 w-4';
  const containerPadding = compact ? 'p-1.5 gap-1.5' : 'p-2 gap-2';

  return (
    <div
      className={`inline-flex ${
        orientation === 'horizontal' ? 'flex-row' : 'flex-col'
      } items-center rounded-lg border border-slate-700/90 bg-slate-950 shadow-inner ${containerPadding}`}
      aria-label={`Traffic signal is ${signal}`}
    >
      <span
        className={`${sizeClass} rounded-full transition-all duration-200 ${
          signal === 'RED'
            ? 'bg-red-500 shadow-[0_0_12px_rgba(239,68,68,0.95)] ring-2 ring-red-400/50'
            : 'bg-red-950/70 border border-red-900/40'
        }`}
      />
      <span
        className={`${sizeClass} rounded-full transition-all duration-200 ${
          signal === 'YELLOW'
            ? 'bg-yellow-400 shadow-[0_0_12px_rgba(250,204,21,0.95)] ring-2 ring-yellow-300/50'
            : 'bg-yellow-950/60 border border-yellow-900/40'
        }`}
      />
      <span
        className={`${sizeClass} rounded-full transition-all duration-200 ${
          signal === 'GREEN'
            ? 'bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.95)] ring-2 ring-emerald-300/50'
            : 'bg-emerald-950/60 border border-emerald-900/40'
        }`}
      />
    </div>
  );
};
