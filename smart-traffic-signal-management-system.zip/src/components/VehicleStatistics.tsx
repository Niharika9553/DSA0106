import React from 'react';
import { Bike, Bus, Car, Truck } from 'lucide-react';
import { OperatingMode, RoadDirection, RoadInput } from '../types/traffic';
import { LiveVehicleMetrics } from '../hooks/useTrafficSystem';
import {
  classifyRoadDensityStatus,
  getHighestDensityDirection,
  getTotalVehicles,
  ROAD_DIRECTIONS,
} from '../utils/trafficEngine';
import { TrafficInputPanel } from './TrafficInputPanel';

interface VehicleStatisticsProps {
  roads: Record<RoadDirection, RoadInput>;
  operatingMode: OperatingMode;
  vehicleMetrics: LiveVehicleMetrics;
  onUpdateManualTraffic: (counts: Record<RoadDirection, number>) => void;
}

export const VehicleStatistics: React.FC<VehicleStatisticsProps> = React.memo(
  ({ roads, operatingMode, vehicleMetrics, onUpdateManualTraffic }) => {
    const total = getTotalVehicles(roads);
    const highest = getHighestDensityDirection(roads);

    return (
      <div className="space-y-6">
        {/* Live Traffic Density Breakdown */}
        <section className="glass-panel rounded-2xl p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/60 pb-4">
            <div>
              <h2 className="font-display text-lg font-semibold text-white">
                Traffic Density & Vehicle Class Statistics
              </h2>
              <p className="text-xs text-slate-400">
                Real-time directional counts, queued vs crossed telemetry, share percentage, and density status
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3 font-mono text-xs tabular-nums">
              <span className="text-slate-400">
                Detected: <strong className="text-white">{total}</strong>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Total Crossed:{' '}
                <strong className="text-emerald-300">{vehicleMetrics.totalCrossed}</strong>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                Highest:{' '}
                <strong className="text-sky-300">
                  {highest ? `${highest.direction} (${highest.count})` : 'None'}
                </strong>
              </span>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            {ROAD_DIRECTIONS.map((dir) => {
              const r = roads[dir];
              const pct = total > 0 ? Math.round((r.vehicleCount / total) * 100) : 0;
              const status = classifyRoadDensityStatus(r.vehicleCount);
              const queuedCount = vehicleMetrics.queuedByDir[dir];
              const crossedCount = vehicleMetrics.crossedByDir[dir];
              const statusColor =
                status === 'HIGH'
                  ? 'text-red-400'
                  : status === 'MEDIUM'
                  ? 'text-orange-400'
                  : 'text-emerald-400';

              return (
                <div
                  key={dir}
                  className="rounded-xl border border-slate-700/70 bg-slate-900/60 p-4"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-sm font-semibold text-white">
                      {dir} Road
                    </h3>
                    <span className={`font-mono text-xs font-bold ${statusColor}`}>
                      {status}
                    </span>
                  </div>

                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="font-mono text-2xl font-bold text-white tabular-nums">
                      {r.vehicleCount}
                    </span>
                    <span className="font-mono text-xs text-sky-300 tabular-nums">
                      {pct}% share
                    </span>
                  </div>

                  <div className="mt-1.5 flex items-center justify-between font-mono text-[11px] text-slate-400 tabular-nums">
                    <span>Queued: {queuedCount}</span>
                    <span className="text-emerald-300">Crossed: {crossedCount}</span>
                  </div>

                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full bg-sky-500 transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <div className="mt-3 grid grid-cols-4 gap-1 border-t border-slate-800 pt-2.5 text-[11px] text-slate-400 font-mono tabular-nums">
                    <div className="flex items-center gap-1" title="Cars">
                      <Car className="h-3 w-3 text-sky-400" />
                      <span>{r.classCounts.car}</span>
                    </div>
                    <div className="flex items-center gap-1" title="Buses">
                      <Bus className="h-3 w-3 text-yellow-400" />
                      <span>{r.classCounts.bus}</span>
                    </div>
                    <div className="flex items-center gap-1" title="Trucks">
                      <Truck className="h-3 w-3 text-slate-300" />
                      <span>{r.classCounts.truck}</span>
                    </div>
                    <div className="flex items-center gap-1" title="Motorcycles">
                      <Bike className="h-3 w-3 text-teal-400" />
                      <span>{r.classCounts.motorcycle}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Dedicated Manual Vehicle Density Input Panel */}
        <TrafficInputPanel
          roads={roads}
          operatingMode={operatingMode}
          onUpdateTraffic={onUpdateManualTraffic}
        />
      </div>
    );
  }
);
VehicleStatistics.displayName = 'VehicleStatistics';
