import React from 'react';
import {
  Camera,
  Menu,
  Pause,
  Play,
  RotateCcw,
  SlidersHorizontal,
  Square,
} from 'lucide-react';
import {
  NavSection,
  OperatingMode,
  SimulationSpeed,
  SimulationStatus,
} from '../types/traffic';

interface TopBarProps {
  activeSection: NavSection;
  operatingMode: OperatingMode;
  simulationStatus: SimulationStatus;
  speed: SimulationSpeed;
  onOpenMobileMenu: () => void;
  onSwitchMode: (mode: OperatingMode) => void;
  onStartSimulation: () => void;
  onPauseSimulation: () => void;
  onResumeSimulation: () => void;
  onStopSimulation: () => void;
  onResetSimulation: () => void;
  onChangeSpeed: (speed: SimulationSpeed) => void;
}

const SECTION_TITLES: Record<NavSection, string> = {
  dashboard: 'Smart Traffic Signal Management System',
  intersection: 'Four-Way Traffic Intersection',
  camera: 'Camera & AI Vehicle Detection',
  statistics: 'Vehicle Statistics & Density',
  controller: 'Traffic Signal Controller',
  emergency: 'Emergency Vehicle Priority',
  analytics: 'Traffic Analytics',
  history: 'Traffic History & Reports',
  cpp_guide: 'C++11 & YOLO ONNX Setup Guide',
};

export const TopBar: React.FC<TopBarProps> = React.memo(
  ({
    activeSection,
    operatingMode,
    simulationStatus,
    speed,
    onOpenMobileMenu,
    onSwitchMode,
    onStartSimulation,
    onPauseSimulation,
    onResumeSimulation,
    onStopSimulation,
    onResetSimulation,
    onChangeSpeed,
  }) => {
    return (
      <header className="sticky top-0 z-30 border-b border-sky-500/15 bg-[#070d19]/92 backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onOpenMobileMenu}
              className="rounded-lg border border-sky-500/20 bg-slate-900/70 p-2 text-slate-200 hover:bg-slate-800 lg:hidden"
              aria-label="Open navigation menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0">
              <h1 className="font-display text-base font-semibold tracking-tight text-white sm:text-lg truncate">
                {SECTION_TITLES[activeSection]}
              </h1>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Explicit Mode Switcher: MANUAL MODE vs CAMERA MODE */}
            <div
              className="flex items-center rounded-lg border border-sky-500/25 bg-slate-900 p-1"
              role="group"
              aria-label="Operating mode"
            >
              <button
                type="button"
                onClick={() => onSwitchMode('MANUAL')}
                className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                  operatingMode === 'MANUAL'
                    ? 'bg-sky-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <SlidersHorizontal className="h-3.5 w-3.5" />
                <span>MANUAL MODE</span>
              </button>
              <button
                type="button"
                onClick={() => onSwitchMode('CAMERA')}
                className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                  operatingMode === 'CAMERA'
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Camera className="h-3.5 w-3.5" />
                <span>CAMERA MODE</span>
              </button>
            </div>

            {/* Speed Selector */}
            <div
              className="flex items-center rounded-lg border border-slate-700 bg-slate-900 p-1"
              role="group"
              aria-label="Simulation speed"
            >
              {([1, 2, 5] as SimulationSpeed[]).map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => onChangeSpeed(val)}
                  className={`rounded-md px-2 py-1 font-mono text-xs font-medium transition-colors whitespace-nowrap ${
                    speed === val
                      ? 'bg-sky-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {val}x
                </button>
              ))}
            </div>

            {/* Simulation Controls: START, PAUSE, RESUME, STOP, RESET */}
            <button
              type="button"
              onClick={onStartSimulation}
              disabled={simulationStatus !== 'STOPPED'}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
            >
              <Play className="h-3.5 w-3.5" />
              <span>START SIMULATION</span>
            </button>

            <button
              type="button"
              onClick={onPauseSimulation}
              disabled={simulationStatus !== 'RUNNING'}
              className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500/35 bg-amber-500/15 px-3 py-2 text-xs font-semibold text-amber-200 hover:bg-amber-500/25 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
            >
              <Pause className="h-3.5 w-3.5" />
              <span>PAUSE SIMULATION</span>
            </button>

            <button
              type="button"
              onClick={onResumeSimulation}
              disabled={simulationStatus !== 'PAUSED'}
              className="inline-flex items-center gap-1.5 rounded-lg border border-sky-500/35 bg-sky-500/15 px-3 py-2 text-xs font-semibold text-sky-200 hover:bg-sky-500/25 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
            >
              <Play className="h-3.5 w-3.5" />
              <span>RESUME SIMULATION</span>
            </button>

            <button
              type="button"
              onClick={onStopSimulation}
              disabled={simulationStatus === 'STOPPED'}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
            >
              <Square className="h-3.5 w-3.5" />
              <span>STOP SIMULATION</span>
            </button>

            <button
              type="button"
              onClick={onResetSimulation}
              className="inline-flex items-center gap-1.5 rounded-lg border border-red-500/35 bg-red-500/15 px-3 py-2 text-xs font-semibold text-red-200 hover:bg-red-500/25 transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>RESET SIMULATION</span>
            </button>
          </div>
        </div>
      </header>
    );
  }
);
TopBar.displayName = 'TopBar';
