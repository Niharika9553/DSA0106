import React from 'react';
import {
  Activity,
  BarChart3,
  Camera,
  Code2,
  History,
  LayoutDashboard,
  Siren,
  SlidersHorizontal,
  TrafficCone,
  X,
} from 'lucide-react';
import { NavSection } from '../types/traffic';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  emergencyCount: number;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'intersection', label: 'Intersection View', icon: TrafficCone },
  { id: 'camera', label: 'Camera & AI Detection', icon: Camera },
  { id: 'statistics', label: 'Vehicle Statistics', icon: SlidersHorizontal },
  { id: 'controller', label: 'Signal Controller', icon: Activity },
  { id: 'emergency', label: 'Emergency Alerts', icon: Siren },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'history', label: 'Traffic History', icon: History },
  { id: 'cpp_guide', label: 'C++ & YOLO Setup', icon: Code2 },
];

export const Sidebar: React.FC<SidebarProps> = React.memo(
  ({ activeSection, onSelectSection, mobileOpen, onCloseMobile, emergencyCount }) => {
    const handleSelect = (id: NavSection) => {
    onSelectSection(id);
    onCloseMobile();
  };

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/75 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-68 flex-col border-r border-sky-500/15 bg-[#091121]/95 backdrop-blur-xl transition-transform duration-200 ease-out lg:static lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-sky-500/15 px-5 py-5">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-sky-500/15 border border-sky-400/30 text-sky-400">
              <TrafficCone className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="font-display text-sm font-semibold tracking-tight text-slate-100 truncate">
                Smart Traffic AI
              </p>
              <p className="text-xs text-slate-400 truncate">
                C++ · OpenCV · YOLO
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onCloseMobile}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-100 lg:hidden"
            aria-label="Close navigation menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4" aria-label="Primary navigation">
          <ul className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => handleSelect(item.id)}
                    className={`group flex w-full items-center justify-between gap-3 rounded-lg px-3.5 py-2.5 text-left text-sm font-medium transition-colors whitespace-nowrap ${
                      isActive
                        ? 'bg-sky-500/15 text-sky-300 border border-sky-400/25'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white border border-transparent'
                    }`}
                  >
                    <span className="flex items-center gap-3 min-w-0">
                      <Icon
                        className={`h-4 w-4 shrink-0 transition-colors ${
                          isActive
                            ? 'text-sky-400'
                            : 'text-slate-400 group-hover:text-slate-200'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {item.id === 'emergency' && emergencyCount > 0 && (
                      <span className="font-mono text-xs font-semibold text-orange-400 tabular-nums">
                        {emergencyCount}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t border-sky-500/15 px-5 py-4">
          <p className="text-xs font-medium text-slate-300">
            4-Way Signal Management
          </p>
          <p className="mt-0.5 text-xs text-slate-400">
            C++11 Engine + React UI
          </p>
        </div>
      </aside>
    </>
  );
});
Sidebar.displayName = 'Sidebar';
