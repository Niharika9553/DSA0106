import React from 'react';
import {
  ArrowUpRight,
  Camera,
  Car,
  CheckCircle2,
  Clock,
  PersonStanding,
  Siren,
  SlidersHorizontal,
  TrafficCone,
} from 'lucide-react';
import {
  DetectedObjectBox,
  DetectionSourceMode,
  EmergencyEventInfo,
  EmergencyResolutionInfo,
  EmergencyType,
  NavSection,
  OperatingMode,
  RoadDirection,
  RoadInput,
  ScheduledRoad,
  SignalColor,
  SimVehicle,
  SimulationPhase,
  SimulationStatus,
  VehicleClass,
} from '../types/traffic';
import { CppEngineTelemetry, LiveVehicleMetrics } from '../hooks/useTrafficSystem';
import { formatEmergencyLabel, ROAD_DIRECTIONS } from '../utils/trafficEngine';
import { CameraPanel } from './CameraPanel';
import { EmergencyInputPanel } from './EmergencyInputPanel';
import { Intersection } from './Intersection';
import { TrafficInputPanel } from './TrafficInputPanel';

interface DashboardProps {
  operatingMode: OperatingMode;
  simulationStatus: SimulationStatus;
  roads: Record<RoadDirection, RoadInput>;
  vehiclesRef: React.MutableRefObject<SimVehicle[]>;
  vehicleMetrics: LiveVehicleMetrics;
  schedule: ScheduledRoad[];
  currentRoadItem: ScheduledRoad | null;
  roadSignals: Record<RoadDirection, SignalColor>;
  phase: SimulationPhase;
  secondsRemaining: number;
  totalVehicles: number;
  activeEmergencies: EmergencyEventInfo[];
  lastEmergencyResolution: EmergencyResolutionInfo | null;
  sourceMode: DetectionSourceMode;
  cameraActive: boolean;
  detectionRunning: boolean;
  detectedBoxes: DetectedObjectBox[];
  cppEngine: CppEngineTelemetry;
  onSwitchMode: (mode: OperatingMode) => void;
  onUpdateManualTraffic: (counts: Record<RoadDirection, number>) => void;
  onSubmitEmergency: (
    direction: RoadDirection,
    type: Exclude<EmergencyType, 'NONE'>
  ) => void;
  onActivatePedestrian: () => void;
  onSetCameraActive: (active: boolean) => void;
  onSetDetectionRunning: (running: boolean) => void;
  onSetDetectedBoxes: (boxes: DetectedObjectBox[]) => void;
  onPrepareForLiveDetection: (mode: DetectionSourceMode) => void;
  onRecordDetectedVehicle: (
    direction: RoadDirection,
    vehicleClass: VehicleClass,
    emergency?: EmergencyType
  ) => void;
  onPauseSimulation: () => void;
  onResumeSimulation: () => void;
  onResetSimulation: () => void;
  onConnectCppEngine: () => Promise<{ ok: boolean; error?: string }>;
  onDisconnectCppEngine: () => void;
  registerCanvasRenderer: (fn: ((nowMs: number) => void) | null) => void;
  onNavigate: (section: NavSection) => void;
}

export const Dashboard: React.FC<DashboardProps> = React.memo(
  ({
    operatingMode,
    simulationStatus,
    roads,
    vehiclesRef,
    vehicleMetrics,
    schedule,
    currentRoadItem,
    roadSignals,
    phase,
    secondsRemaining,
    totalVehicles,
    activeEmergencies,
    lastEmergencyResolution,
    sourceMode,
    cameraActive,
    detectionRunning,
    detectedBoxes,
    cppEngine,
    onSwitchMode,
    onUpdateManualTraffic,
    onSubmitEmergency,
    onActivatePedestrian,
    onSetCameraActive,
    onSetDetectionRunning,
    onSetDetectedBoxes,
    onPrepareForLiveDetection,
    onRecordDetectedVehicle,
    onPauseSimulation,
    onResumeSimulation,
    onResetSimulation,
    onConnectCppEngine,
    onDisconnectCppEngine,
    registerCanvasRenderer,
    onNavigate,
  }) => {
    const activeGreenDir =
      phase === 'ROAD_GREEN' && currentRoadItem ? currentRoadItem.direction : 'None';

    const emergencyText =
      activeEmergencies.length > 0
        ? activeEmergencies
            .map((e) => `${formatEmergencyLabel(e.type)} (${e.direction})`)
            .join(', ')
        : 'None';

    const pedestrianText =
      phase === 'PEDESTRIAN_CROSSING'
        ? `WALK (${secondsRemaining}s)`
        : "DON'T WALK";

    const cameraStatusText = cppEngine.connected
      ? cppEngine.cameraActive
        ? 'Connected (C++ OpenCV)'
        : 'C++ Ready'
      : cameraActive
      ? `Active (${sourceMode})`
      : 'Disconnected';

    return (
      <div className="space-y-6">
        {/* Live State Summary Strip (Section 10) */}
        <section
          aria-label="Live traffic management telemetry"
          className="grid grid-cols-2 gap-3.5 md:grid-cols-4 xl:grid-cols-6"
        >
          {ROAD_DIRECTIONS.map((dir) => {
            const sig = roadSignals[dir];
            const sched = schedule.find((s) => s.direction === dir);
            return (
              <div key={dir} className="glass-panel rounded-xl p-3.5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>{dir} Road</span>
                  <span
                    className={`font-mono font-bold ${
                      sig === 'GREEN'
                        ? 'text-emerald-400'
                        : sig === 'YELLOW'
                        ? 'text-yellow-300'
                        : 'text-red-400'
                    }`}
                  >
                    {sig}
                  </span>
                </div>
                <p className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
                  {roads[dir].vehicleCount}
                </p>
                <p className="mt-0.5 font-mono text-[11px] text-slate-400 tabular-nums">
                  Green: {sched?.skipped ? 'Skip (0s)' : `${sched?.greenDuration ?? 0}s`}
                </p>
              </div>
            );
          })}

          <div className="glass-panel rounded-xl p-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Total Detected</span>
              <Car className="h-4 w-4 text-sky-400" />
            </div>
            <p className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
              {totalVehicles}
            </p>
            <p className="mt-0.5 font-mono text-[11px] text-emerald-300 tabular-nums">
              Crossed: {vehicleMetrics.totalCrossed}
            </p>
          </div>

          <div className="glass-panel rounded-xl p-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Active Mode</span>
              <SlidersHorizontal className="h-4 w-4 text-sky-400" />
            </div>
            <p className="mt-1 font-display text-base font-bold text-sky-300">
              {operatingMode === 'MANUAL' ? 'MANUAL MODE' : 'CAMERA MODE'}
            </p>
            <p className="mt-0.5 font-mono text-[11px] text-slate-400">
              Sim: {simulationStatus}
            </p>
          </div>

          <div className="glass-panel rounded-xl p-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Current GREEN</span>
              <TrafficCone className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="mt-1 font-display text-lg font-bold text-emerald-300">
              {activeGreenDir}
            </p>
            <p className="mt-0.5 font-mono text-[11px] text-slate-400 truncate">
              State: {phase}
            </p>
          </div>

          <div className="glass-panel rounded-xl p-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Countdown</span>
              <Clock className="h-4 w-4 text-sky-400" />
            </div>
            <p className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
              {secondsRemaining}s
            </p>
            <p className="mt-0.5 font-mono text-[11px] text-slate-400 tabular-nums">
              Allocated: {currentRoadItem?.greenDuration ?? 0}s
            </p>
          </div>

          <div className="glass-panel rounded-xl p-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Emergency</span>
              <Siren
                className={`h-4 w-4 ${
                  activeEmergencies.length > 0 ? 'text-orange-400' : 'text-slate-500'
                }`}
              />
            </div>
            <p
              className={`mt-1 font-display text-sm font-semibold truncate ${
                activeEmergencies.length > 0 ? 'text-orange-300' : 'text-slate-300'
              }`}
            >
              {emergencyText}
            </p>
            <p className="mt-0.5 text-[11px] text-slate-400">
              {activeEmergencies.length > 0 ? 'PRIORITY MODE' : 'Normal Flow'}
            </p>
          </div>

          <div className="glass-panel rounded-xl p-3.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Camera Status</span>
              <Camera className="h-4 w-4 text-sky-400" />
            </div>
            <p className="mt-1 font-display text-sm font-semibold text-slate-200 truncate">
              {cameraStatusText}
            </p>
            <p className="mt-0.5 font-mono text-[11px] text-slate-400 truncate">
              {cppEngine.modelStatus}
            </p>
          </div>

          <div className="glass-panel rounded-xl p-3.5 sm:col-span-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <span className="text-xs text-slate-400 block">Pedestrian Crossing</span>
                <span
                  className={`font-display text-base font-semibold tabular-nums ${
                    phase === 'PEDESTRIAN_CROSSING' ? 'text-emerald-300' : 'text-slate-200'
                  }`}
                >
                  {pedestrianText}
                </span>
              </div>
              <button
                type="button"
                onClick={onActivatePedestrian}
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3 py-2 text-xs font-semibold text-emerald-200 hover:bg-emerald-500/25 transition-colors whitespace-nowrap"
              >
                <PersonStanding className="h-4 w-4" />
                <span>Request Pedestrian WALK (15s)</span>
              </button>
            </div>
          </div>
        </section>

        {/* Main Focus: Four-Way Intersection + Schedule Queue */}
        <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.45fr_1fr] items-start">
          <Intersection
            roads={roads}
            vehiclesRef={vehiclesRef}
            vehicleMetrics={vehicleMetrics}
            roadSignals={roadSignals}
            phase={phase}
            simulationStatus={simulationStatus}
            secondsRemaining={secondsRemaining}
            currentRoadItem={currentRoadItem}
            registerCanvasRenderer={registerCanvasRenderer}
          />

          <div className="space-y-6">
            <div className="glass-panel rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
                <div>
                  <h3 className="font-display text-base font-semibold text-white">
                    Signal Scheduling Queue
                  </h3>
                  <p className="text-xs text-slate-400">
                    Green Time = Vehicle Count × 2s (No 60s cap)
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('controller')}
                  className="inline-flex items-center gap-1 text-xs font-medium text-sky-400 hover:text-sky-300"
                >
                  <span>Controller</span>
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="space-y-2">
                {schedule.map((item) => {
                  const sig = roadSignals[item.direction];
                  return (
                    <div
                      key={item.direction}
                      className={`flex items-center justify-between rounded-xl border px-3.5 py-2.5 text-xs ${
                        sig === 'GREEN'
                          ? 'border-emerald-500/45 bg-emerald-500/10'
                          : sig === 'YELLOW'
                          ? 'border-yellow-400/45 bg-yellow-500/10'
                          : item.skipped
                          ? 'border-slate-800 bg-slate-900/40 opacity-60'
                          : 'border-slate-800 bg-slate-900/60'
                      }`}
                    >
                      <div>
                        <span className="font-display font-semibold text-white">
                          {item.skipped ? 'SKIP' : `#${item.priorityRank}`} · {item.direction}
                        </span>
                        <p className="text-[11px] text-slate-400">{item.reason}</p>
                      </div>
                      <div className="text-right font-mono tabular-nums">
                        <span className="font-semibold text-sky-300 block">
                          {item.skipped ? '0s' : `${item.greenDuration}s`}
                        </span>
                        <span
                          className={
                            sig === 'GREEN'
                              ? 'text-emerald-400'
                              : sig === 'YELLOW'
                              ? 'text-yellow-300'
                              : 'text-red-400'
                          }
                        >
                          {item.skipped ? 'SKIPPED' : sig}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 px-3.5 py-2.5 text-xs text-slate-300">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>
                  Vehicles stop strictly at stop lines on RED/YELLOW and clear before next GREEN.
                </span>
              </div>
            </div>

            <EmergencyInputPanel
              activeEmergencies={activeEmergencies}
              lastEmergencyResolution={lastEmergencyResolution}
              currentRoadItem={currentRoadItem}
              phase={phase}
              onSubmitEmergency={onSubmitEmergency}
            />
          </div>
        </section>

        {/* Dedicated Traffic Input Panel (Manual Mode) */}
        <TrafficInputPanel
          roads={roads}
          operatingMode={operatingMode}
          onUpdateTraffic={onUpdateManualTraffic}
        />

        {/* Camera & YOLO Detection Panel */}
        <CameraPanel
          operatingMode={operatingMode}
          simulationStatus={simulationStatus}
          sourceMode={sourceMode}
          cameraActive={cameraActive}
          detectionRunning={detectionRunning}
          detectedBoxes={detectedBoxes}
          cppEngine={cppEngine}
          onSwitchMode={onSwitchMode}
          onSetCameraActive={onSetCameraActive}
          onSetDetectionRunning={onSetDetectionRunning}
          onSetDetectedBoxes={onSetDetectedBoxes}
          onPrepareForLiveDetection={onPrepareForLiveDetection}
          onRecordDetectedVehicle={onRecordDetectedVehicle}
          onPauseSimulation={onPauseSimulation}
          onResumeSimulation={onResumeSimulation}
          onResetSimulation={onResetSimulation}
          onConnectCppEngine={onConnectCppEngine}
          onDisconnectCppEngine={onDisconnectCppEngine}
        />
      </div>
    );
  }
);
Dashboard.displayName = 'Dashboard';
