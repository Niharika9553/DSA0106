import React, { useEffect, useRef } from 'react';
import { PersonStanding, ShieldCheck } from 'lucide-react';
import {
  RoadDirection,
  RoadInput,
  ScheduledRoad,
  SignalColor,
  SimVehicle,
  SimulationPhase,
  SimulationStatus,
} from '../types/traffic';
import { LiveVehicleMetrics } from '../hooks/useTrafficSystem';

interface IntersectionProps {
  roads: Record<RoadDirection, RoadInput>;
  vehiclesRef: React.MutableRefObject<SimVehicle[]>;
  vehicleMetrics: LiveVehicleMetrics;
  roadSignals: Record<RoadDirection, SignalColor>;
  phase: SimulationPhase;
  simulationStatus: SimulationStatus;
  secondsRemaining: number;
  currentRoadItem: ScheduledRoad | null;
  registerCanvasRenderer: (fn: ((nowMs: number) => void) | null) => void;
}

const CANVAS_SIZE = 720;
const CENTER = 360;
const ROAD_HALF = 82;
const STOP_LINE_OFFSET = 112;
const CROSSWALK_START = 84;
const CROSSWALK_WIDTH = 22;

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.closePath();
}

function drawSignalHead(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  signal: SignalColor,
  dirLabel: string,
  countdown: number | null
) {
  ctx.save();
  ctx.fillStyle = '#090f1d';
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 1.5;
  drawRoundedRect(ctx, x - 14, y - 34, 28, 68, 6);
  ctx.fill();
  ctx.stroke();

  const lights: Array<{ color: SignalColor; cy: number; on: string; off: string }> = [
    { color: 'RED', cy: y - 20, on: '#ef4444', off: '#450a0a' },
    { color: 'YELLOW', cy: y, on: '#facc15', off: '#422006' },
    { color: 'GREEN', cy: y + 20, on: '#22c55e', off: '#052e16' },
  ];

  for (const l of lights) {
    ctx.beginPath();
    ctx.arc(x, l.cy, 6.5, 0, Math.PI * 2);
    if (signal === l.color) {
      ctx.fillStyle = l.on;
      ctx.shadowColor = l.on;
      ctx.shadowBlur = 12;
    } else {
      ctx.fillStyle = l.off;
      ctx.shadowBlur = 0;
    }
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  ctx.fillStyle = 'rgba(9, 15, 29, 0.92)';
  drawRoundedRect(ctx, x - 24, y + 38, 48, 18, 4);
  ctx.fill();
  ctx.fillStyle =
    signal === 'GREEN' ? '#4ade80' : signal === 'YELLOW' ? '#facc15' : '#f87171';
  ctx.font = '700 10px "JetBrains Mono", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const label =
    countdown !== null && countdown > 0 ? `${dirLabel[0]}:${countdown}s` : dirLabel[0];
  ctx.fillText(label, x, y + 47);

  ctx.restore();
}

function drawVehicle(ctx: CanvasRenderingContext2D, v: SimVehicle, nowMs: number) {
  // Skip drawing vehicles far off-canvas upstream while queued
  if (v.position < -385) return;

  ctx.save();

  let cx = CENTER;
  let cy = CENTER;
  let angle = 0;

  if (v.direction === 'North') {
    cx = CENTER - ROAD_HALF / 2;
    cy = CENTER + v.position - v.length / 2;
    angle = Math.PI / 2;
  } else if (v.direction === 'South') {
    cx = CENTER + ROAD_HALF / 2;
    cy = CENTER - v.position + v.length / 2;
    angle = -Math.PI / 2;
  } else if (v.direction === 'West') {
    cx = CENTER + v.position - v.length / 2;
    cy = CENTER + ROAD_HALF / 2;
    angle = 0;
  } else {
    cx = CENTER - v.position + v.length / 2;
    cy = CENTER - ROAD_HALF / 2;
    angle = Math.PI;
  }

  ctx.translate(cx, cy);
  ctx.rotate(angle);

  const halfL = v.length / 2;
  const halfW = v.width / 2;

  let bodyColor = '#38bdf8';
  if (v.emergency === 'AMBULANCE') bodyColor = '#f8fafc';
  else if (v.emergency === 'FIRE_ENGINE') bodyColor = '#dc2626';
  else if (v.vehicleClass === 'bus') bodyColor = '#eab308';
  else if (v.vehicleClass === 'truck') bodyColor = '#94a3b8';
  else if (v.vehicleClass === 'motorcycle') bodyColor = '#2dd4bf';

  ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
  drawRoundedRect(ctx, -halfL + 1, -halfW + 2, v.length, v.width, 4);
  ctx.fill();

  ctx.fillStyle = bodyColor;
  drawRoundedRect(ctx, -halfL, -halfW, v.length, v.width, 4);
  ctx.fill();

  ctx.fillStyle = '#0f172a';
  drawRoundedRect(ctx, halfL - 10, -halfW + 2.5, 6, v.width - 5, 2);
  ctx.fill();

  ctx.fillStyle = '#fef08a';
  ctx.fillRect(halfL - 2, -halfW + 2, 2, 3);
  ctx.fillRect(halfL - 2, halfW - 5, 2, 3);

  ctx.fillStyle = v.speed < 3 ? '#ff2d2d' : '#7f1d1d';
  ctx.fillRect(-halfL, -halfW + 2, 2.5, 3.5);
  ctx.fillRect(-halfL, halfW - 5.5, 2.5, 3.5);

  if (v.emergency !== 'NONE') {
    const strobeRed = Math.floor(nowMs / 180) % 2 === 0;
    ctx.fillStyle = v.emergency === 'AMBULANCE' ? '#f97316' : '#fef08a';
    ctx.fillRect(-4, -halfW + 2, 6, v.width - 4);

    ctx.beginPath();
    ctx.arc(2, 0, 4, 0, Math.PI * 2);
    ctx.fillStyle = strobeRed ? '#ef4444' : '#3b82f6';
    ctx.shadowColor = strobeRed ? '#ef4444' : '#3b82f6';
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  ctx.restore();
}

export const Intersection: React.FC<IntersectionProps> = React.memo(
  ({
    roads,
    vehiclesRef,
    vehicleMetrics,
    roadSignals,
    phase,
    simulationStatus,
    secondsRemaining,
    currentRoadItem,
    registerCanvasRenderer,
  }) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);

    const latestPropsRef = useRef({
      roads,
      vehicleMetrics,
      roadSignals,
      phase,
      simulationStatus,
      secondsRemaining,
      currentRoadItem,
    });
    latestPropsRef.current = {
      roads,
      vehicleMetrics,
      roadSignals,
      phase,
      simulationStatus,
      secondsRemaining,
      currentRoadItem,
    };

    useEffect(() => {
      const renderCanvas = (nowMs: number) => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const dpr = window.devicePixelRatio || 1;
        const targetPx = CANVAS_SIZE * dpr;
        if (canvas.width !== targetPx || canvas.height !== targetPx) {
          canvas.width = targetPx;
          canvas.height = targetPx;
        }

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const {
          roads: currRoads,
          vehicleMetrics: currMetrics,
          roadSignals: currSignals,
          phase: currPhase,
          simulationStatus: currSimStatus,
          secondsRemaining: currSec,
          currentRoadItem: currItem,
        } = latestPropsRef.current;

        ctx.save();
        ctx.scale(dpr, dpr);

        ctx.fillStyle = '#091121';
        ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

        const blockSize = CENTER - ROAD_HALF - 10;
        const blocks = [
          [0, 0],
          [CENTER + ROAD_HALF + 10, 0],
          [0, CENTER + ROAD_HALF + 10],
          [CENTER + ROAD_HALF + 10, CENTER + ROAD_HALF + 10],
        ];
        for (const [bx, by] of blocks) {
          ctx.fillStyle = '#0e182d';
          drawRoundedRect(ctx, bx + 10, by + 10, blockSize - 20, blockSize - 20, 12);
          ctx.fill();
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.10)';
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        ctx.fillStyle = '#192338';
        ctx.fillRect(CENTER - ROAD_HALF, 0, ROAD_HALF * 2, CANVAS_SIZE);
        ctx.fillRect(0, CENTER - ROAD_HALF, CANVAS_SIZE, ROAD_HALF * 2);

        ctx.fillStyle = '#1e2a42';
        ctx.fillRect(CENTER - ROAD_HALF, CENTER - ROAD_HALF, ROAD_HALF * 2, ROAD_HALF * 2);

        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(CENTER - ROAD_HALF, 0);
        ctx.lineTo(CENTER - ROAD_HALF, CENTER - ROAD_HALF);
        ctx.moveTo(CENTER + ROAD_HALF, 0);
        ctx.lineTo(CENTER + ROAD_HALF, CENTER - ROAD_HALF);
        ctx.moveTo(CENTER - ROAD_HALF, CENTER + ROAD_HALF);
        ctx.lineTo(CENTER - ROAD_HALF, CANVAS_SIZE);
        ctx.moveTo(CENTER + ROAD_HALF, CENTER + ROAD_HALF);
        ctx.lineTo(CENTER + ROAD_HALF, CANVAS_SIZE);
        ctx.moveTo(0, CENTER - ROAD_HALF);
        ctx.lineTo(CENTER - ROAD_HALF, CENTER - ROAD_HALF);
        ctx.moveTo(0, CENTER + ROAD_HALF);
        ctx.lineTo(CENTER - ROAD_HALF, CENTER + ROAD_HALF);
        ctx.moveTo(CENTER + ROAD_HALF, CENTER - ROAD_HALF);
        ctx.lineTo(CANVAS_SIZE, CENTER - ROAD_HALF);
        ctx.moveTo(CENTER + ROAD_HALF, CENTER + ROAD_HALF);
        ctx.lineTo(CANVAS_SIZE, CENTER + ROAD_HALF);
        ctx.stroke();

        // Yellow center lines
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.72)';
        ctx.lineWidth = 2;
        ctx.setLineDash([12, 10]);
        ctx.beginPath();
        ctx.moveTo(CENTER, 0);
        ctx.lineTo(CENTER, CENTER - STOP_LINE_OFFSET);
        ctx.moveTo(CENTER, CENTER + STOP_LINE_OFFSET);
        ctx.lineTo(CENTER, CANVAS_SIZE);
        ctx.moveTo(0, CENTER);
        ctx.lineTo(CENTER - STOP_LINE_OFFSET, CENTER);
        ctx.moveTo(CENTER + STOP_LINE_OFFSET, CENTER);
        ctx.lineTo(CANVAS_SIZE, CENTER);
        ctx.stroke();
        ctx.setLineDash([]);

        // Zebra Crosswalks
        const isPedWalk = currPhase === 'PEDESTRIAN_CROSSING';
        ctx.fillStyle = isPedWalk ? 'rgba(52, 211, 153, 0.85)' : 'rgba(226, 232, 240, 0.65)';
        const stripeCount = 7;
        const stripeStep = (ROAD_HALF * 2 - 16) / stripeCount;

        for (let i = 0; i < stripeCount; i++) {
          const offset = CENTER - ROAD_HALF + 10 + i * stripeStep;
          ctx.fillRect(offset, CENTER - CROSSWALK_START - CROSSWALK_WIDTH, 10, CROSSWALK_WIDTH);
          ctx.fillRect(offset, CENTER + CROSSWALK_START, 10, CROSSWALK_WIDTH);
          ctx.fillRect(CENTER - CROSSWALK_START - CROSSWALK_WIDTH, offset, CROSSWALK_WIDTH, 10);
          ctx.fillRect(CENTER + CROSSWALK_START, offset, CROSSWALK_WIDTH, 10);
        }

        // Stop Lines
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(CENTER - ROAD_HALF + 3, CENTER - STOP_LINE_OFFSET - 3, ROAD_HALF - 5, 4);
        ctx.fillRect(CENTER + 2, CENTER + STOP_LINE_OFFSET - 1, ROAD_HALF - 5, 4);
        ctx.fillRect(CENTER - STOP_LINE_OFFSET - 3, CENTER + 2, 4, ROAD_HALF - 5);
        ctx.fillRect(CENTER + STOP_LINE_OFFSET - 1, CENTER - ROAD_HALF + 3, 4, ROAD_HALF - 5);

        // Road Badges showing Density Count + Queued vs Crossed
        const drawRoadBadge = (x: number, y: number, dir: RoadDirection) => {
          const sig = currSignals[dir];
          const count = currRoads[dir].vehicleCount;
          const queued = currMetrics.queuedByDir[dir];
          const crossed = currMetrics.crossedByDir[dir];

          ctx.fillStyle = 'rgba(13, 22, 40, 0.92)';
          ctx.strokeStyle =
            sig === 'GREEN'
              ? 'rgba(34, 197, 94, 0.55)'
              : sig === 'YELLOW'
              ? 'rgba(250, 204, 21, 0.55)'
              : 'rgba(56, 189, 248, 0.22)';
          ctx.lineWidth = 1;
          drawRoundedRect(ctx, x, y, 160, 56, 8);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#f1f5f9';
          ctx.font = '600 12px "Outfit", sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(`${dir} Road`, x + 10, y + 17);

          ctx.fillStyle =
            sig === 'GREEN' ? '#4ade80' : sig === 'YELLOW' ? '#facc15' : '#f87171';
          ctx.font = '700 11px "JetBrains Mono", monospace';
          ctx.textAlign = 'right';
          ctx.fillText(sig, x + 150, y + 17);

          ctx.fillStyle = '#38bdf8';
          ctx.textAlign = 'left';
          ctx.fillText(`Density: ${count}`, x + 10, y + 34);

          ctx.fillStyle = '#94a3b8';
          ctx.font = '500 10px "JetBrains Mono", monospace';
          ctx.fillText(`Q:${queued} · Crossed:${crossed}`, x + 10, y + 48);
        };

        drawRoadBadge(22, 22, 'North');
        drawRoadBadge(CANVAS_SIZE - 182, 22, 'East');
        drawRoadBadge(22, CANVAS_SIZE - 78, 'West');
        drawRoadBadge(CANVAS_SIZE - 182, CANVAS_SIZE - 78, 'South');

        // Render physics vehicles from ref
        for (const v of vehiclesRef.current) {
          drawVehicle(ctx, v, nowMs);
        }

        // Render pedestrian walkers ONLY during PEDESTRIAN_CROSSING
        if (isPedWalk && currSimStatus === 'RUNNING') {
          const walkProgress = ((nowMs / 1000) % 4) / 4;
          const offset =
            (walkProgress < 0.5 ? walkProgress * 2 : (1 - walkProgress) * 2) *
            (ROAD_HALF * 2 - 40);
          const pedPositions = [
            { x: CENTER - ROAD_HALF + 20 + offset, y: CENTER - CROSSWALK_START - 11 },
            { x: CENTER + ROAD_HALF - 20 - offset, y: CENTER + CROSSWALK_START + 11 },
            { x: CENTER - CROSSWALK_START - 11, y: CENTER - ROAD_HALF + 20 + offset },
            { x: CENTER + CROSSWALK_START + 11, y: CENTER + ROAD_HALF - 20 - offset },
          ];
          for (const p of pedPositions) {
            ctx.beginPath();
            ctx.arc(p.x, p.y, 6, 0, Math.PI * 2);
            ctx.fillStyle = '#34d399';
            ctx.shadowColor = '#34d399';
            ctx.shadowBlur = 10;
            ctx.fill();
            ctx.shadowBlur = 0;
          }
        }

        // Traffic Signal Heads
        drawSignalHead(
          ctx,
          CENTER - ROAD_HALF - 26,
          CENTER - STOP_LINE_OFFSET - 34,
          currSignals.North,
          'North',
          currItem?.direction === 'North' ? currSec : null
        );
        drawSignalHead(
          ctx,
          CENTER + ROAD_HALF + 26,
          CENTER + STOP_LINE_OFFSET - 12,
          currSignals.South,
          'South',
          currItem?.direction === 'South' ? currSec : null
        );
        drawSignalHead(
          ctx,
          CENTER - STOP_LINE_OFFSET - 26,
          CENTER + ROAD_HALF + 32,
          currSignals.West,
          'West',
          currItem?.direction === 'West' ? currSec : null
        );
        drawSignalHead(
          ctx,
          CENTER + STOP_LINE_OFFSET + 26,
          CENTER - ROAD_HALF - 34,
          currSignals.East,
          'East',
          currItem?.direction === 'East' ? currSec : null
        );

        // Center Status Indicator
        if (isPedWalk) {
          ctx.fillStyle = 'rgba(5, 46, 22, 0.92)';
          ctx.strokeStyle = '#34d399';
          ctx.lineWidth = 2;
          drawRoundedRect(ctx, CENTER - 56, CENTER - 32, 112, 64, 10);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#34d399';
          ctx.font = '700 13px "Outfit", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('WALK', CENTER, CENTER - 6);

          ctx.fillStyle = '#ffffff';
          ctx.font = '700 20px "JetBrains Mono", monospace';
          ctx.fillText(`${currSec}s`, CENTER, CENTER + 18);
        } else if (currPhase === 'RED_CLEARANCE') {
          ctx.fillStyle = 'rgba(69, 10, 10, 0.90)';
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 1.5;
          drawRoundedRect(ctx, CENTER - 56, CENTER - 24, 112, 48, 8);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#fca5a5';
          ctx.font = '700 11px "JetBrains Mono", monospace';
          ctx.textAlign = 'center';
          ctx.fillText('ALL-RED', CENTER, CENTER - 4);
          ctx.fillText('CLEARANCE', CENTER, CENTER + 12);
        }

        ctx.restore();
      };

      registerCanvasRenderer(renderCanvas);
      renderCanvas(performance.now());
      return () => registerCanvasRenderer(null);
    }, [registerCanvasRenderer, vehiclesRef]);

    const totalQueued =
      vehicleMetrics.queuedByDir.North +
      vehicleMetrics.queuedByDir.South +
      vehicleMetrics.queuedByDir.East +
      vehicleMetrics.queuedByDir.West;

    return (
      <div className="glass-panel rounded-2xl p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-lg font-semibold text-white">
              Four-Way Top-Down Traffic Intersection
            </h2>
            <p className="text-xs text-slate-400">
              Stop-line braking · Collision-free lane queues · All-red clearance lock
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            <span className="text-slate-300 tabular-nums">
              Queued: <strong className="text-sky-300">{totalQueued}</strong>
            </span>
            <span className="text-slate-300 tabular-nums">
              Crossed: <strong className="text-emerald-300">{vehicleMetrics.totalCrossed}</strong>
            </span>
            <div className="flex items-center gap-1.5 text-slate-300">
              <ShieldCheck className="h-4 w-4 text-sky-400" />
              <span
                className={
                  vehicleMetrics.insideIntersection > 0 ? 'text-amber-300' : 'text-emerald-300'
                }
              >
                {vehicleMetrics.insideIntersection > 0
                  ? `Clearing (${vehicleMetrics.insideIntersection})`
                  : 'Clear'}
              </span>
            </div>

            {phase === 'PEDESTRIAN_CROSSING' && (
              <div className="flex items-center gap-1.5 font-semibold text-emerald-300">
                <PersonStanding className="h-4 w-4" />
                <span>WALK · {secondsRemaining}s</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-center">
          <canvas
            ref={canvasRef}
            className="aspect-square w-full max-w-[640px] rounded-xl border border-slate-700/80 shadow-2xl"
            aria-label="Top-down four-way traffic intersection simulation"
          />
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 pt-3 text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2.5 w-3.5 rounded-sm bg-sky-400 inline-block" /> Car
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2.5 w-4 rounded-sm bg-yellow-400 inline-block" /> Bus
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2.5 w-4 rounded-sm bg-slate-400 inline-block" /> Truck
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2 w-2.5 rounded-sm bg-teal-400 inline-block" /> Motorcycle
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2.5 w-4 rounded-sm bg-white border border-orange-500 inline-block" /> Ambulance / Fire
            </span>
          </div>
          <span className="font-mono text-slate-400">
            Status: {simulationStatus}
          </span>
        </div>
      </div>
    );
  }
);
Intersection.displayName = 'Intersection';
