import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Download,
  FileSpreadsheet,
  FileText,
  History,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { CongestionLevel, TrafficCycleRecord } from '../types/traffic';
import {
  exportHistoryToCSV,
  exportHistoryToTextReport,
  formatEmergencyLabel,
} from '../utils/trafficEngine';

interface TrafficHistoryProps {
  history: TrafficCycleRecord[];
  onClearHistory: () => void;
  onRestoreSample: () => void;
}

type HistoryFilter = 'ALL' | 'EMERGENCY' | CongestionLevel;

function triggerDownload(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export const TrafficHistory: React.FC<TrafficHistoryProps> = React.memo(
  ({ history, onClearHistory, onRestoreSample }) => {
    const [filter, setFilter] = useState<HistoryFilter>('ALL');
    const [confirmClear, setConfirmClear] = useState(false);

  const filtered = useMemo(() => {
    const rev = [...history].reverse();
    if (filter === 'ALL') return rev;
    if (filter === 'EMERGENCY') return rev.filter((c) => c.emergencies.length > 0);
    return rev.filter((c) => c.congestionLevel === filter);
  }, [history, filter]);

  return (
    <div className="space-y-6">
      <section className="glass-panel rounded-2xl p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-700/60 pb-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-white">
              Traffic History & Reports
            </h2>
            <p className="text-xs text-slate-400">
              Completed cycles logged automatically to local storage ({history.length} cycles)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              disabled={history.length === 0}
              onClick={() =>
                triggerDownload(
                  exportHistoryToCSV(history),
                  `traffic_history_${new Date().toISOString().slice(0, 10)}.csv`,
                  'text/csv;charset=utf-8;'
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-sky-500/30 bg-sky-500/15 px-3.5 py-2 text-xs font-semibold text-sky-200 hover:bg-sky-500/25 disabled:opacity-40 transition-colors whitespace-nowrap"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Export CSV</span>
            </button>

            <button
              type="button"
              disabled={history.length === 0}
              onClick={() =>
                triggerDownload(
                  exportHistoryToTextReport(history),
                  `traffic_report_${new Date().toISOString().slice(0, 10)}.txt`,
                  'text/plain;charset=utf-8;'
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-500 disabled:opacity-40 transition-colors whitespace-nowrap"
            >
              <Download className="h-4 w-4" />
              <span>Download Report</span>
            </button>

            <button
              type="button"
              disabled={history.length === 0}
              onClick={() => setConfirmClear(true)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-red-500/35 bg-red-500/15 px-3.5 py-2 text-xs font-semibold text-red-200 hover:bg-red-500/25 disabled:opacity-40 transition-colors whitespace-nowrap"
            >
              <Trash2 className="h-4 w-4" />
              <span>Clear History</span>
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 p-1">
            {(
              [
                { id: 'ALL', label: 'All' },
                { id: 'EMERGENCY', label: 'Emergency' },
                { id: 'LOW', label: 'Low' },
                { id: 'MEDIUM', label: 'Medium' },
                { id: 'HIGH', label: 'High' },
              ] as Array<{ id: HistoryFilter; label: string }>
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  filter === tab.id
                    ? 'bg-sky-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <span className="font-mono text-xs text-slate-400 tabular-nums">
            Showing {filtered.length} of {history.length}
          </span>
        </div>

        {history.length === 0 ? (
          <div className="mt-6 flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 bg-slate-900/40 px-6 py-10 text-center">
            <History className="h-9 w-9 text-slate-500" />
            <p className="mt-2 font-display text-sm font-semibold text-white">
              No Completed Cycles Stored
            </p>
            <p className="mt-1 text-xs text-slate-400">
              Cycles log automatically after each 15s pedestrian crossing phase.
            </p>
            <button
              type="button"
              onClick={onRestoreSample}
              className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-500"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Restore Sample Cycles</span>
            </button>
          </div>
        ) : (
          <div className="mt-5 overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400">
                  <th className="py-2.5 pr-3 font-medium">Cycle</th>
                  <th className="py-2.5 px-3 font-medium">Timestamp</th>
                  <th className="py-2.5 px-3 font-medium">Source</th>
                  <th className="py-2.5 px-3 font-medium">Counts (N/S/E/W)</th>
                  <th className="py-2.5 px-3 font-medium">Signal Order</th>
                  <th className="py-2.5 px-3 font-medium">Green Durations</th>
                  <th className="py-2.5 px-3 font-medium">Emergency</th>
                  <th className="py-2.5 pl-3 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/35">
                    <td className="py-2.5 pr-3 font-mono font-semibold text-sky-300 tabular-nums">
                      #{item.cycleNumber}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-xs text-slate-300 whitespace-nowrap tabular-nums">
                      {new Date(item.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-xs text-slate-300 whitespace-nowrap">
                      {item.sourceMode}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-xs text-slate-200 whitespace-nowrap tabular-nums">
                      N:{item.vehicleCounts.North} · S:{item.vehicleCounts.South} · E:
                      {item.vehicleCounts.East} · W:{item.vehicleCounts.West} ({item.totalVehicles})
                    </td>
                    <td className="py-2.5 px-3 text-xs text-slate-200 whitespace-nowrap">
                      {item.signalOrder.join(' → ') || 'Skipped'}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-xs text-slate-300 whitespace-nowrap tabular-nums">
                      N:{item.greenDurations.North}s · S:{item.greenDurations.South}s · E:
                      {item.greenDurations.East}s · W:{item.greenDurations.West}s
                    </td>
                    <td className="py-2.5 px-3 text-xs">
                      {item.emergencies.length > 0 ? (
                        <span className="font-semibold text-orange-300">
                          {item.emergencies
                            .map((e) => `${e.direction} (${formatEmergencyLabel(e.type)})`)
                            .join(', ')}
                        </span>
                      ) : (
                        <span className="text-slate-500">None</span>
                      )}
                    </td>
                    <td
                      className={`py-2.5 pl-3 text-right font-mono text-xs font-bold ${
                        item.congestionLevel === 'HIGH'
                          ? 'text-red-400'
                          : item.congestionLevel === 'MEDIUM'
                          ? 'text-orange-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {item.congestionLevel}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {confirmClear && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="glass-panel-elevated w-full max-w-md rounded-2xl p-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 text-red-400 shrink-0" />
              <div>
                <h3 className="font-display text-lg font-semibold text-white">
                  Clear Traffic History?
                </h3>
                <p className="mt-1 text-sm text-slate-300">
                  This removes all {history.length} saved cycle records from browser local storage.
                </p>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearHistory();
                  setConfirmClear(false);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-500"
              >
                <FileText className="h-3.5 w-3.5" />
                <span>Confirm Clear</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});
TrafficHistory.displayName = 'TrafficHistory';
