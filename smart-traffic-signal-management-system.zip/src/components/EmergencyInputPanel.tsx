import React, { useState } from 'react';
import { Ambulance, CheckCircle2, Flame, Siren } from 'lucide-react';
import {
  EmergencyEventInfo,
  EmergencyResolutionInfo,
  EmergencyType,
  RoadDirection,
  ScheduledRoad,
  SimulationPhase,
} from '../types/traffic';
import { formatEmergencyLabel, ROAD_DIRECTIONS } from '../utils/trafficEngine';

interface EmergencyInputPanelProps {
  activeEmergencies: EmergencyEventInfo[];
  lastEmergencyResolution: EmergencyResolutionInfo | null;
  currentRoadItem: ScheduledRoad | null;
  phase: SimulationPhase;
  onSubmitEmergency: (
    direction: RoadDirection,
    type: Exclude<EmergencyType, 'NONE'>
  ) => void;
}

export const EmergencyInputPanel: React.FC<EmergencyInputPanelProps> = React.memo(
  ({
    activeEmergencies,
    lastEmergencyResolution,
    currentRoadItem,
    phase,
    onSubmitEmergency,
  }) => {
    const [selectedType, setSelectedType] =
      useState<Exclude<EmergencyType, 'NONE'>>('AMBULANCE');
    const [selectedDirection, setSelectedDirection] =
      useState<RoadDirection>('South');

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      onSubmitEmergency(selectedDirection, selectedType);
    };

    return (
      <section className="glass-panel rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/60 pb-3.5">
          <div className="flex items-center gap-2.5">
            <Siren className="h-5 w-5 text-orange-400 shrink-0" />
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Emergency Vehicle Input & Priority
              </h2>
              <p className="text-xs text-slate-400">
                Tracks emergency vehicle until exit, releases priority, and immediately activates highest-density GREEN
              </p>
            </div>
          </div>
        </div>

        {activeEmergencies.length > 0 && (
          <div
            role="alert"
            className="rounded-xl border border-orange-500/50 bg-orange-950/35 px-4 py-3 text-xs text-orange-100"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-display text-sm font-bold text-orange-300">
                PRIORITY MODE ACTIVE
              </span>
              <span className="font-mono text-orange-200">
                Phase: {phase}
              </span>
            </div>
            <p className="mt-1">
              {activeEmergencies.map((em, idx) => (
                <React.Fragment key={em.direction}>
                  {idx > 0 && ' · '}
                  <strong>{formatEmergencyLabel(em.type)}</strong> on{' '}
                  <strong>{em.direction} Road</strong>
                  {currentRoadItem?.direction === em.direction
                    ? ' (Crossing Intersection — Tracking Exit)'
                    : em.pending
                    ? ' (Safe Clearance Transitioning)'
                    : ''}
                </React.Fragment>
              ))}
            </p>
          </div>
        )}

        {activeEmergencies.length === 0 && lastEmergencyResolution && (
          <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/25 px-4 py-3 text-xs text-emerald-100">
            <div className="flex items-center gap-2 font-semibold text-emerald-300">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>
                {formatEmergencyLabel(lastEmergencyResolution.emergencyType)} Exited{' '}
                {lastEmergencyResolution.exitedDirection} Road · Priority Released
              </span>
            </div>
            <p className="mt-1 text-slate-300 font-mono text-[11px] tabular-nums">
              Latest Density (N:{lastEmergencyResolution.latestCounts.North}, S:
              {lastEmergencyResolution.latestCounts.South}, E:
              {lastEmergencyResolution.latestCounts.East}, W:
              {lastEmergencyResolution.latestCounts.West}) →{' '}
              {lastEmergencyResolution.nextDirection
                ? `Next GREEN: ${lastEmergencyResolution.nextDirection} (${lastEmergencyResolution.nextGreenDuration}s)`
                : 'All Zero (Waiting RED)'}
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-3 items-end">
          <div>
            <label
              htmlFor="emergency-type-select"
              className="block text-xs font-medium text-slate-300 mb-1.5"
            >
              Emergency Vehicle Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSelectedType('AMBULANCE')}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                  selectedType === 'AMBULANCE'
                    ? 'border-orange-400/70 bg-orange-500/20 text-orange-200'
                    : 'border-slate-700 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                <Ambulance className="h-3.5 w-3.5" />
                <span>Ambulance</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedType('FIRE_ENGINE')}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                  selectedType === 'FIRE_ENGINE'
                    ? 'border-red-400/70 bg-red-500/20 text-red-200'
                    : 'border-slate-700 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                <Flame className="h-3.5 w-3.5" />
                <span>Fire Engine</span>
              </button>
            </div>
          </div>

          <div>
            <label
              htmlFor="emergency-direction-select"
              className="block text-xs font-medium text-slate-300 mb-1.5"
            >
              Emergency Vehicle Direction
            </label>
            <select
              id="emergency-direction-select"
              value={selectedDirection}
              onChange={(e) => setSelectedDirection(e.target.value as RoadDirection)}
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-medium text-white focus:border-orange-400 focus:outline-none"
            >
              {ROAD_DIRECTIONS.map((dir) => (
                <option key={dir} value={dir}>
                  {dir} Road
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-orange-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-orange-500 transition-colors whitespace-nowrap"
          >
            <Siren className="h-4 w-4" />
            <span>SUBMIT EMERGENCY</span>
          </button>
        </form>
      </section>
    );
  }
);
EmergencyInputPanel.displayName = 'EmergencyInputPanel';
