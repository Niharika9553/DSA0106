export type RoadDirection = 'North' | 'South' | 'East' | 'West';

export type VehicleClass = 'car' | 'bus' | 'truck' | 'motorcycle';

export type EmergencyType = 'NONE' | 'AMBULANCE' | 'FIRE_ENGINE';

export type SignalColor = 'RED' | 'YELLOW' | 'GREEN';

export type CongestionLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export type OperatingMode = 'MANUAL' | 'CAMERA';

export type SimulationStatus = 'RUNNING' | 'PAUSED' | 'STOPPED';

export type SimulationPhase =
  | 'IDLE'
  | 'ROAD_GREEN'
  | 'ROAD_YELLOW'
  | 'RED_CLEARANCE'
  | 'PEDESTRIAN_CROSSING';

export type DetectionSourceMode =
  | 'NONE'
  | 'CPP_ENGINE'
  | 'CAMERA'
  | 'VIDEO_UPLOAD'
  | 'PRERECORDED_DEMO';

export type NavSection =
  | 'dashboard'
  | 'intersection'
  | 'camera'
  | 'statistics'
  | 'controller'
  | 'emergency'
  | 'analytics'
  | 'history'
  | 'cpp_guide';

export interface RoadClassCounts {
  car: number;
  bus: number;
  truck: number;
  motorcycle: number;
}

export interface RoadInput {
  direction: RoadDirection;
  vehicleCount: number;
  classCounts: RoadClassCounts;
  emergency: EmergencyType;
}

export interface ScheduledRoad {
  direction: RoadDirection;
  vehicleCount: number;
  emergency: EmergencyType;
  greenDuration: number;
  skipped: boolean;
  priorityRank: number;
  reason: string;
}

export interface EmergencyEventInfo {
  direction: RoadDirection;
  type: Exclude<EmergencyType, 'NONE'>;
  pending: boolean;
}

export interface EmergencyResolutionInfo {
  exitedDirection: RoadDirection;
  emergencyType: Exclude<EmergencyType, 'NONE'>;
  nextDirection: RoadDirection | null;
  nextGreenDuration: number;
  latestCounts: Record<RoadDirection, number>;
  timestamp: string;
}

export interface DetectedObjectBox {
  trackId: number;
  x: number;
  y: number;
  w: number;
  h: number;
  vehicleClass: VehicleClass;
  confidence: number;
  direction: RoadDirection;
  emergency: EmergencyType;
}

export type VehicleMovementState = 'QUEUED' | 'ACCELERATING' | 'CROSSING' | 'CLEARED';

export interface SimVehicle {
  id: number;
  direction: RoadDirection;
  lane: string;
  vehicleClass: VehicleClass;
  emergency: EmergencyType;
  position: number;
  speed: number;
  targetPosition: number;
  stoppingPosition: number;
  movementState: VehicleMovementState;
  length: number;
  width: number;
  passedStopLine: boolean;
}

export interface TrafficCycleRecord {
  id: string;
  cycleNumber: number;
  timestamp: string;
  vehicleCounts: Record<RoadDirection, number>;
  totalVehicles: number;
  signalOrder: RoadDirection[];
  greenDurations: Record<RoadDirection, number>;
  emergencies: Array<{ direction: RoadDirection; type: Exclude<EmergencyType, 'NONE'> }>;
  congestionLevel: CongestionLevel;
  weightedScore: number;
  pedestrianDuration: number;
  sourceMode: string;
}

export interface CongestionMetrics {
  currentTotal: number;
  previousTotal: number | null;
  weightedScore: number;
  level: CongestionLevel;
  formulaText: string;
}

export type SimulationSpeed = 1 | 2 | 5;
