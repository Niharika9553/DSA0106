/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Analytics } from './components/Analytics';
import { CameraPanel } from './components/CameraPanel';
import { CppEngineGuide } from './components/CppEngineGuide';
import { Dashboard } from './components/Dashboard';
import { EmergencyAlerts } from './components/EmergencyAlerts';
import { Intersection } from './components/Intersection';
import { Sidebar } from './components/Sidebar';
import { SignalController } from './components/SignalController';
import { TopBar } from './components/TopBar';
import { TrafficHistory } from './components/TrafficHistory';
import { VehicleStatistics } from './components/VehicleStatistics';
import { useTrafficSystem } from './hooks/useTrafficSystem';
import { NavSection } from './types/traffic';

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const sys = useTrafficSystem();

  return (
    <div className="relative flex min-h-screen bg-[#070d19] text-slate-100">
      <div
        className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(14,165,233,0.10),transparent_50%),radial-gradient(ellipse_at_bottom_left,rgba(34,197,94,0.06),transparent_50%)]"
        aria-hidden="true"
      />

      <Sidebar
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        emergencyCount={sys.activeEmergencies.length}
      />

      <div className="relative flex min-w-0 flex-1 flex-col">
        <TopBar
          activeSection={activeSection}
          operatingMode={sys.operatingMode}
          simulationStatus={sys.simulationStatus}
          speed={sys.speed}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onSwitchMode={sys.switchOperatingMode}
          onStartSimulation={sys.startSimulation}
          onPauseSimulation={sys.pauseSimulation}
          onResumeSimulation={sys.resumeSimulation}
          onStopSimulation={sys.stopSimulation}
          onResetSimulation={sys.resetSimulation}
          onChangeSpeed={sys.setSpeed}
        />

        <main className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-6 sm:px-6 lg:px-8">
          {activeSection === 'dashboard' && (
            <Dashboard
              operatingMode={sys.operatingMode}
              simulationStatus={sys.simulationStatus}
              roads={sys.roads}
              vehiclesRef={sys.vehiclesRef}
              vehicleMetrics={sys.vehicleMetrics}
              schedule={sys.schedule}
              currentRoadItem={sys.currentRoadItem}
              roadSignals={sys.roadSignals}
              phase={sys.phase}
              secondsRemaining={sys.secondsRemaining}
              totalVehicles={sys.totalVehicles}
              activeEmergencies={sys.activeEmergencies}
              lastEmergencyResolution={sys.lastEmergencyResolution}
              sourceMode={sys.sourceMode}
              cameraActive={sys.cameraActive}
              detectionRunning={sys.detectionRunning}
              detectedBoxes={sys.detectedBoxes}
              cppEngine={sys.cppEngine}
              onSwitchMode={sys.switchOperatingMode}
              onUpdateManualTraffic={sys.updateManualTraffic}
              onSubmitEmergency={sys.submitEmergency}
              onActivatePedestrian={sys.activatePedestrianCrossing}
              onSetCameraActive={sys.setCameraActive}
              onSetDetectionRunning={sys.setDetectionRunning}
              onSetDetectedBoxes={sys.setDetectedBoxes}
              onPrepareForLiveDetection={sys.prepareForLiveDetection}
              onRecordDetectedVehicle={sys.recordDetectedVehicle}
              onPauseSimulation={sys.pauseSimulation}
              onResumeSimulation={sys.resumeSimulation}
              onResetSimulation={sys.resetSimulation}
              onConnectCppEngine={sys.connectCppEngine}
              onDisconnectCppEngine={sys.disconnectCppEngine}
              registerCanvasRenderer={sys.registerCanvasRenderer}
              onNavigate={setActiveSection}
            />
          )}

          {activeSection === 'intersection' && (
            <div className="space-y-6">
              <Intersection
                roads={sys.roads}
                vehiclesRef={sys.vehiclesRef}
                vehicleMetrics={sys.vehicleMetrics}
                roadSignals={sys.roadSignals}
                phase={sys.phase}
                simulationStatus={sys.simulationStatus}
                secondsRemaining={sys.secondsRemaining}
                currentRoadItem={sys.currentRoadItem}
                registerCanvasRenderer={sys.registerCanvasRenderer}
              />
              <SignalController
                schedule={sys.schedule}
                activeQueue={sys.activeQueue}
                activeQueueIndex={sys.activeQueueIndex}
                currentRoadItem={sys.currentRoadItem}
                roadSignals={sys.roadSignals}
                phase={sys.phase}
                secondsRemaining={sys.secondsRemaining}
                servedDirections={sys.servedDirections}
                vehiclesInsideIntersection={sys.vehicleMetrics.insideIntersection}
                simulationStatus={sys.simulationStatus}
                pendingPedestrian={sys.pendingPedestrian}
                speed={sys.speed}
                onChangeSpeed={sys.setSpeed}
                onTriggerPedestrian={sys.activatePedestrianCrossing}
              />
            </div>
          )}

          {activeSection === 'camera' && (
            <div className="space-y-6">
              <CameraPanel
                operatingMode={sys.operatingMode}
                simulationStatus={sys.simulationStatus}
                sourceMode={sys.sourceMode}
                cameraActive={sys.cameraActive}
                detectionRunning={sys.detectionRunning}
                detectedBoxes={sys.detectedBoxes}
                cppEngine={sys.cppEngine}
                onSwitchMode={sys.switchOperatingMode}
                onSetCameraActive={sys.setCameraActive}
                onSetDetectionRunning={sys.setDetectionRunning}
                onSetDetectedBoxes={sys.setDetectedBoxes}
                onPrepareForLiveDetection={sys.prepareForLiveDetection}
                onRecordDetectedVehicle={sys.recordDetectedVehicle}
                onPauseSimulation={sys.pauseSimulation}
                onResumeSimulation={sys.resumeSimulation}
                onResetSimulation={sys.resetSimulation}
                onConnectCppEngine={sys.connectCppEngine}
                onDisconnectCppEngine={sys.disconnectCppEngine}
              />
              <VehicleStatistics
                roads={sys.roads}
                operatingMode={sys.operatingMode}
                vehicleMetrics={sys.vehicleMetrics}
                onUpdateManualTraffic={sys.updateManualTraffic}
              />
            </div>
          )}

          {activeSection === 'statistics' && (
            <VehicleStatistics
              roads={sys.roads}
              operatingMode={sys.operatingMode}
              vehicleMetrics={sys.vehicleMetrics}
              onUpdateManualTraffic={sys.updateManualTraffic}
            />
          )}

          {activeSection === 'controller' && (
            <SignalController
              schedule={sys.schedule}
              activeQueue={sys.activeQueue}
              activeQueueIndex={sys.activeQueueIndex}
              currentRoadItem={sys.currentRoadItem}
              roadSignals={sys.roadSignals}
              phase={sys.phase}
              secondsRemaining={sys.secondsRemaining}
              servedDirections={sys.servedDirections}
              vehiclesInsideIntersection={sys.vehicleMetrics.insideIntersection}
              simulationStatus={sys.simulationStatus}
              pendingPedestrian={sys.pendingPedestrian}
              speed={sys.speed}
              onChangeSpeed={sys.setSpeed}
              onTriggerPedestrian={sys.activatePedestrianCrossing}
            />
          )}

          {activeSection === 'emergency' && (
            <EmergencyAlerts
              roads={sys.roads}
              activeEmergencies={sys.activeEmergencies}
              lastEmergencyResolution={sys.lastEmergencyResolution}
              currentRoadItem={sys.currentRoadItem}
              phase={sys.phase}
              onSubmitEmergency={sys.submitEmergency}
            />
          )}

          {activeSection === 'analytics' && (
            <Analytics
              roads={sys.roads}
              schedule={sys.schedule}
              history={sys.history}
              vehicleMetrics={sys.vehicleMetrics}
            />
          )}

          {activeSection === 'history' && (
            <TrafficHistory
              history={sys.history}
              onClearHistory={sys.clearHistory}
              onRestoreSample={sys.restoreSampleHistory}
            />
          )}

          {activeSection === 'cpp_guide' && <CppEngineGuide />}
        </main>
      </div>
    </div>
  );
}
